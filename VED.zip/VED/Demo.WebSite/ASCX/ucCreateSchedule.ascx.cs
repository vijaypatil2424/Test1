﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Newtonsoft.Json;
using VED_WebService.SharePoint;
using VED_WebService.SharePoint.BusinessLayer;
using System.Configuration;
using VED_WebService.SharePoint.DTO;
using System.Data;



namespace Demo.WebSite.ASCX
{
    public partial class ucCreateSchedule : System.Web.UI.UserControl
    {
        Business BL = null;
        string executionContext = "";
        string loginName = string.Empty;
        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]
        public ucCreateSchedule()
        {
            BL = new Business();
            executionContext = Guid.NewGuid().ToString();
            loginName = ConfigurationManager.AppSettings["loginUser"].ToString();
            //"IsImageAvailable"
        }


        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                BindCenterDropDown();
                BindVEDScheduled();
                BindPreviouScheduledByUserID(loginName);
                detailsDIV.Visible = false;
                //Disable the  Save button if , we are between 6 and 24 of the month

                int currentDay = DateTime.Now.Day;
                if (currentDay >= 6 && currentDay <= 24)
                {
                    btnSubmit.Enabled = false;
                    txtScheduleDate.Enabled = false;
                    ddlCenters.Enabled = false;
                    lblError.Text = "Assessment scheduling is only allowed between 25th and 5th of respective month";
                }




            }
        }

        private void BindPreviouScheduledByUserID(string loginName)
        {

            string[] arr = new string[3];
            arr[0] = "count=100";
            arr[1] = "UserID=" + loginName + "";
            arr[2] = "Type=1";
            ServiceResult<Generic> data = BL.GenericMethod("usp_GetTheScheduleHistoryOfCenterByUserID", executionContext, loginName, VED_WebService.SharePoint.RequestType.Portal, arr);
            DataSet result = JsonConvert.DeserializeObject<DataSet>(data.Data.ResultData);
            if (result.Tables.Count > 0)
            {
                grdPreviousSchedules.DataSource = result.Tables[0];
                grdPreviousSchedules.DataBind();
            }
        }
        private void BindVEDScheduled(bool isRebind = false)
        {
            try
            {
                ServiceResult<List<VEDSchedule>> results = BL.GetAllScheduleForCurrentMonth(loginName, executionContext, loginName);
                grdCentersDetails.DataSource = null;
                grdCentersDetails.DataBind();
                //grdCentersDetails.PageIndex = 0;
                grdCentersDetails.DataSource = results.Data;
                if (isRebind) { grdCentersDetails.PageIndex = 0; }
                grdCentersDetails.DataBind();
                //
                //grdCentersDetails.SetPageIndex(0);
            }
            catch (Exception)
            {

                throw;
            }
        }

        private void BindCenterDropDown()
        {

            ServiceResult<List<CommonDDL>> results = BL.GetAllCentersByUserID(loginName, executionContext, "");
            if (results.ErrorCode == "1")
            {
                ddlCenters.DataSource = results.Data;
                ddlCenters.DataTextField = "Title";
                ddlCenters.DataValueField = "ID";
                ddlCenters.DataBind();
                ddlCenters.Items.Insert(0, new ListItem("Select Center", "0"));
                executionContext = results.ExecutionContext;
            }
            else
            {
                lblError.Text = results.ErrorMessage + "Error code : " + executionContext;
            }
        }

        private void ClearControls()
        {
            lblOfficeArea.Text = string.Empty;
            lblOfficeCSPerson.Text = string.Empty;
            lblOfficeAddress.Text = string.Empty;
            lblOfficeType.Text = string.Empty;
            lblActualDate.Text = string.Empty;
            lblCity.Text = string.Empty;
            lblOfficeArea.Text = string.Empty;
            //lblScheduleDate.Text = string.Empty;
            txtScheduleDate.Text = string.Empty;
            //lblZone.Text = string.Empty;
            txtComments.Text = string.Empty;
            txtComments.Visible = false;
            ddlCenters.Enabled = true;
            ddlCenters.ClearSelection();
            //ddlCenters.SelectedValue = 0;
            ddlCenters.Items.FindByValue("0").Selected = true;
            BindVEDScheduled(true);
            btnSubmit.Text = "Submit";
            detailsDIV.Visible = false;
            lblError.Text = string.Empty;

        }

        private void GetVEDScheduledData(int VEDId)
        {
            ViewState["currentItem"] = string.Empty;
            ServiceResult<VEDSchedule> data = BL.GetScheduledVEDDetailsByID(VEDId.ToString(), executionContext, loginName);
            lblCity.Text = data.Data.City;
            lblOfficeAddress.Text = data.Data.Address;
            lblOfficeCSPerson.Text = data.Data.Address;
            lblOfficeType.Text = data.Data.OfficeType;
            // lblZone.Text = data.Data.Zone;
            lblOfficeArea.Text = data.Data.CarpetArea;
            txtScheduleDate.Text = data.Data.ScheduledOn;
            ddlCenters.ClearSelection();
            ddlCenters.Items.FindByValue(data.Data.OfficeID).Selected = true;
            ddlCenters.Enabled = false;
            ViewState["currentItem"] = VEDId;
            txtComments.Visible = true;
            txtComments.Text = string.Empty;
            lblError.Text = string.Empty;
            detailsDIV.Visible = true;
            lblZone.Text = data.Data.Zone;

        }

        protected void EditSchedule(object sender, EventArgs e)
        {
            btnSubmit.Text = "Update";
            GridViewRow row = (sender as LinkButton).NamingContainer as GridViewRow;
            int ID = Convert.ToInt32(grdCentersDetails.Rows[row.RowIndex].Cells[6].Text);
            GetVEDScheduledData(ID);
        }

        protected void ddlCenters_SelectedIndexChanged(object sender, EventArgs e)
        {

            try
            {
                ServiceResult<Office> officeDetails = BL.GetCenterDetailsByID(ddlCenters.SelectedValue, executionContext, loginName);
                if (officeDetails.ErrorCode == "1")
                {
                    if (officeDetails.Data != null)
                    {
                        lblCity.Text = officeDetails.Data.City;
                        lblOfficeAddress.Text = officeDetails.Data.Address;
                        lblOfficeCSPerson.Text = officeDetails.Data.Address;
                        lblOfficeType.Text = officeDetails.Data.OfficeType;
                        //lblZone.Text = officeDetails.Data.Zone;
                        lblOfficeArea.Text = officeDetails.Data.CarpetArea;
                        lblZone.Text = officeDetails.Data.Zone;
                        btnSubmit.Text = "Submit";
                        txtComments.Visible = false;
                        lblError.Text = string.Empty;
                        detailsDIV.Visible = true;
                    }
                    else
                    {
                        lblError.Text = "No data found for the selected center";

                    }
                }
                else
                {
                    lblError.Text = officeDetails.ErrorMessage + "Error code : " + executionContext;
                }

            }
            catch (Exception ex)
            {
                
                throw;
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            string scheduleDate = txtScheduleDate.Text.Trim();
            if (ddlCenters.SelectedValue == "0")
            {
                lblError.Text = "Please select the center";
            }
            else if (scheduleDate == string.Empty)
            {
                lblError.Text = "Please select the date.";
            }
            else if (btnSubmit.Text.ToUpper() == "UPDATE" && txtComments.Text == string.Empty)
            {
                lblError.Text = "Please provide Comments.";
            }
            else if (btnSubmit.Text.ToUpper() == "SUBMIT" && CheckDateRangeValidation(txtScheduleDate.Text))
            {
                lblError.Text = "Please change the Schedule date";
            }
            else
            {
                ServiceResult result = null;
                if (btnSubmit.Text.ToUpper() == "SUBMIT") { result = BL.AddVEDSchedule("", ddlCenters.SelectedValue, scheduleDate, "", executionContext, loginName); }
                else
                {
                    result = BL.AddVEDSchedule(ViewState["currentItem"].ToString(), ddlCenters.SelectedValue, scheduleDate, txtComments.Text, executionContext, loginName);
                }

                if (result.ErrorCode == "1")
                {
                    lblError.Text = result.ErrorMessage;
                    ClearControls();
                    ddlCenters.SelectedIndex = 0;
                    //BindVEDScheduled();
                }
                else
                {
                    lblError.Text = result.ErrorMessage + " Error Code : " + result.ExecutionContext;
                }
            }
        }

        private bool CheckDateRangeValidation(string scheduleDate)
        {
            return false;
        }

        protected void grdCentersDetails_RowDataBound(object sender, GridViewRowEventArgs e)
        {

            if (e.Row.RowType == DataControlRowType.DataRow)
            {

                DateTime scheduleDate = Convert.ToDateTime(((Label)e.Row.FindControl("lblScheduledOn")).Text);
                DateTime minus3Days = DateTime.Now;
                HyperLink lnkView = (HyperLink)e.Row.FindControl("lnkView");
                double daysDiff = (minus3Days - scheduleDate).TotalDays;
                //if(daysDiff )
                if (daysDiff >= -3)
                {
                    if (lnkView != null)
                    {
                        lnkView.Visible = true;
                    }
                }
                else
                {
                    lnkView.Visible = false;
                }

                bool isEditable = Convert.ToBoolean(e.Row.Cells[5].Text);
                if (!isEditable)
                {
                    LinkButton lnk = (LinkButton)e.Row.FindControl("lnkEdit");
                    if (lnk != null)
                    {
                        lnk.Visible = false;
                    }
                }
            }
        }

        protected void grdCentersDetails_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdCentersDetails.PageIndex = e.NewPageIndex;
            BindVEDScheduled();
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            ClearControls();
        }
    }
}