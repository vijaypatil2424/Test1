﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VED_WebService.SharePoint.BusinessLayer;
using VED_WebService.SharePoint.DTO;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using VED_WebService.SharePoint;
using Newtonsoft.Json;
using DTO = VED_WebService.SharePoint.DTO;
using System.Configuration;

namespace Demo.WebSite.ASCX
{
    public partial class ucSaveAssessment : System.Web.UI.UserControl
    {
        
        Business BL = null;
        string executionContext = "";
        string loginName = string.Empty;
        public ucSaveAssessment()
        {
            BL = new Business();
            executionContext = Guid.NewGuid().ToString();
            loginName = "sachin7.jain";
        }

        protected void Page_Load(object sender, EventArgs e)
        {

            //TODO : To check if Page load is perform , to hide the SAVE button
            try
            {
                string officeTypeID = string.Empty;
                if (HttpContext.Current.Request.QueryString["vedid"] != null)
                {
                    if (HttpContext.Current.Request.QueryString["vedid"].ToString() != string.Empty)
                    {

                        if (!Page.IsPostBack)
                        {
                            string scheduleID = Convert.ToString(HttpContext.Current.Request.QueryString["vedid"]);
                            ServiceResult<VEDSchedule> scheduleDetail = BL.GetScheduledVEDDetailsByID(scheduleID, executionContext, loginName,VED_WebService.SharePoint.RequestType.Portal);
                            lblScheduleDate.Text = scheduleDetail.Data.ScheduledOn;
                            officeTypeID = scheduleDetail.Data.OfficeTypeID.ToString();
                            lblActualDate.Text = string.IsNullOrEmpty(scheduleDetail.Data.ActualAssesstmentDate) ? DateTime.Now.ToString("dd-MMM-yyyy") : scheduleDetail.Data.ActualAssesstmentDate;
                            Page.Form.Attributes.Add("enctype", "multipart/form-data");
                            lblCenter.Text = scheduleDetail.Data.Center;
                            executionContext = scheduleDetail.ExecutionContext;
                            ServiceResult<FinalAssessmentData> result = BL.GetAssessmentDetails(HttpContext.Current.Request.QueryString["vedid"].ToString(), "", "", VED_WebService.SharePoint.RequestType.Portal);
                            if (result.Data.AssesstmentDetails.Count > 0)
                            {
                                assessmentDiv.Visible = false;
                                //  grdAssessment.Visible = false;
                                grdCentersDetails.DataSource = result.Data.VEDFinalData;
                                grdCentersDetails.DataBind();

                                readOnlyDIV.Visible = true;
                                grdAssessmentReadOnly.DataSource = result.Data.AssesstmentDetails;
                                grdAssessmentReadOnly.DataBind();

                                buttonDiv.Visible = false;

                                btnExportToExcel.Visible = true;
                            }
                            else
                            {
                                readOnlyDIV.Visible = false;
                                btnExportToExcel.Visible = false;
                                FacilityAreaDetailsMaster(officeTypeID, scheduleID);

                            }

                        }
                        //AddAttachment(postedFile, dt, Convert.ToString(lblRowID.Text.Trim()));
                    }
                    else
                    {
                        Common.ErrorLog(VED_WebService.SharePoint.Type.Information, "VEDAssessment : Page_Load", "", "No VEDID Found", loginName, executionContext, null, VED_WebService.SharePoint.RequestType.Portal);
                    }
                }
            }
            catch (Exception ex)
            {
                Common.ErrorLog(VED_WebService.SharePoint.Type.Error, "VEDAssessment : Page_Load", "", "", loginName, executionContext, ex, VED_WebService.SharePoint.RequestType.Portal);
            }
        }

        private void FacilityAreaDetailsMaster(string centerTypeID, string VEDScheduleID)
        {
            ServiceResult<Facility> result = null;
            string request = "centerTypeID : " + centerTypeID + " VEDScheduleID : " + VEDScheduleID;
            try
            {
                result = BL.GetFaciltyAreaDetailsMasters(centerTypeID, VEDScheduleID, "", loginName);
                grdAssessment.DataSource = result.Data.FacilityMaster;
                grdAssessment.DataBind();
                grdCentersDetails.DataSource = result.Data.VEDSchedules;
                grdCentersDetails.DataBind();
                ViewState["VEDSchedules"] = result.Data.VEDSchedules.ToList();
                executionContext = result.ExecutionContext;
            }
            catch (Exception ex)
            {
                Common.ErrorLog(VED_WebService.SharePoint.Type.Error, "VEDAssessment : FacilityAreaDetailsMaster", request, JsonConvert.SerializeObject(result), loginName, executionContext, ex, VED_WebService.SharePoint.RequestType.Portal);
            }

        }

        //protected void grdAssessment_DataBound(object sender, EventArgs e)
        //{


        //    GridViewRow row = new GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Normal);
        //    TableHeaderCell cell = new TableHeaderCell();
        //    cell.Text = "";
        //    cell.ColumnSpan = 2;
        //    row.Controls.Add(cell);

        //    cell = new TableHeaderCell();
        //    cell.ColumnSpan = 2;
        //    cell.Text = "Facility";
        //    row.Controls.Add(cell);

        //    cell = new TableHeaderCell();
        //    cell.ColumnSpan = 1;
        //    cell.Text = "Points";
        //    row.Controls.Add(cell);

        //    cell = new TableHeaderCell();
        //    cell.ColumnSpan = 2;
        //    cell.Text = "";
        //    row.Controls.Add(cell);
        //    grdAssessment.HeaderRow.Parent.Controls.AddAt(0, row);
        //}

        //protected void grdAssessment_RowDataBound(object sender, GridViewRowEventArgs e)
        //{
        //    if (e.Row.RowType == DataControlRowType.DataRow)
        //    {
        //        //string critricalityType = e.Row.Cells[2].Text;
        //        //DropDownList ddl = (DropDownList)e.Row.FindControl("ddlCondition");
        //        //List<ScoringMaster> scMasters = (List<ScoringMaster>)ViewState["ScoringMaster"];
        //        //ScoringMaster scMaster = scMasters.Where(t => t.Criticality == critricalityType).FirstOrDefault();
        //        //List<CommonDDL> ddlColl = new List<CommonDDL>();




        //        //CommonDDL obj = new CommonDDL();
        //    }
        ////}

        private bool ValidImage(string imageName)
        {
            bool isValid = true;

            switch (imageName.ToLower())
            {
                case "png":
                case "jpeg":
                case "jpg":
                    break;
                default:
                    isValid = false;
                    break;
            }


            return isValid;
        }

        protected void btnUploadFile_Click(object sender, EventArgs e)
        {
            GridViewRow row = (sender as Button).NamingContainer as GridViewRow;
            FileUpload flInsertFile = ((FileUpload)row.FindControl("flInsertFile"));
            Label errormsg = ((Label)row.FindControl("errormsg"));
            string lblPoint = ((Label)row.FindControl("lblPoint")).Text;
            GridView grdAttachments = ((GridView)row.FindControl("grdAttachments"));
            Label lblRowID = (Label)row.FindControl("lblRowID");
            int pageID = (Convert.ToInt32(row.RowIndex));
            lblPageId.Text = Convert.ToString(pageID);
            try
            {

                string Result = string.Empty;
                errormsg.Text = string.Empty;
                if (flInsertFile.HasFile)
                {
                    DataTable dt = (DataTable)Page.Session[AttachmentVar.Attachment + lblRowID.Text.Trim()];

                    if (dt == null)
                    {
                        if (flInsertFile.PostedFiles.Count <= 3)
                        {
                            dt = createAttachmentTable();
                        }
                        else
                        {
                            errormsg.Text = "Only three files are allowed to upload";
                            goto end;
                        }
                    }
                    if (dt.Rows.Count <= 3)
                    {
                        int fileCount = dt.Rows.Count;
                        foreach (HttpPostedFile postedFile in flInsertFile.PostedFiles)
                        {

                            double fileSize = (postedFile.ContentLength / 1024) / 1000;
                            if (fileSize > 3)
                            {
                                errormsg.Text = "Error file uploading file : " + postedFile.FileName + "Maximum file size allowed is 3 M.B";
                                goto end;
                            }
                            else if (!ValidImage(postedFile.FileName.Split('.')[1]))
                            {
                                errormsg.Text = "Invalid file format : " + postedFile.FileName + " Allowed file format are jpeg.jpg or png";
                                goto end;
                            }
                            else
                            {
                                string FileName = new FileInfo(postedFile.FileName).Name;
                                bool exists = dt.Select().ToList().Exists(dtrow => Convert.ToString(dtrow["FileName"]) == Convert.ToString(FileName));
                                if (exists)
                                {
                                    ScriptManager.RegisterStartupScript(this.Page, GetType(), "script", "alert('Attached File Name is same. Please try Another Name and Upload'); ", true);

                                }
                                else
                                {
                                    if (fileCount >= 3)
                                    {
                                        errormsg.Text = "Only three files are allowed to upload";
                                        goto end;
                                    }
                                    else
                                    {
                                        dt = AddAttachment(postedFile, dt, Convert.ToString(lblRowID.Text.Trim()));
                                        fileCount += 1;
                                    }
                                }
                            }

                        }

                        Page.Session[AttachmentVar.Attachment + lblRowID.Text.Trim()] = dt;

                        if (dt != null)
                        {
                            FillAttachmentGrid(grdAttachments, dt);
                            if (grdAssessment != null)
                            {
                                grdAssessment.HeaderRow.TableSection = TableRowSection.TableHeader;
                            }
                        }
                        else
                        {
                            grdAttachments.DataSource = createAttachmentTable();
                            grdAttachments.DataBind();
                            errormsg.Text = Result;
                        }

                    }
                    else
                    {
                        errormsg.Text = "Only three files are allowed to upload";
                        goto end;
                    }
                end:
                    return;
                }
                else
                {
                    errormsg.Text = "Select the File.";
                }
            }
            catch (Exception ex)
            {
                string ErrorLog = ex.Message + "\n\n" + ex.StackTrace + "btnUploadFile_Click";
                Common.ErrorLog(VED_WebService.SharePoint.Type.Error, "VEDAssessment : btnUploadFile_Click", "", "", loginName, executionContext, ex, VED_WebService.SharePoint.RequestType.Portal);
                //  sbErrorMessage.AppendLine(ErrorLog);
            }
        }

        private DataTable createAttachmentTable()
        {
            DataTable dtableAttachmentArray = null;

            dtableAttachmentArray = BOInsertColumn(AttachmentVar.FileName, null, dtableAttachmentArray); //  Adding FileName column manually, because its a custom column
            dtableAttachmentArray = BOInsertColumn(AttachmentVar.FileGUID, null, dtableAttachmentArray);  //  Adding FileGUID column manually, because its a custom column
            dtableAttachmentArray = BOInsertColumn(AttachmentVar.FilePath, null, dtableAttachmentArray);   //  Adding FilePath column manually, because its a custom column
            dtableAttachmentArray = BOInsertColumn(AttachmentVar.FileDelete, null, dtableAttachmentArray); //  Adding FileContents column manually, because its a custom column
            dtableAttachmentArray = BOInsertColumn(AttachmentVar.ID, null, dtableAttachmentArray); //  Adding FileContents column manually, because its a custom column
            dtableAttachmentArray = BOInsertColumn(AttachmentVar.RowIndex, null, dtableAttachmentArray); //  Adding FileContents column manually, because its a custom column
            dtableAttachmentArray = BOInsertColumn(AttachmentVar.OperationalStatus, null, dtableAttachmentArray); //  Adding FileContents column manually, because its a custom column

            return dtableAttachmentArray;
        }

        private DataTable addAttachment(DataTable dtableAttachmentArray)
        {
            string pageUniqueDt = Convert.ToString(ViewState["pageUniqueDt"]);

            if (dtableAttachmentArray == null)
            {
                dtableAttachmentArray = createAttachmentTable();
            }

            if (!string.IsNullOrEmpty(Convert.ToString(Page.Session[AttachmentVar.FileName + pageUniqueDt])))
            {
                DataRow drAttachments = dtableAttachmentArray.NewRow();
                drAttachments[AttachmentVar.FileName] = Convert.ToString(Page.Session[AttachmentVar.FileName + pageUniqueDt]);
                drAttachments[AttachmentVar.FilePath] = Convert.ToString(Page.Session[AttachmentVar.FilePath + pageUniqueDt]);
                drAttachments[AttachmentVar.FileGUID] = Convert.ToString(Page.Session[AttachmentVar.FileGUID + pageUniqueDt]);

                dtableAttachmentArray.Rows.Add(drAttachments);
            }
            /// --- Removing Page.Session --- ///
            Page.Session[AttachmentVar.FileName + pageUniqueDt] = string.Empty;
            Page.Session[AttachmentVar.FileGUID + pageUniqueDt] = string.Empty;
            Page.Session[AttachmentVar.FilePath + pageUniqueDt] = string.Empty;

            return dtableAttachmentArray;
        }

        public DataTable AddAttachment(HttpPostedFile flInsertFile, DataTable dt, string QueryStringRowIndex)
        {
            try
            {
                //SPUtility.ValidateFormDigest();
                //SPSecurity.RunWithElevatedPrivileges(delegate()
                //{
                Stream strmStream = flInsertFile.InputStream;
                Int32 intFileLength = (Int32)strmStream.Length;
                byte[] file = new byte[intFileLength + 1];
                strmStream.Read(file, 0, intFileLength);
                strmStream.Close();
                string FileName = new FileInfo(flInsertFile.FileName).Name;
                string GetTempFolder = Path.GetTempPath();
                string FilePath = GetTempFolder + DateTime.Now.ToString("yy_MM_dd_HH_mm_ss_fff_") + FileName;
                string Index = string.Empty;
                if (!System.IO.File.Exists(FilePath))
                {
                    File.WriteAllBytes(FilePath, file);
                }

                //foreach (DataRow drw in dt.Rows) 
                //{
                //    if (!string.IsNullOrEmpty(Convert.ToString(drw[AttachmentVar.Index]))) 
                //    {
                //        Index = Convert.ToString(drw[AttachmentVar.Index]);
                //        break;
                //    }
                //}
                DataRow dr = null;
                dr = dt.NewRow();
                dr[AttachmentVar.ID] = Convert.ToString(Guid.NewGuid());
                dr[AttachmentVar.OperationalStatus] = "New";
                dr[AttachmentVar.FileName] = FileName;
                dr[AttachmentVar.FilePath] = FilePath;
                dr[AttachmentVar.RowIndex] = QueryStringRowIndex;
                // dr[AttachmentVar.Index] = Index;
                //  dr["DeleteStatus"] = "0";
                dt.Rows.Add(dr);
                // reslt = string.Empty;

                try
                {
                    if (!System.IO.File.Exists(FilePath))
                    {
                        File.Delete(FilePath);
                    }
                }
                catch (Exception ex)
                {
                    Common.ErrorLog(VED_WebService.SharePoint.Type.Error, "VEDAssessment : AddAttachment_1", "", "", loginName, executionContext, ex, VED_WebService.SharePoint.RequestType.Portal);
                }

                //  });

            }

            catch (Exception ex)
            {
                Common.ErrorLog(VED_WebService.SharePoint.Type.Error, "VEDAssessment : AddAttachment_2", "", "", loginName, executionContext, ex, VED_WebService.SharePoint.RequestType.Portal);
                return dt = null;

            }
            return dt;

        }

        private static void FillAttachmentGrid(GridView grdAttachments, DataTable dtableAttachmentArray)
        {
            if (dtableAttachmentArray.Rows.Count > 0)
            {
                DataTable AttachmentPPTable = dtableAttachmentArray;

                var GetPPDt = AttachmentPPTable.AsEnumerable()
                            .Where(r => r.Field<string>(AttachmentVar.OperationalStatus) != Convert.ToString("TempDelete")
                                && r.Field<string>(AttachmentVar.OperationalStatus) != Convert.ToString("TempDelete|")
                                && r.Field<string>(AttachmentVar.OperationalStatus) != Convert.ToString("Delete")
                                && !string.IsNullOrEmpty(r.Field<string>(AttachmentVar.OperationalStatus)));

                if (GetPPDt.Any())
                {
                    AttachmentPPTable = GetPPDt.CopyToDataTable();
                    grdAttachments.DataSource = AttachmentPPTable;
                    grdAttachments.DataBind();
                }
                else
                {
                    grdAttachments.DataSource = null;
                    grdAttachments.DataBind();
                }
            }
            else
            {
                grdAttachments.DataSource = null;
                grdAttachments.DataBind();
            }
        }

        public DataTable BOInsertColumn(string columnName, string columnValue, DataTable dtableData)
        {
            /*  Create new DataTable if dtableData is null  */
            if (dtableData == null)
            {
                dtableData = new DataTable();
                //dtableData.Rows.Add(dtableData.NewRow());   /*  Because First Row is Empty row for all DataTables - will be deleted while 'InsertData'   */
            }

            if (dtableData.Rows.Count < 1)
            {
                //dtableData.Rows.Add(dtableData.NewRow());
                //goto addRow; 
            }

            /*  Check if column already exist   */
            if (!dtableData.Columns.Contains(columnName))
            { dtableData.Columns.Add(new DataColumn(columnName)); }

            /*  Set the columnValue to all Rows if columnValue is not NULL  */
            if (columnValue != null)
            {
                try
                {
                    foreach (DataRow drData in dtableData.Rows)
                    {
                        drData[columnName] = columnValue;
                    }
                }
                catch (Exception)
                { dtableData = null; }
            }

            return dtableData;
        }

        protected void lbdeleteFile_Click(object sender, EventArgs e)
        {
            try
            {
                GridViewRow row = (sender as LinkButton).NamingContainer as GridViewRow;
                Label lblFilePath = (Label)row.FindControl("lblFilePath") as Label;
                //Label lblID = (Label)row.FindControl("lblID") as Label;
                Label lblRowIndex = (Label)row.FindControl("lblRowIndex") as Label;
                GridView grdAttachments = ((GridView)grdAssessment.Rows[(Convert.ToInt32(lblRowIndex.Text.Trim())) - 1].FindControl("grdAttachments"));
                //Label lblRowID = (Label)grdAssessment.Rows[(Convert.ToInt32(lblRowIndex.Text.Trim()))].FindControl("lblRowID");
                Label lblRowID = (Label)grdAssessment.Rows[(Convert.ToInt32(lblRowIndex.Text.Trim())) - 1].FindControl("lblRowID");

                DataTable dtAttachment = (DataTable)Page.Session[AttachmentVar.Attachment + lblRowID.Text.Trim()];
                // DataTable dtAttachment = (DataTable)Page.Session[AttachmentVar.Attachment + lblRowIndex.Text.Trim()];
                int pageID = (Convert.ToInt32(lblRowID.Text));
                lblPageId.Text = Convert.ToString(pageID);
                #region Delete the file

                if (dtAttachment != null)
                {
                    if (grdAssessment != null)
                    {
                        grdAssessment.HeaderRow.TableSection = TableRowSection.TableHeader;
                    }

                    for (int i = 1; i <= dtAttachment.Rows.Count; i++)
                    {
                        if (i == (Convert.ToInt32(row.RowIndex) + 1))
                        {
                            #region Get File Information From Datatable
                            string[] AFilePath = Convert.ToString(dtAttachment.Rows[i - 1][AttachmentVar.FilePath]).Split('|');
                            string[] AOperationalStatus = Convert.ToString(dtAttachment.Rows[i - 1][AttachmentVar.OperationalStatus]).Split('|');
                            #endregion

                            string FilePath = string.Empty, OperationalStatus = string.Empty;
                            for (int j = 0; j < AOperationalStatus.Length - 1; j++)
                            {
                                #region Change the File Operational Status Based on the File Type
                                if (AFilePath[j].Equals(lblFilePath.Text))
                                {
                                    if (AOperationalStatus[j].Equals("New"))
                                    {
                                        OperationalStatus += "Delete" + "|";
                                    }
                                    else if (AOperationalStatus[j].Equals("Update"))
                                    {
                                        OperationalStatus += "TempDelete" + "|";
                                    }
                                    else
                                    {
                                        OperationalStatus += AOperationalStatus[j] + "|";
                                    }
                                }
                                else
                                {
                                    OperationalStatus += AOperationalStatus[j] + "|";
                                }
                                #endregion
                            }

                            if (AOperationalStatus[0].Equals("Update"))
                            {
                                OperationalStatus += "TempDelete" + "|";
                                dtAttachment.Rows[i - 1][AttachmentVar.OperationalStatus] = OperationalStatus;
                            }
                            else
                            {
                                if (grdAttachments.Rows.Count == 1) // This is to delete attach if there are more than 1
                                {
                                    if (Convert.ToString(dtAttachment.Rows[dtAttachment.Rows.Count - 1][AttachmentVar.OperationalStatus]).Equals("Update") || Convert.ToString(dtAttachment.Rows[dtAttachment.Rows.Count - 1][AttachmentVar.OperationalStatus]).Equals("New"))
                                    {
                                        dtAttachment.Rows[dtAttachment.Rows.Count - 1][AttachmentVar.OperationalStatus] = "TempDelete" + "|";
                                    }
                                }
                                else
                                {
                                    dtAttachment.Rows[i - 1][AttachmentVar.OperationalStatus] = OperationalStatus;
                                    dtAttachment.Rows[i - 1].Delete();
                                }
                            }

                            //if (row.RowIndex == 0)
                            //{
                            //    //dtAttachment.Rows[dtAttachment.Rows.Count][AttachmentVar.OperationalStatus] = OperationalStatus;
                            //}


                            //dtAttachment.Rows[i - 1].Delete();
                            break;
                        }
                    }
                }
                #endregion

                Page.Session[AttachmentVar.Attachment + lblRowID.Text.Trim()] = dtAttachment;

                FillAttachmentGrid(grdAttachments, dtAttachment);
            }
            catch (Exception ex)
            {
                string ErrorLog = ex.Message + "\n\n" + ex.StackTrace + "lbdeleteFile_Click";
                Common.ErrorLog(VED_WebService.SharePoint.Type.Error, "VEDAssessment : lbdeleteFile_Click", "", "", loginName, executionContext, ex, VED_WebService.SharePoint.RequestType.Portal);
                //  sbErrorMessage.AppendLine(ErrorLog);
            }

        }

        protected void grdAttachments_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            #region Attachment Logic

            //if (!string.IsNullOrEmpty(Convert.ToString(drCheckPoints[0]["FileName"])))
            //{
            //    GridView grdAttachments = ((GridView)e.Row.FindControl("grdAttachments"));
            //    processGridAttachment(Convert.ToInt32(lblRowIID.Text.Trim()), drCheckPoints[0], grdAttachments);
            //}

            #endregion
        }

        protected void grdAssessmentReadOnly_RowDataBound(object sender, GridViewRowEventArgs e)
        {

            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                bool isImageAvailable = Convert.ToBoolean(e.Row.Cells[5].Text);

                if (!isImageAvailable)
                {
                    LinkButton lnk = (LinkButton)e.Row.FindControl("lnkViewImage");
                    lnk.Visible = false;
                }
            }



        }

        protected void btnSave_Click(object sender, EventArgs e)
        {

            string request = "VEDID : " + HttpContext.Current.Request.QueryString["vedid"].ToString();
            ServiceResult<VEDScore> results = null;
            try
            {
                if (HttpContext.Current.Request.QueryString["vedid"].ToString() != string.Empty)
                {
                    List<AssesstmentDetails> details = new List<AssesstmentDetails>();
                    List<DTO.Image> images = new List<DTO.Image>();

                    foreach (GridViewRow row in grdAssessment.Rows)
                    {
                        AssesstmentDetails detail = new AssesstmentDetails();
                        detail.VEDScheduleID = Convert.ToInt32(HttpContext.Current.Request.QueryString["vedid"]); //Need to Get the same from  Query String
                        // detail.AssessmentDate = Convert.ToDateTime(DateTime.Now.ToString("MM/dd/yyyy h:mm"));
                        detail.AssessmentDoneBy = loginName;
                        detail.FacilityAreaID = Convert.ToInt32(((Label)row.FindControl("lblFacilityAreaID")).Text);
                        detail.FacilityDetailsID = Convert.ToInt32(((Label)row.FindControl("lblFacilityDetailsID")).Text);
                        detail.Condition = ((DropDownList)row.FindControl("ddlCondition")).SelectedValue;
                        detail.Comments = ((TextBox)row.FindControl("txtComments")).Text;
                        detail.CriticalityID = Convert.ToInt32(((Label)row.FindControl("lblCriticalityID")).Text);
                        detail.Criticality = ((Label)row.FindControl("lblCriticality")).Text;
                        //  detail.AssessmentType = AssessmentType.AreaLevel;
                        details.Add(detail);

                        //Saving the Images
                        Label lblRowID = (Label)row.FindControl("lblRowID");
                        Label lblCheckPointId = (Label)row.FindControl("lblIndex");
                        // int CheckPointID = Convert.ToInt32(lblCheckPointId.Text);
                        DataTable dtRowAttach = (DataTable)Page.Session[AttachmentVar.Attachment + lblRowID.Text.Trim()];


                        GridView grdAttachments = ((GridView)(row.FindControl("grdAttachments")));
                        if (dtRowAttach != null)
                        {
                            foreach (DataRow dr in dtRowAttach.Rows)
                            {
                                if (Convert.ToString(dr[AttachmentVar.OperationalStatus]).Equals("New"))
                                {
                                    DTO.Image image = new DTO.Image();
                                    string fileName = dr[AttachmentVar.FileName].ToString();
                                    string strFilepath = dr[AttachmentVar.FilePath].ToString();
                                    StreamReader sr = new StreamReader(strFilepath);
                                    Stream fStream = sr.BaseStream;
                                    byte[] contents;
                                    contents = new byte[fStream.Length];
                                    fStream.Read(contents, 0, (int)fStream.Length);
                                    fStream.Close();
                                    //listItem.Attachments.Add(fileName, contents);
                                    image.ImageName = fileName;
                                    image.ImageContent = Convert.ToBase64String(contents); //Encoding.ASCII.GetString(contents); //Encoding.UTF8.GetString(B);
                                    image.FacilityDetailsID = detail.FacilityDetailsID;
                                    image.VEDScheduleID = detail.VEDScheduleID;
                                    image.AssessmentDoneBy = loginName;
                                    images.Add(image);
                                }
                            }

                        }
                    }

                    if (Page.Request.QueryString["Type"] != null)
                    {
                        string assessmentType = Page.Request.QueryString["Type"].ToString();
                        if (assessmentType == "2")
                        {
                            results = BL.SaveAsessmentDetails_Web(details, executionContext, loginName, VED_WebService.SharePoint.RequestType.Portal, AssessmentType.StateLevel);

                        }
                        else if (assessmentType == "3")
                        {
                            results = BL.SaveAsessmentDetails_Web(details, executionContext, loginName, VED_WebService.SharePoint.RequestType.Portal, AssessmentType.ZoneLevel);
                        }
                        else
                        {
                            results = BL.SaveAsessmentDetails_Web(details, executionContext, loginName, VED_WebService.SharePoint.RequestType.Portal, AssessmentType.AreaLevel);
                        }
                    }
                    else
                    {
                        results = BL.SaveAsessmentDetails_Web(details, executionContext, loginName, VED_WebService.SharePoint.RequestType.Portal, AssessmentType.AreaLevel);
                    }
                    executionContext = results.ExecutionContext;
                    if (results.ErrorCode == "1")
                    {
                        ServiceResult imageResults = BL.UploadAssessmentImages_Web(images, executionContext, loginName, VED_WebService.SharePoint.RequestType.Portal);
                        executionContext = imageResults.ExecutionContext;
                    }

                    if (results.ErrorCode == "1")
                    {
                        //grdAssessment.Visible = false;
                        assessmentDiv.Visible = false;
                        vedScoreDiv.Visible = true;
                        vedScoreAssessmentDiv.Visible = false;
                        backDiv.Visible = true;
                        buttonDiv.Visible = false;
                        double totalCount = results.Data.Desirable + results.Data.Essential + results.Data.Vital;
                        lblDesirableCount.Text = results.Data.Desirable.ToString() + "(" + ((results.Data.Desirable / totalCount) * 100).ToString("#.##") + "%)";
                        lblEssentialCount.Text = results.Data.Essential.ToString() + "(" + ((results.Data.Essential / totalCount) * 100).ToString("#.##") + "%)";
                        lblVitalCount.Text = results.Data.Vital.ToString() + "(" + ((results.Data.Vital / totalCount) * 100).ToString("#.##") + "%)";
                        lblTotalCount.Text = totalCount.ToString();
                        lblVEDScore.Text = results.Data.VEDSCORE.ToString();
                        lblMaxVEDScore.Text = results.Data.MAXVEDSCORE.ToString();
                        lblPerVED.Text = ((results.Data.VEDSCORE / results.Data.MAXVEDSCORE) * 100).ToString("#.##") + "%";
                    }
                    else
                    {
                        Common.ErrorLog(VED_WebService.SharePoint.Type.Information, "VEDAssessment : btnSave_Click", request, JsonConvert.SerializeObject(results), loginName, executionContext, null, VED_WebService.SharePoint.RequestType.Portal);
                    }
                }
            }
            catch (Exception ex)
            {
                Common.ErrorLog(VED_WebService.SharePoint.Type.Information, "VEDAssessment : btnSave_Click", request, JsonConvert.SerializeObject(results), loginName, executionContext, null, VED_WebService.SharePoint.RequestType.Portal);
            }
            Page.Session.Clear();

        }

        //protected void btnDemoUpload_Click(object sender, EventArgs e)
        //{
        //    string connectionString = "Data Source=SP13DEVDB01;Initial Catalog=VEDDB;User Id=veduser;Password =pass@123";


        //    if (fileDemo.HasFile)
        //    {
        //        byte[] theImage = new byte[fileDemo.PostedFile.ContentLength];
        //        HttpPostedFile image = fileDemo.PostedFile;
        //        image.InputStream.Read(theImage, 0, (int)fileDemo.PostedFile.ContentLength);
        //        int length = theImage.Length;
        //        string type = fileDemo.PostedFile.ContentType;
        //        int size = fileDemo.PostedFile.ContentLength;
        //        string fileName = fileDemo.FileName.ToString();


        //        using (SqlConnection conn = new SqlConnection(connectionString))
        //        {
        //            conn.Open();
        //            SqlCommand cmd = new SqlCommand();
        //            cmd.Connection = conn;
        //            cmd.CommandType = CommandType.StoredProcedure;
        //            cmd.CommandText = "usp_InsertUpdateAssessmentImages_1";

        //            SqlParameter[] param = new SqlParameter[4];
        //            param[0] = new SqlParameter("@VEDScheduleID", SqlDbType.Int);
        //            param[0].Value = 1;
        //            param[1] = new SqlParameter("@FacilityDetailID", SqlDbType.Int);
        //            param[1].Value = 1;
        //            param[2] = new SqlParameter("@Image", SqlDbType.Image);
        //            param[2].Value = theImage;
        //            param[3] = new SqlParameter("@ImageName", SqlDbType.VarChar, 500);
        //            param[3].Value = fileName;
        //            cmd.Parameters.AddRange(param);
        //            int rowsAffected = cmd.ExecuteNonQuery();
        //        }


        //    }

        //}

        protected void grdAssessment_DataBound(object sender, EventArgs e)
        {
            //GridViewRow row = new GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Normal);
            //TableHeaderCell cell = new TableHeaderCell();
            //cell.Text = "";
            //cell.ColumnSpan = 2;
            //row.Controls.Add(cell);

            //cell = new TableHeaderCell();
            //cell.ColumnSpan = 2;
            //cell.Text = "Facility";
            //row.Controls.Add(cell);

            //cell = new TableHeaderCell();
            //cell.ColumnSpan = 1;
            //cell.Text = "Points";
            //row.Controls.Add(cell);

            //cell = new TableHeaderCell();
            //cell.ColumnSpan = 2;
            //cell.Text = "";
            //row.Controls.Add(cell);
            //grdAssessment.HeaderRow.Parent.Controls.AddAt(0, row);
            for (int i = grdAssessment.Rows.Count - 1; i > 0; i--)
            {
                GridViewRow row1 = grdAssessment.Rows[i];
                GridViewRow previousRow = grdAssessment.Rows[i - 1];
                //for (int j = 0; j < row.Cells.Count; j++)
                //{
                int j = 1;
                if (row1.Cells[1].Text == previousRow.Cells[1].Text)
                {
                    if (previousRow.Cells[j].RowSpan == 0)
                    {
                        if (row1.Cells[j].RowSpan == 0)
                        {
                            previousRow.Cells[j].RowSpan += 2;
                        }
                        else
                        {
                            previousRow.Cells[j].RowSpan = row1.Cells[j].RowSpan + 1;
                        }
                        row1.Cells[j].Visible = false;
                    }
                }
                //}
            }
        }

        protected void grdAssessmentReadOnly_DataBound(object sender, EventArgs e)
        {
            for (int i = grdAssessmentReadOnly.Rows.Count - 1; i > 0; i--)
            {
                GridViewRow row1 = grdAssessmentReadOnly.Rows[i];
                GridViewRow previousRow = grdAssessmentReadOnly.Rows[i - 1];
                //for (int j = 0; j < row.Cells.Count; j++)
                //{
                int j = 0;
                if (row1.Cells[0].Text == previousRow.Cells[0].Text)
                {
                    if (previousRow.Cells[j].RowSpan == 0)
                    {
                        if (row1.Cells[j].RowSpan == 0)
                        {
                            previousRow.Cells[j].RowSpan += 2;
                        }
                        else
                        {
                            previousRow.Cells[j].RowSpan = row1.Cells[j].RowSpan + 1;
                        }
                        row1.Cells[j].Visible = false;
                    }
                }
                //}
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            Page.Response.Redirect("/sites/rcs/jcved/pages/Create-schedule.aspx", true);
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {

            if (Page.Request.QueryString["Type"] != null)
            {
                if (Page.Request.QueryString["Type"].ToString() == "2" || Page.Request.QueryString["Type"].ToString() == "3")
                {
                    Page.Response.Redirect("/sites/rcs/jcved/pages/VED-Schedule-Management.aspx", true);
                }
                else
                {
                    Page.Response.Redirect("/sites/rcs/jcved/pages/Create-schedule.aspx", true);
                }
            }
            else
            {

                Page.Response.Redirect("/sites/rcs/jcved/pages/home.aspx", true);
            }
        }

        protected void grdCentersDetails_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdCentersDetails.PageIndex = e.NewPageIndex;
            List<VEDFinalData> finalData = (List<VEDFinalData>)ViewState["VEDSchedules"];
            grdCentersDetails.DataSource = finalData.ToList();
            grdCentersDetails.DataBind();

        }

        protected void btnExportToExcel_Click(object sender, EventArgs e)
        {
            string[] arr = null;
            arr = new string[1];
            arr[0] = "VEDScheduledID=" + HttpContext.Current.Request.QueryString["vedid"].ToString();
            ServiceResult<Generic> results = BL.GenericMethod("usp_GetAssessmentDetailsByVEDSchedulesID", executionContext, loginName, VED_WebService.SharePoint.RequestType.Portal, arr);
            DataSet ds = JsonConvert.DeserializeObject<DataSet>(results.Data.ResultData);
            //usp_Report_GetImages
            DataTable dt = ds.Tables[0];
            DataTable dt1 = ds.Tables[1];
            //dt.Columns.Remove("FacilityID");
            //dt.Columns.Remove("IsImageAvailable");
            //dt.Columns.Remove("VEDScheduleID");
            string strHtmlTable = "";

            //////HttpContext.Current.Response.Write("<Table border='1' bgColor='#ffffff' " +
            //////  "borderColor='#000000' cellSpacing='0' cellPadding='0' " +
            //////  "style='font-size:10.0pt; font-family:Calibri; background:white;'> <TR>");


            strHtmlTable = "<Table border='1' bgColor='#ffffff' " +
              "borderColor='#000000' cellSpacing='0' cellPadding='0' " +
              "style='font-size:10.0pt; font-family:Calibri; background:white;'>";
            strHtmlTable += "<tr><th>FacilityArea</th><th>FaciltyDetails</th><th>Criticality</th><th>Condition</th><th>Comments</th><th>Images</th></tr>";
            string siteURL = Convert.ToString(ConfigurationManager.AppSettings["siteURL"]);
            foreach (DataRow row in dt.Rows)
            {
                strHtmlTable += "<tr>";
                for (int i = 0; i < dt.Columns.Count; i++)
                {

                    if (i == 5)
                    {
                        strHtmlTable += "<td>";
                        bool isImageAvailable = Convert.ToBoolean(row[i]);
                        if (isImageAvailable)
                        {
                            strHtmlTable += "<a href=" + this.Page.Request.Url + "/Pages/view-images.aspx?VEDID=" + row[7].ToString() + "&facilityAreaID=" + row[6].ToString() + ">ViewImages</a>";//
                        }
                        else
                        {
                            strHtmlTable += "No Images";
                        }
                        strHtmlTable += "</td>";

                    }
                    else if (i == 6 || i == 7)
                    {
                        continue;
                    }
                    else
                    {
                        strHtmlTable += "<td>";
                        strHtmlTable += row[i].ToString();
                        strHtmlTable += "</td>";
                    }

                }
            }

            strHtmlTable += "</tr>";
            //strHtmlTable += "<tr><td><a href='http://sp13devwfe01:19999/_LAYOUTS/15/VEDHandler/image.ashx?ID=14'>ViewImages</a></td></tr>";
            strHtmlTable += "</table>";
            strHtmlTable += "<BR><BR><BR>";
            strHtmlTable += "<Table border='1' bgColor='#ffffff' " +
         "borderColor='#000000' cellSpacing='0' cellPadding='0' " +
         "style='font-size:10.0pt; font-family:Calibri; background:white;'>";


            strHtmlTable += "<tr><th>ScheduledOn</th><th>ScheduledBy</th><th>ActualAssesstmentDate</th><th>Center</th><th>Zone</th>";
            strHtmlTable += "<th>City</th><th>OfficeType</th><th>VitalCount</th><th>EssentialCount</th>";
            strHtmlTable += "<th>DesirableCount</th><th>VitalNotApplicable</th><th>EssentialNotApplicable</th><th>DesirableNotApplicable</th><th>TotalVEDByType</th><th>VEDScore</th>";
            strHtmlTable += "<th>MAXVEDScore</th><th>VEDPerScore</th></tr>";

            foreach (DataRow row in dt1.Rows)
            {//write in new row
                strHtmlTable += "<tr>";
                for (int i = 0; i < dt1.Columns.Count; i++)
                {
                    strHtmlTable += "<td>";
                    strHtmlTable += row[i].ToString();
                    strHtmlTable += "</td>";
                }
            }
            strHtmlTable += "</tr>";
            //strHtmlTable += "<tr><td><a href='http://sp13devwfe01:19999/_LAYOUTS/15/VEDHandler/image.ashx?ID=14'>ViewImages</a></td></tr>";
            strHtmlTable += "</table>";
            string centerName = "JCVEDReport";
            if (dt1.Rows.Count > 0)
            {
                DataRow row1 = dt1.Rows[0];
                centerName = row1["Center"].ToString();
            }
            string fileName = centerName + "_" + DateTime.Now.Day + "_" + DateTime.Now.Month + "_" + DateTime.Now.Year + ".xls";
            this.Page.Response.AppendHeader("content-disposition", "attachment;filename=" + fileName + "");
            this.Page.Response.Charset = "";
            this.Page.Response.Cache.SetCacheability(HttpCacheability.NoCache);
            this.Page.Response.ContentType = "application/vnd.ms-excel";
            this.EnableViewState = false;
            this.Page.Response.Write(strHtmlTable);
            this.Page.Response.End();


            //////string[] arr = null;
            //////arr = new string[1];
            //////arr[0] = "VEDScheduledID=" + HttpContext.Current.Request.QueryString["vedid"].ToString();
            //////ServiceResult<Generic> results = BL.GenericMethod("usp_GetAssessmentDetailsByVEDSchedulesID", executionContext, loginName, VED_WebService.SharePoint.RequestType.Portal, arr);
            //////DataSet ds = JsonConvert.DeserializeObject<DataSet>(results.Data.ResultData);
            ////////usp_Report_GetImages
            //////DataTable dt = ds.Tables[0];
            //////DataTable dt1 = ds.Tables[1];
            //////dt.Columns.Remove("FacilityID");
            //////dt.Columns.Remove("IsImageAvailable");
            //////dt.Columns.Remove("VEDScheduleID");
            //////HttpContext.Current.Response.Clear();
            //////HttpContext.Current.Response.ClearContent();
            //////HttpContext.Current.Response.ClearHeaders();
            //////HttpContext.Current.Response.Buffer = true;
            //////HttpContext.Current.Response.ContentType = "application/ms-excel";
            //////HttpContext.Current.Response.Write(@"<!DOCTYPE HTML PUBLIC ""-//W3C//DTD HTML 4.0 Transitional//EN"">");
            //////HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment;filename=Reports.xls");

            //////HttpContext.Current.Response.Charset = "utf-8";
            //////HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.GetEncoding("windows-1250");
            ////////sets font
            //////HttpContext.Current.Response.Write("<font style='font-size:10.0pt; font-family:Calibri;'>");
            //////HttpContext.Current.Response.Write("<BR><BR><BR>");
            ////////sets the table border, cell spacing, border color, font of the text, background, foreground, font height
            //////HttpContext.Current.Response.Write("<Table border='1' bgColor='#ffffff' " +
            //////  "borderColor='#000000' cellSpacing='0' cellPadding='0' " +
            //////  "style='font-size:10.0pt; font-family:Calibri; background:white;'> <TR>");
            ////////am getting my grid's column headers
            ////////  int columnscount = GridView_Result.Columns.Count;

            //////foreach (DataColumn dc in dt.Columns)
            //////{
            //////    //Page.Response.Write(tab + dc.ColumnName);
            //////    //tab = "\t";

            //////    HttpContext.Current.Response.Write("<Td>");
            //////    //Get column headers  and make it as bold in excel columns
            //////    HttpContext.Current.Response.Write("<B>");
            //////    HttpContext.Current.Response.Write(dc.ColumnName);
            //////    HttpContext.Current.Response.Write("</B>");
            //////    HttpContext.Current.Response.Write("</Td>");
            //////}


            ////////for (int j = 0; j < columnscount; j++)
            ////////{      //write in new column
            ////////    HttpContext.Current.Response.Write("<Td>");
            ////////    //Get column headers  and make it as bold in excel columns
            ////////    HttpContext.Current.Response.Write("<B>");
            ////////    HttpContext.Current.Response.Write(GridView_Result.Columns[j].HeaderText.ToString());
            ////////    HttpContext.Current.Response.Write("</B>");
            ////////    HttpContext.Current.Response.Write("</Td>");
            ////////}
            //////HttpContext.Current.Response.Write("</TR>");
            //////foreach (DataRow row in dt.Rows)
            //////{//write in new row
            //////    HttpContext.Current.Response.Write("<TR>");
            //////    for (int i = 0; i < dt.Columns.Count; i++)
            //////    {
            //////        HttpContext.Current.Response.Write("<Td>");
            //////        if (i == 5)
            //////        {
            //////            HttpContext.Current.Response.Write(GetHyperlink(row[i].ToString()));
            //////        }
            //////        else
            //////        {
            //////            HttpContext.Current.Response.Write(row[i].ToString());
            //////        }



            //////        HttpContext.Current.Response.Write("</Td>");
            //////    }

            //////    HttpContext.Current.Response.Write("</TR>");
            //////}
            //////HttpContext.Current.Response.Write("</Table>");


            //////HttpContext.Current.Response.Write("<BR><BR><BR>");
            ////////sets the table border, cell spacing, border color, font of the text, background, foreground, font height
            //////HttpContext.Current.Response.Write("<Table border='1' bgColor='#ffffff' " +
            //////  "borderColor='#000000' cellSpacing='0' cellPadding='0' " +
            //////  "style='font-size:10.0pt; font-family:Calibri; background:white;'> <TR>");

            //////foreach (DataColumn dc in dt1.Columns)
            //////{
            //////    //Page.Response.Write(tab + dc.ColumnName);
            //////    //tab = "\t";

            //////    HttpContext.Current.Response.Write("<Td>");
            //////    //Get column headers  and make it as bold in excel columns
            //////    HttpContext.Current.Response.Write("<B>");
            //////    HttpContext.Current.Response.Write(dc.ColumnName);
            //////    HttpContext.Current.Response.Write("</B>");
            //////    HttpContext.Current.Response.Write("</Td>");
            //////}


            ////////for (int j = 0; j < columnscount; j++)
            ////////{      //write in new column
            ////////    HttpContext.Current.Response.Write("<Td>");
            ////////    //Get column headers  and make it as bold in excel columns
            ////////    HttpContext.Current.Response.Write("<B>");
            ////////    HttpContext.Current.Response.Write(GridView_Result.Columns[j].HeaderText.ToString());
            ////////    HttpContext.Current.Response.Write("</B>");
            ////////    HttpContext.Current.Response.Write("</Td>");
            ////////}
            //////HttpContext.Current.Response.Write("</TR>");
            //////foreach (DataRow row in dt1.Rows)
            //////{//write in new row
            //////    HttpContext.Current.Response.Write("<TR>");
            //////    for (int i = 0; i < dt1.Columns.Count; i++)
            //////    {
            //////        HttpContext.Current.Response.Write("<Td>");
            //////        HttpContext.Current.Response.Write(row[i].ToString());
            //////        HttpContext.Current.Response.Write("</Td>");
            //////    }

            //////    HttpContext.Current.Response.Write("</TR>");
            //////}
            //////HttpContext.Current.Response.Write("</Table>");




            //////HttpContext.Current.Response.Write("</font>");
            //////HttpContext.Current.Response.Flush();
            //////HttpContext.Current.Response.End();
        }

        private string GetHyperlink(string p)
        {
            string returnAnch = string.Empty;
            returnAnch = "<table   class='ReportTable'   id='tblVEDReport' runat='server' visible='false'>";
            returnAnch += "<tr><th>Links</th></tr>";
            returnAnch += "<tr>";

            if (!string.IsNullOrEmpty(p))
            {
                string[] arr = p.Split(',');

                for (int i = 0; i < arr.Length; i++)
                {
                    returnAnch += "<td><a href='" + arr[i].Trim() + "'>ViewImages</a></td>";

                }
                returnAnch += "</tr>";
                returnAnch += "</table>";

            }
            return returnAnch;
        }

    }
}



