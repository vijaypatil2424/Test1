﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VED_WebService.SharePoint.BusinessLayer;
using VED_WebService.SharePoint.DTO;
using DTO = VED_WebService.SharePoint.DTO;

namespace Demo.WebSite.ASPX
{
    public partial class Demo : System.Web.UI.Page
    {
        Business BL = null;
        protected void Page_Load(object sender, EventArgs e)
        {
            double a = 93.2124234234;

            Math.Round(a, 2); //returns 1.99

            double b = 93.996577567;

          //  Math.Round(b, 2); //returns 2.00
            //You might also want to look at bankers rounding / round-to-even with the following overload:

           double c=  Math.Round(a, 2, MidpointRounding.ToEven);
          double d=  Math.Round(b, 2, MidpointRounding.ToEven);
            ////    string officeTypeID = string.Empty;
            ////    if (HttpContext.Current.Request.QueryString["vedid"] != null)
            ////    {
            ////        if (HttpContext.Current.Request.QueryString["vedid"].ToString() != string.Empty)
            ////        {
            ////            string scheduleID = Convert.ToString(HttpContext.Current.Request.QueryString["vedid"]);
            ////            BL = new Business();

            ////            ServiceResult<List<DTO.Image>> results = BL.GetImagesBasedOnVEDID("93", "1", "", "", VED_WebService.SharePoint.RequestType.Portal);



            ////            //string[] array = new string[1];
            ////            //array[0] = "VEDScheduledID=93";


            ////            //ServiceResult<VEDSchedule> scheduleDetail = BL.GetScheduledVEDDetailsByID(scheduleID, "", "");
            ////            //lblScheduleDate.Text = scheduleDetail.Data.ScheduledOn;
            ////            //officeTypeID = scheduleDetail.Data.OfficeTypeID.ToString();
            ////            //lblActualDate.Text = DateTime.Now.ToString("dd-MMM-yyyy");
            ////            //Page.Form.Attributes.Add("enctype", "multipart/form-data");
            ////            //if (!Page.IsPostBack)
            ////            //{

            ////            //    ServiceResult<FinalAssessmentData> result = BL.GetAssessmentDetails("93", "", "", VED_WebService.SharePoint.RequestType.Portal);
            ////            //    if (result.Data != null)
            ////            //    {
            ////            //        grdAssessment.Visible = false;
            ////            //        grdCentersDetails.DataSource = result.Data.VEDFinalData;
            ////            //        grdCentersDetails.DataBind();

            ////            //        grdAssessmentReadOnly.Visible = true;
            ////            //        grdAssessmentReadOnly.DataSource = result.Data.AssesstmentDetails;
            ////            //        grdAssessmentReadOnly.DataBind();
            ////            //    }
            ////            //    else
            ////            //    {
            ////            //        grdAssessmentReadOnly.Visible = false;
            ////            //        FacilityAreaDetailsMaster(officeTypeID, scheduleID);

            ////            //    }

            ////            //}
            ////            ////AddAttachment(postedFile, dt, Convert.ToString(lblRowID.Text.Trim()));
            ////        }
            ////        else
            ////        {
            ////            //Page Level Error;
            ////        }
            ////    }
        }

        private void test(params string[] arr)
        {

        }


        private void FacilityAreaDetailsMaster(string centerTypeID, string VEDScheduleID)
        {
            ServiceResult<Facility> result = BL.GetFaciltyAreaDetailsMasters(centerTypeID, VEDScheduleID, "", "sachin7.jain");
            //List<ScoringMaster> scMaster = result.Data.ScoringMaster;
            //ViewState["ScoringMaster"] = scMaster;
            grdAssessment.DataSource = result.Data.FacilityMaster;
            grdAssessment.DataBind();

            grdCentersDetails.DataSource = result.Data.VEDSchedules;
            grdCentersDetails.DataBind();

        }

        //protected void grdAssessment_DataBound(object sender, EventArgs e)
        //{


        //    GridViewRow row = new GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Normal);
        //    TableHeaderCell cell = new TableHeaderCell();
        //    cell.Text = "";
        //    cell.ColumnSpan = 2;
        //    row.Controls.Add(cell);

        //    cell = new TableHeaderCell();
        //    cell.ColumnSpan = 2;
        //    cell.Text = "Facility";
        //    row.Controls.Add(cell);

        //    cell = new TableHeaderCell();
        //    cell.ColumnSpan = 1;
        //    cell.Text = "Points";
        //    row.Controls.Add(cell);

        //    cell = new TableHeaderCell();
        //    cell.ColumnSpan = 2;
        //    cell.Text = "";
        //    row.Controls.Add(cell);
        //    grdAssessment.HeaderRow.Parent.Controls.AddAt(0, row);
        //}

        //protected void grdAssessment_RowDataBound(object sender, GridViewRowEventArgs e)
        //{
        //    if (e.Row.RowType == DataControlRowType.DataRow)
        //    {
        //        //string critricalityType = e.Row.Cells[2].Text;
        //        //DropDownList ddl = (DropDownList)e.Row.FindControl("ddlCondition");
        //        //List<ScoringMaster> scMasters = (List<ScoringMaster>)ViewState["ScoringMaster"];
        //        //ScoringMaster scMaster = scMasters.Where(t => t.Criticality == critricalityType).FirstOrDefault();
        //        //List<CommonDDL> ddlColl = new List<CommonDDL>();




        //        //CommonDDL obj = new CommonDDL();
        //    }
        ////}

        protected void btnUploadFile_Click(object sender, EventArgs e)
        {
            GridViewRow row = (sender as Button).NamingContainer as GridViewRow;
            FileUpload flInsertFile = ((FileUpload)row.FindControl("flInsertFile"));
            Label errormsg = ((Label)row.FindControl("errormsg"));
            string lblPoint = ((Label)row.FindControl("lblPoint")).Text;
            GridView grdAttachments = ((GridView)row.FindControl("grdAttachments"));
            Label lblRowID = (Label)row.FindControl("lblRowID");
            int pageID = (Convert.ToInt32(row.RowIndex));
            lblPageId.Text = Convert.ToString(pageID);
            try
            {

                string Result = string.Empty;
                errormsg.Text = string.Empty;
                if (flInsertFile.HasFile)
                {


                    DataTable dt = (DataTable)Page.Session[AttachmentVar.Attachment + lblRowID.Text.Trim()];

                    if (dt == null)
                    {
                        if (flInsertFile.PostedFiles.Count <= 3)
                        {
                            dt = createAttachmentTable();
                        }
                        else
                        {
                            errormsg.Text = "Only three files are allowed to upload";
                            goto end;
                        }
                    }
                    if (dt.Rows.Count <= 3)
                    {
                        int fileCount = dt.Rows.Count;
                        foreach (HttpPostedFile postedFile in flInsertFile.PostedFiles)
                        {

                            double fileSize = (postedFile.ContentLength / 1024) / 1000;
                            if (fileSize > 3)
                            {
                                errormsg.Text = "Error file uploading file : " + postedFile.FileName + "Maximum file size allowed is 3 M.B";
                                goto end;
                            }
                            else
                            {
                                string FileName = new FileInfo(postedFile.FileName).Name;
                                bool exists = dt.Select().ToList().Exists(dtrow => Convert.ToString(dtrow["FileName"]) == Convert.ToString(FileName));
                                if (exists)
                                {
                                    ScriptManager.RegisterStartupScript(this.Page, GetType(), "script", "alert('Attached File Name is same. Please try Another Name and Upload'); ", true);

                                }
                                else
                                {
                                    if (fileCount >= 3)
                                    {
                                        errormsg.Text = "Only three files are allowed to upload";
                                        goto end;
                                    }
                                    else
                                    {
                                        dt = AddAttachment(postedFile, dt, Convert.ToString(lblRowID.Text.Trim()));
                                        fileCount += 1;
                                    }
                                }
                            }

                        }

                        Page.Session[AttachmentVar.Attachment + lblRowID.Text.Trim()] = dt;

                        if (dt != null)
                        {
                            FillAttachmentGrid(grdAttachments, dt);
                            if (grdAssessment != null)
                            {
                                grdAssessment.HeaderRow.TableSection = TableRowSection.TableHeader;
                            }
                        }
                        else
                        {
                            grdAttachments.DataSource = createAttachmentTable();
                            grdAttachments.DataBind();
                            errormsg.Text = Result;
                        }

                    }
                    else
                    {
                        errormsg.Text = "Only three files are allowed to upload";
                        goto end;
                    }
                end:
                    return;
                }
                else
                {
                    errormsg.Text = "Select the File.";
                }
            }
            catch (Exception ex)
            {
                string ErrorLog = ex.Message + "\n\n" + ex.StackTrace + "btnUploadFile_Click";
                //  sbErrorMessage.AppendLine(ErrorLog);
            }
        }

        private DataTable createAttachmentTable()
        {
            DataTable dtableAttachmentArray = null;

            dtableAttachmentArray = BOInsertColumn(AttachmentVar.FileName, null, dtableAttachmentArray); //  Adding FileName column manually, because its a custom column
            dtableAttachmentArray = BOInsertColumn(AttachmentVar.FileGUID, null, dtableAttachmentArray);  //  Adding FileGUID column manually, because its a custom column
            dtableAttachmentArray = BOInsertColumn(AttachmentVar.FilePath, null, dtableAttachmentArray);   //  Adding FilePath column manually, because its a custom column
            dtableAttachmentArray = BOInsertColumn(AttachmentVar.FileDelete, null, dtableAttachmentArray); //  Adding FileContents column manually, because its a custom column
            dtableAttachmentArray = BOInsertColumn(AttachmentVar.ID, null, dtableAttachmentArray); //  Adding FileContents column manually, because its a custom column
            dtableAttachmentArray = BOInsertColumn(AttachmentVar.RowIndex, null, dtableAttachmentArray); //  Adding FileContents column manually, because its a custom column
            dtableAttachmentArray = BOInsertColumn(AttachmentVar.OperationalStatus, null, dtableAttachmentArray); //  Adding FileContents column manually, because its a custom column

            return dtableAttachmentArray;
        }

        private DataTable addAttachment(DataTable dtableAttachmentArray)
        {
            string pageUniqueDt = Convert.ToString(ViewState["pageUniqueDt"]);

            if (dtableAttachmentArray == null)
            {
                dtableAttachmentArray = createAttachmentTable();
            }

            if (!string.IsNullOrEmpty(Convert.ToString(Page.Session[AttachmentVar.FileName + pageUniqueDt])))
            {
                DataRow drAttachments = dtableAttachmentArray.NewRow();
                drAttachments[AttachmentVar.FileName] = Convert.ToString(Page.Session[AttachmentVar.FileName + pageUniqueDt]);
                drAttachments[AttachmentVar.FilePath] = Convert.ToString(Page.Session[AttachmentVar.FilePath + pageUniqueDt]);
                drAttachments[AttachmentVar.FileGUID] = Convert.ToString(Page.Session[AttachmentVar.FileGUID + pageUniqueDt]);

                dtableAttachmentArray.Rows.Add(drAttachments);
            }
            /// --- Removing Page.Session --- ///
            Page.Session[AttachmentVar.FileName + pageUniqueDt] = string.Empty;
            Page.Session[AttachmentVar.FileGUID + pageUniqueDt] = string.Empty;
            Page.Session[AttachmentVar.FilePath + pageUniqueDt] = string.Empty;

            return dtableAttachmentArray;
        }

        public DataTable AddAttachment(HttpPostedFile flInsertFile, DataTable dt, string QueryStringRowIndex)
        {
            try
            {
                //SPUtility.ValidateFormDigest();
                //SPSecurity.RunWithElevatedPrivileges(delegate()
                //{
                Stream strmStream = flInsertFile.InputStream;
                Int32 intFileLength = (Int32)strmStream.Length;
                byte[] file = new byte[intFileLength + 1];
                strmStream.Read(file, 0, intFileLength);
                strmStream.Close();
                string FileName = new FileInfo(flInsertFile.FileName).Name;
                string GetTempFolder = Path.GetTempPath();
                string FilePath = GetTempFolder + DateTime.Now.ToString("yy_MM_dd_HH_mm_ss_fff_") + FileName;
                string Index = string.Empty;
                if (!System.IO.File.Exists(FilePath))
                {
                    File.WriteAllBytes(FilePath, file);
                }

                //foreach (DataRow drw in dt.Rows) 
                //{
                //    if (!string.IsNullOrEmpty(Convert.ToString(drw[AttachmentVar.Index]))) 
                //    {
                //        Index = Convert.ToString(drw[AttachmentVar.Index]);
                //        break;
                //    }
                //}
                DataRow dr = null;
                dr = dt.NewRow();
                dr[AttachmentVar.ID] = Convert.ToString(Guid.NewGuid());
                dr[AttachmentVar.OperationalStatus] = "New";
                dr[AttachmentVar.FileName] = FileName;
                dr[AttachmentVar.FilePath] = FilePath;
                dr[AttachmentVar.RowIndex] = QueryStringRowIndex;
                // dr[AttachmentVar.Index] = Index;
                //  dr["DeleteStatus"] = "0";
                dt.Rows.Add(dr);
                // reslt = string.Empty;

                try
                {
                    if (!System.IO.File.Exists(FilePath))
                    {
                        File.Delete(FilePath);
                    }
                }
                catch (Exception)
                {
                }

                //  });

            }

            catch (Exception)
            {
                return dt = null;
            }
            return dt;

        }

        private static void FillAttachmentGrid(GridView grdAttachments, DataTable dtableAttachmentArray)
        {
            if (dtableAttachmentArray.Rows.Count > 0)
            {
                DataTable AttachmentPPTable = dtableAttachmentArray;

                var GetPPDt = AttachmentPPTable.AsEnumerable()
                            .Where(r => r.Field<string>(AttachmentVar.OperationalStatus) != Convert.ToString("TempDelete")
                                && r.Field<string>(AttachmentVar.OperationalStatus) != Convert.ToString("TempDelete|")
                                && r.Field<string>(AttachmentVar.OperationalStatus) != Convert.ToString("Delete")
                                && !string.IsNullOrEmpty(r.Field<string>(AttachmentVar.OperationalStatus)));

                if (GetPPDt.Any())
                {
                    AttachmentPPTable = GetPPDt.CopyToDataTable();
                    grdAttachments.DataSource = AttachmentPPTable;
                    grdAttachments.DataBind();
                }
                else
                {
                    grdAttachments.DataSource = null;
                    grdAttachments.DataBind();
                }
            }
            else
            {
                grdAttachments.DataSource = null;
                grdAttachments.DataBind();
            }
        }

        public DataTable BOInsertColumn(string columnName, string columnValue, DataTable dtableData)
        {
            /*  Create new DataTable if dtableData is null  */
            if (dtableData == null)
            {
                dtableData = new DataTable();
                //dtableData.Rows.Add(dtableData.NewRow());   /*  Because First Row is Empty row for all DataTables - will be deleted while 'InsertData'   */
            }

            if (dtableData.Rows.Count < 1)
            {
                //dtableData.Rows.Add(dtableData.NewRow());
                //goto addRow; 
            }

            /*  Check if column already exist   */
            if (!dtableData.Columns.Contains(columnName))
            { dtableData.Columns.Add(new DataColumn(columnName)); }

            /*  Set the columnValue to all Rows if columnValue is not NULL  */
            if (columnValue != null)
            {
                try
                {
                    foreach (DataRow drData in dtableData.Rows)
                    {
                        drData[columnName] = columnValue;
                    }
                }
                catch (Exception)
                { dtableData = null; }
            }

            return dtableData;
        }

        protected void lbdeleteFile_Click(object sender, EventArgs e)
        {
            try
            {
                GridViewRow row = (sender as LinkButton).NamingContainer as GridViewRow;
                Label lblFilePath = (Label)row.FindControl("lblFilePath") as Label;
                //Label lblID = (Label)row.FindControl("lblID") as Label;
                Label lblRowIndex = (Label)row.FindControl("lblRowIndex") as Label;
                GridView grdAttachments = ((GridView)grdAssessment.Rows[(Convert.ToInt32(lblRowIndex.Text.Trim())) - 1].FindControl("grdAttachments"));
                //Label lblRowID = (Label)grdAssessment.Rows[(Convert.ToInt32(lblRowIndex.Text.Trim()))].FindControl("lblRowID");
                Label lblRowID = (Label)grdAssessment.Rows[(Convert.ToInt32(lblRowIndex.Text.Trim())) - 1].FindControl("lblRowID");

                DataTable dtAttachment = (DataTable)Page.Session[AttachmentVar.Attachment + lblRowID.Text.Trim()];
                // DataTable dtAttachment = (DataTable)Page.Session[AttachmentVar.Attachment + lblRowIndex.Text.Trim()];
                int pageID = (Convert.ToInt32(lblRowID.Text));
                lblPageId.Text = Convert.ToString(pageID);
                #region Delete the file

                if (dtAttachment != null)
                {
                    if (grdAssessment != null)
                    {
                        grdAssessment.HeaderRow.TableSection = TableRowSection.TableHeader;
                    }

                    for (int i = 1; i <= dtAttachment.Rows.Count; i++)
                    {
                        if (i == (Convert.ToInt32(row.RowIndex) + 1))
                        {
                            #region Get File Information From Datatable
                            string[] AFilePath = Convert.ToString(dtAttachment.Rows[i - 1][AttachmentVar.FilePath]).Split('|');
                            string[] AOperationalStatus = Convert.ToString(dtAttachment.Rows[i - 1][AttachmentVar.OperationalStatus]).Split('|');
                            #endregion

                            string FilePath = string.Empty, OperationalStatus = string.Empty;
                            for (int j = 0; j < AOperationalStatus.Length - 1; j++)
                            {
                                #region Change the File Operational Status Based on the File Type
                                if (AFilePath[j].Equals(lblFilePath.Text))
                                {
                                    if (AOperationalStatus[j].Equals("New"))
                                    {
                                        OperationalStatus += "Delete" + "|";
                                    }
                                    else if (AOperationalStatus[j].Equals("Update"))
                                    {
                                        OperationalStatus += "TempDelete" + "|";
                                    }
                                    else
                                    {
                                        OperationalStatus += AOperationalStatus[j] + "|";
                                    }
                                }
                                else
                                {
                                    OperationalStatus += AOperationalStatus[j] + "|";
                                }
                                #endregion
                            }

                            if (AOperationalStatus[0].Equals("Update"))
                            {
                                OperationalStatus += "TempDelete" + "|";
                                dtAttachment.Rows[i - 1][AttachmentVar.OperationalStatus] = OperationalStatus;
                            }
                            else
                            {
                                if (grdAttachments.Rows.Count == 1) // This is to delete attach if there are more than 1
                                {
                                    if (Convert.ToString(dtAttachment.Rows[dtAttachment.Rows.Count - 1][AttachmentVar.OperationalStatus]).Equals("Update") || Convert.ToString(dtAttachment.Rows[dtAttachment.Rows.Count - 1][AttachmentVar.OperationalStatus]).Equals("New"))
                                    {
                                        dtAttachment.Rows[dtAttachment.Rows.Count - 1][AttachmentVar.OperationalStatus] = "TempDelete" + "|";
                                    }
                                }
                                else
                                {
                                    dtAttachment.Rows[i - 1][AttachmentVar.OperationalStatus] = OperationalStatus;
                                    dtAttachment.Rows[i - 1].Delete();
                                }
                            }

                            //if (row.RowIndex == 0)
                            //{
                            //    //dtAttachment.Rows[dtAttachment.Rows.Count][AttachmentVar.OperationalStatus] = OperationalStatus;
                            //}


                            //dtAttachment.Rows[i - 1].Delete();
                            break;
                        }
                    }
                }
                #endregion

                Page.Session[AttachmentVar.Attachment + lblRowID.Text.Trim()] = dtAttachment;

                FillAttachmentGrid(grdAttachments, dtAttachment);
            }
            catch (Exception ex)
            {
                string ErrorLog = ex.Message + "\n\n" + ex.StackTrace + "lbdeleteFile_Click";
                //  sbErrorMessage.AppendLine(ErrorLog);
            }

        }

        protected void grdAttachments_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            #region Attachment Logic

            //if (!string.IsNullOrEmpty(Convert.ToString(drCheckPoints[0]["FileName"])))
            //{
            //    GridView grdAttachments = ((GridView)e.Row.FindControl("grdAttachments"));
            //    processGridAttachment(Convert.ToInt32(lblRowIID.Text.Trim()), drCheckPoints[0], grdAttachments);
            //}

            #endregion
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {

            if (Request.QueryString["vedid"].ToString() != string.Empty)
            {
                List<AssesstmentDetails> details = new List<AssesstmentDetails>();
                List<DTO.Image> images = new List<DTO.Image>();

                foreach (GridViewRow row in grdAssessment.Rows)
                {

                    // GridView grdAttachments = ((GridView)row.FindControl("grdAttachments"));

                    //Saving the attachment
                    AssesstmentDetails detail = new AssesstmentDetails();
                    detail.VEDScheduleID = Convert.ToInt32(Request.QueryString["vedid"]); //Need to Get the same from  Query String
                    detail.AssessmentDate = DateTime.Now;//Can be saved from Database
                    detail.AssessmentDoneBy = "sachin7.jain";//Loggedin User
                    detail.FacilityAreaID = Convert.ToInt32(((Label)row.FindControl("lblFacilityAreaID")).Text);
                    detail.FacilityDetailsID = Convert.ToInt32(((Label)row.FindControl("lblFacilityDetailsID")).Text);
                    detail.Condition = ((DropDownList)row.FindControl("ddlCondition")).SelectedValue;
                    detail.Comments = ((TextBox)row.FindControl("txtComments")).Text;
                    detail.CriticalityID = Convert.ToInt32(((Label)row.FindControl("lblCriticalityID")).Text);
                    detail.Criticality = ((Label)row.FindControl("lblCriticality")).Text;
                    details.Add(detail);

                    //Saving the Images
                    Label lblRowID = (Label)row.FindControl("lblRowID");
                    Label lblCheckPointId = (Label)row.FindControl("lblIndex");
                    // int CheckPointID = Convert.ToInt32(lblCheckPointId.Text);
                    DataTable dtRowAttach = (DataTable)Page.Session[AttachmentVar.Attachment + lblRowID.Text.Trim()];


                    GridView grdAttachments = ((GridView)(row.FindControl("grdAttachments")));
                    if (dtRowAttach != null)
                    {
                        foreach (DataRow dr in dtRowAttach.Rows)
                        {
                            if (Convert.ToString(dr[AttachmentVar.OperationalStatus]).Equals("New"))
                            {
                                DTO.Image image = new DTO.Image();
                                string fileName = dr[AttachmentVar.FileName].ToString();
                                string strFilepath = dr[AttachmentVar.FilePath].ToString();
                                StreamReader sr = new StreamReader(strFilepath);
                                Stream fStream = sr.BaseStream;
                                byte[] contents;
                                contents = new byte[fStream.Length];
                                fStream.Read(contents, 0, (int)fStream.Length);
                                fStream.Close();
                                //listItem.Attachments.Add(fileName, contents);
                                image.ImageName = fileName;
                                image.ImageContent = Encoding.ASCII.GetString(contents); //Encoding.UTF8.GetString(B);
                                image.FacilityDetailsID = detail.FacilityDetailsID;
                                image.VEDScheduleID = detail.VEDScheduleID;
                                image.AssessmentDoneBy = "sachin7.jain";
                                images.Add(image);
                            }
                        }

                    }
                }
                ServiceResult<VEDScore> results = BL.SaveAsessmentDetails_Web(details, "", "");
                if (results.ErrorCode == "1")
                {
                    ServiceResult imageResults = BL.UploadAssessmentImages_Web(images, "", "");
                }

                if (results.ErrorCode == "1")
                {
                    grdAssessment.Visible = false;
                    tblVEDScore.Visible = true;
                    double totalCount = results.Data.Desirable + results.Data.Essential + results.Data.Vital;
                    lblDesirableCount.Text = results.Data.Desirable.ToString() + "(" + ((results.Data.Desirable / totalCount) * 100).ToString("#.##") + "%)";
                    lblEssentialCount.Text = results.Data.Essential.ToString() + "(" + ((results.Data.Essential / totalCount) * 100).ToString("#.##") + "%)";
                    lblVitalCount.Text = results.Data.Vital.ToString() + "(" + ((results.Data.Vital / totalCount) * 100).ToString("#.##") + "%)";
                    lblTotalCount.Text = totalCount.ToString();
                    lblVEDScore.Text = results.Data.VEDSCORE.ToString();
                    lblMaxVEDScore.Text = results.Data.MAXVEDSCORE.ToString();
                    lblPerVED.Text = ((results.Data.VEDSCORE / results.Data.MAXVEDSCORE) * 100).ToString("#.##") + "%";
                }
                else
                {

                }





            }

        }

        //protected void btnDemoUpload_Click(object sender, EventArgs e)
        //{
        //    string connectionString = "Data Source=SP13DEVDB01;Initial Catalog=VEDDB;User Id=veduser;Password =pass@123";


        //    if (fileDemo.HasFile)
        //    {
        //        byte[] theImage = new byte[fileDemo.PostedFile.ContentLength];
        //        HttpPostedFile image = fileDemo.PostedFile;
        //        image.InputStream.Read(theImage, 0, (int)fileDemo.PostedFile.ContentLength);
        //        int length = theImage.Length;
        //        string type = fileDemo.PostedFile.ContentType;
        //        int size = fileDemo.PostedFile.ContentLength;
        //        string fileName = fileDemo.FileName.ToString();


        //        using (SqlConnection conn = new SqlConnection(connectionString))
        //        {
        //            conn.Open();
        //            SqlCommand cmd = new SqlCommand();
        //            cmd.Connection = conn;
        //            cmd.CommandType = CommandType.StoredProcedure;
        //            cmd.CommandText = "usp_InsertUpdateAssessmentImages_1";

        //            SqlParameter[] param = new SqlParameter[4];
        //            param[0] = new SqlParameter("@VEDScheduleID", SqlDbType.Int);
        //            param[0].Value = 1;
        //            param[1] = new SqlParameter("@FacilityDetailID", SqlDbType.Int);
        //            param[1].Value = 1;
        //            param[2] = new SqlParameter("@Image", SqlDbType.Image);
        //            param[2].Value = theImage;
        //            param[3] = new SqlParameter("@ImageName", SqlDbType.VarChar, 500);
        //            param[3].Value = fileName;
        //            cmd.Parameters.AddRange(param);
        //            int rowsAffected = cmd.ExecuteNonQuery();
        //        }


        //    }

        //}

        protected void grdAssessment_DataBound(object sender, EventArgs e)
        {
            //GridViewRow row = new GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Normal);
            //TableHeaderCell cell = new TableHeaderCell();
            //cell.Text = "";
            //cell.ColumnSpan = 2;
            //row.Controls.Add(cell);

            //cell = new TableHeaderCell();
            //cell.ColumnSpan = 2;
            //cell.Text = "Facility";
            //row.Controls.Add(cell);

            //cell = new TableHeaderCell();
            //cell.ColumnSpan = 1;
            //cell.Text = "Points";
            //row.Controls.Add(cell);

            //cell = new TableHeaderCell();
            //cell.ColumnSpan = 2;
            //cell.Text = "";
            //row.Controls.Add(cell);
            //grdAssessment.HeaderRow.Parent.Controls.AddAt(0, row);
            for (int i = grdAssessment.Rows.Count - 1; i > 0; i--)
            {
                GridViewRow row1 = grdAssessment.Rows[i];
                GridViewRow previousRow = grdAssessment.Rows[i - 1];
                //for (int j = 0; j < row.Cells.Count; j++)
                //{
                int j = 1;
                if (row1.Cells[1].Text == previousRow.Cells[1].Text)
                {
                    if (previousRow.Cells[j].RowSpan == 0)
                    {
                        if (row1.Cells[j].RowSpan == 0)
                        {
                            previousRow.Cells[j].RowSpan += 2;
                        }
                        else
                        {
                            previousRow.Cells[j].RowSpan = row1.Cells[j].RowSpan + 1;
                        }
                        row1.Cells[j].Visible = false;
                    }
                }
                //}
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {

        }

        protected void grdAssessmentReadOnly_DataBound(object sender, EventArgs e)
        {
            for (int i = grdAssessmentReadOnly.Rows.Count - 1; i > 0; i--)
            {
                GridViewRow row1 = grdAssessmentReadOnly.Rows[i];
                GridViewRow previousRow = grdAssessmentReadOnly.Rows[i - 1];
                //for (int j = 0; j < row.Cells.Count; j++)
                //{
                int j = 0;
                if (row1.Cells[0].Text == previousRow.Cells[0].Text)
                {
                    if (previousRow.Cells[j].RowSpan == 0)
                    {
                        if (row1.Cells[j].RowSpan == 0)
                        {
                            previousRow.Cells[j].RowSpan += 2;
                        }
                        else
                        {
                            previousRow.Cells[j].RowSpan = row1.Cells[j].RowSpan + 1;
                        }
                        row1.Cells[j].Visible = false;
                    }
                }
                //}
            }
        }

        protected void grdAssessmentReadOnly_RowDataBound(object sender, GridViewRowEventArgs e)
        {

            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                bool isImageAvailable = Convert.ToBoolean(e.Row.Cells[5].Text);

                if (!isImageAvailable)
                {
                    LinkButton lnk = (LinkButton)e.Row.FindControl("lnkViewImage");
                    lnk.Visible = false;
                }
            }



        }
        //protected void btnUpload_Click(object sender, EventArgs e)
        //{
        //    string connectionString = "Data Source=SP13DEVDB01;Initial Catalog=VEDDB;User Id=veduser;Password =pass@123";


        //    if (fileUpload.HasFile)
        //    {
        //        byte[] theImage = new byte[fileUpload.PostedFile.ContentLength];
        //        HttpPostedFile image = fileUpload.PostedFile;
        //        image.InputStream.Read(theImage, 0, (int)fileUpload.PostedFile.ContentLength);
        //        int length = theImage.Length;
        //        string type = fileUpload.PostedFile.ContentType;
        //        int size = fileUpload.PostedFile.ContentLength;
        //        string fileName = fileUpload.FileName.ToString();


        //        using (SqlConnection conn = new SqlConnection(connectionString))
        //        {
        //            conn.Open();
        //            SqlCommand cmd = new SqlCommand();
        //            cmd.Connection = conn;
        //            cmd.CommandType = CommandType.StoredProcedure;
        //            cmd.CommandText = "usp_InsertUpdateAssessmentImages";

        //            SqlParameter[] param = new SqlParameter[8];
        //            param[0] = new SqlParameter("@VEDScheduleID", SqlDbType.Int);
        //            param[0].Value = 1;
        //            param[1] = new SqlParameter("@FacilityDetailID", SqlDbType.Int);
        //            param[1].Value = 1;
        //            param[2] = new SqlParameter("@Image", SqlDbType.Image);
        //            param[2].Value = theImage;
        //            param[3] = new SqlParameter("@CreatedBy", SqlDbType.VarChar, 200);
        //            param[3].Value = "sachin7.jain";
        //            param[4] = new SqlParameter("@Type", SqlDbType.VarChar);
        //            param[4].Value = "Add";
        //            param[5] = new SqlParameter("@ImageType", SqlDbType.NVarChar, 100);
        //            param[5].Value = type;
        //            param[6] = new SqlParameter("@ImageSize", SqlDbType.BigInt);
        //            param[6].Value = length;
        //            param[7] = new SqlParameter("@ImageName", SqlDbType.VarChar, 500);
        //            param[7].Value = fileName;
        //            cmd.Parameters.AddRange(param);
        //            int rowsAffected = cmd.ExecuteNonQuery();
        //        }


        //    }


        //}
        #region FileUploadDemo
        //private void StartUpLoad()
        //{

        //    //get the image file that was posted (binary format)
        //    byte[] theImage = new byte[FileUpload1.PostedFile.ContentLength];
        //    HttpPostedFile Image = FileUpload1.PostedFile;
        //    Image.InputStream.Read(theImage, 0, (int)FileUpload1.PostedFile.ContentLength);
        //    int length = theImage.Length; //get the length of the image
        //    string fileName = FileUpload1.FileName.ToString(); //get the file name of the posted image
        //    string type = FileUpload1.PostedFile.ContentType; //get the type of the posted image
        //    int size = FileUpload1.PostedFile.ContentLength; //get the size in bytes that
        //    if (FileUpload1.PostedFile != null && FileUpload1.PostedFile.FileName != "")
        //    {
        //        //Call the method to execute Insertion of data to the Database
        //        ExecuteInsert(theImage, type, size, fileName, length);
        //        Response.Write("Save Successfully!");
        //    }
        //}

        //public string GetConnectionString()
        //{
        //    //sets the connection string from your web config file "ConnString" is the name of your Connection String
        //    return System.Configuration.ConfigurationManager.ConnectionStrings["MyConsString"].ConnectionString;
        //}

        //private void ExecuteInsert(byte[] Image, string Type, Int64 Size, string Name, int length)
        //{
        //    SqlConnection conn = new SqlConnection(GetConnectionString());
        //    string sql = "INSERT INTO TblImages (Image, ImageType, ImageSize, ImageName) VALUES "

        //                + " (@img,@type,@imgsize,@imgname)";
        //    try
        //    {
        //        conn.Open();
        //        SqlCommand cmd = new SqlCommand(sql, conn);
        //        SqlParameter[] param = new SqlParameter[4];

        //        param[0] = new SqlParameter("@img", SqlDbType.Image, length);
        //        param[1] = new SqlParameter("@type", SqlDbType.NVarChar, 50);
        //        param[2] = new SqlParameter("@imgsize", SqlDbType.BigInt, 9999);
        //        param[3] = new SqlParameter("@imgname", SqlDbType.NVarChar, 50);

        //        param[0].Value = Image;
        //        param[1].Value = Type;
        //        param[2].Value = Size;
        //        param[3].Value = Name;

        //        for (int i = 0; i < param.Length; i++)
        //        {
        //            cmd.Parameters.Add(param[i]);
        //        }

        //        cmd.CommandType = CommandType.Text;
        //        cmd.ExecuteNonQuery();
        //    }
        //    catch (System.Data.SqlClient.SqlException ex)
        //    {
        //        string msg = "Insert Error:";
        //        msg += ex.Message;
        //        throw new Exception(msg);
        //    }
        //    finally
        //    {
        //        conn.Close();
        //    }
        //}

        //protected void Button1_Click(object sender, EventArgs e)
        //{
        //    StartUpLoad();
        //}
        #endregion
    }
}