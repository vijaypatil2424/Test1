﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VED_WebService.SharePoint.BusinessLayer;
using VED_WebService.SharePoint.DTO;

namespace Demo.WebSite.ASPX
{
    public partial class EditSchedulePage : System.Web.UI.Page
    {
        Business BL = null;
        string executionContext = "";
        string loginName = string.Empty;
        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]
        public EditSchedulePage()
        {
            BL = new Business();
            executionContext = Guid.NewGuid().ToString();
            loginName = ConfigurationManager.AppSettings["loginUser"].ToString();
        }


        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                //  BindCenterDropDown();
                BindVEDScheduled();
                detailsDIV.Visible = false;

                //Disable the  Save button if , we are between 6 and 24 of the month


            }
        }
        private void BindVEDScheduled(bool isRebind = false)
        {
            try
            {
                ServiceResult<List<VEDSchedule>> results = BL.GetManagerLevelScheduleData(loginName, "State", executionContext, loginName);
                grdCentersDetails.DataSource = null;
                grdCentersDetails.DataBind();
                //grdCentersDetails.PageIndex = 0;
                grdCentersDetails.DataSource = results.Data;
                if (isRebind) { grdCentersDetails.PageIndex = 0; }
                grdCentersDetails.DataBind();
                //
                //grdCentersDetails.SetPageIndex(0);
            }
            catch (Exception)
            {

                throw;
            }
        }
        private void ClearControls()
        {
            lblOfficeArea.Text = string.Empty;
            lblOfficeCSPerson.Text = string.Empty;
            lblOfficeAddress.Text = string.Empty;
            lblOfficeType.Text = string.Empty;
            lblActualDate.Text = string.Empty;
            lblCity.Text = string.Empty;
            lblOfficeArea.Text = string.Empty;
            //lblScheduleDate.Text = string.Empty;
            txtScheduleDate.Text = string.Empty;
            lblZone.Text = string.Empty;
            txtComments.Text = string.Empty;
            txtComments.Visible = false;
            //ddlCenters.Enabled = true;
            //ddlCenters.ClearSelection();
            //ddlCenters.SelectedValue = 0;
            //ddlCenters.Items.FindByValue("0").Selected = true;
            BindVEDScheduled(true);
            detailsDIV.Visible = false;
        }

        private void GetVEDScheduledData(int VEDId)
        {
            ViewState["currentItem"] = string.Empty;
            ServiceResult<VEDSchedule> data = BL.GetScheduledVEDDetailsByID(VEDId.ToString(), executionContext, loginName);
            lblCity.Text = data.Data.City;
            lblOfficeAddress.Text = data.Data.Address;
            lblOfficeCSPerson.Text = data.Data.Address;
            lblOfficeType.Text = data.Data.OfficeType;
            lblZone.Text = data.Data.Zone;
            lblOfficeArea.Text = data.Data.CarpetArea;
            txtScheduleDate.Text = data.Data.ScheduledOn;
            txtOffice.Text = data.Data.Center;
            ViewState["currentItem"] = VEDId;
            txtComments.Visible = true;
            txtComments.Text = string.Empty;
            lblError.Text = string.Empty;
            detailsDIV.Visible = true;


        }

        protected void EditSchedule(object sender, EventArgs e)
        {
            btnSubmit.Text = "Update";
            GridViewRow row = (sender as LinkButton).NamingContainer as GridViewRow;
            int ID = Convert.ToInt32(grdCentersDetails.Rows[row.RowIndex].Cells[5].Text);
            GetVEDScheduledData(ID);
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            string scheduleDate = txtScheduleDate.Text.Trim();
            if (scheduleDate == string.Empty)
            {
                lblError.Text = "Please select the date.";
            }
            else if (btnSubmit.Text.ToUpper() == "UPDATE" && txtComments.Text == string.Empty)
            {
                lblError.Text = "Please provide Comments.";
            }
            else if (btnSubmit.Text.ToUpper() == "SUBMIT" && CheckDateRangeValidation(txtScheduleDate.Text))
            {
                lblError.Text = "Please change the Schedule date";
            }
            else
            {
                ServiceResult result = null;

                result = BL.AddVEDSchedule(ViewState["currentItem"].ToString(), "0", scheduleDate, txtComments.Text, executionContext, loginName);

                if (result.ErrorCode == "1")
                {
                    lblError.Text = result.ErrorMessage;
                    ClearControls();
                    //ddlCenters.SelectedIndex = 0;
                    BindVEDScheduled();
                }
                else
                {
                    lblError.Text = result.ErrorMessage + " Error Code : " + result.ExecutionContext;
                }
            }
        }

        private bool CheckDateRangeValidation(string scheduleDate)
        {
            return false;
        }

        protected void grdCentersDetails_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                bool isEditable = Convert.ToBoolean(e.Row.Cells[4].Text);
                if (!isEditable)
                {
                    LinkButton lnk = (LinkButton)e.Row.FindControl("lnkEdit");
                    if (lnk != null)
                    {
                        lnk.Visible = false;
                    }
                }
            }
        }

        protected void grdCentersDetails_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdCentersDetails.PageIndex = e.NewPageIndex;
            BindVEDScheduled();
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            ClearControls();
        }
    }
}