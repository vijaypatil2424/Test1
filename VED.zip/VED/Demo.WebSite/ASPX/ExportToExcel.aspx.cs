﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VED_WebService.SharePoint.BusinessLayer;
using VED_WebService.SharePoint.DTO;

namespace Demo.WebSite.ASPX
{
    public partial class ExportToExcel : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnExportToExcel_Click(object sender, EventArgs e)
        {

            Business BL = new Business();
            string[] arr = null;
            arr = new string[1];
            arr[0] = "VEDScheduledID=" + HttpContext.Current.Request.QueryString["vedid"].ToString();
            ServiceResult<Generic> results = BL.GenericMethod("usp_GetAssessmentDetailsByVEDSchedulesID", "", "", VED_WebService.SharePoint.RequestType.Portal, arr);
            DataSet ds = JsonConvert.DeserializeObject<DataSet>(results.Data.ResultData);
            //usp_Report_GetImages
            DataTable dt = ds.Tables[0];
            DataTable dt1 = ds.Tables[1];
            dt.Columns.Remove("FacilityID");
            dt.Columns.Remove("IsImageAvailable");
            dt.Columns.Remove("VEDScheduleID");
            string strHtmlTable = "";
            strHtmlTable = "<table   class='ReportTable'   id='tblVEDReport' runat='server' visible='false'>";
            strHtmlTable += "<tr><th>FacilityArea</th><th>FaciltyDetails</th><th>Criticality</th><th>Condition</th><th>Comments</th><th>Images</th></tr>";
            foreach (DataRow row in dt.Rows)
            {//write in new row
                strHtmlTable += "<tr>";
                for (int i = 0; i < dt.Columns.Count; i++)
                {
                    strHtmlTable += "<td>";
                    if (i == 5)
                    {
                        strHtmlTable += "<a href='http://sp13devwfe01:19999/_LAYOUTS/15/VEDHandler/image.ashx?ID=14'>ViewImages</a>";//
                        strHtmlTable += "<a href='http://sp13devwfe01:19999/_LAYOUTS/15/VEDHandler/image.ashx?ID=15'>ViewImages</a>";//
                    }
                    else
                    {
                        strHtmlTable += row[i].ToString();
                    }



                    strHtmlTable += "</td>";
                }
            }

            strHtmlTable += "</tr>";
            //strHtmlTable += "<tr><td><a href='http://sp13devwfe01:19999/_LAYOUTS/15/VEDHandler/image.ashx?ID=14'>ViewImages</a></td></tr>";
            strHtmlTable += "</table>";


            this.Page.Response.AppendHeader("content-disposition", "attachment;filename=JCVEDReport.xls");
            this.Page.Response.Charset = "";
            this.Page.Response.Cache.SetCacheability(HttpCacheability.NoCache);
            this.Page.Response.ContentType = "application/vnd.ms-excel";
            this.EnableViewState = false;
            this.Page.Response.Write(strHtmlTable);
            this.Page.Response.End();


            //////string[] arr = null;
            //////arr = new string[1];
            //////arr[0] = "VEDScheduledID=" + HttpContext.Current.Request.QueryString["vedid"].ToString();
            //////ServiceResult<Generic> results = BL.GenericMethod("usp_GetAssessmentDetailsByVEDSchedulesID", executionContext, loginName, RequestType.Portal, arr);
            //////DataSet ds = JsonConvert.DeserializeObject<DataSet>(results.Data.ResultData);
            ////////usp_Report_GetImages
            //////DataTable dt = ds.Tables[0];
            //////DataTable dt1 = ds.Tables[1];
            //////dt.Columns.Remove("FacilityID");
            //////dt.Columns.Remove("IsImageAvailable");
            //////dt.Columns.Remove("VEDScheduleID");
            //////HttpContext.Current.Response.Clear();
            //////HttpContext.Current.Response.ClearContent();
            //////HttpContext.Current.Response.ClearHeaders();
            //////HttpContext.Current.Response.Buffer = true;
            //////HttpContext.Current.Response.ContentType = "application/ms-excel";
            //////HttpContext.Current.Response.Write(@"<!DOCTYPE HTML PUBLIC ""-//W3C//DTD HTML 4.0 Transitional//EN"">");
            //////HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment;filename=Reports.xls");

            //////HttpContext.Current.Response.Charset = "utf-8";
            //////HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.GetEncoding("windows-1250");
            ////////sets font
            //////HttpContext.Current.Response.Write("<font style='font-size:10.0pt; font-family:Calibri;'>");
            //////HttpContext.Current.Response.Write("<BR><BR><BR>");
            ////////sets the table border, cell spacing, border color, font of the text, background, foreground, font height
            //////HttpContext.Current.Response.Write("<Table border='1' bgColor='#ffffff' " +
            //////  "borderColor='#000000' cellSpacing='0' cellPadding='0' " +
            //////  "style='font-size:10.0pt; font-family:Calibri; background:white;'> <TR>");
            ////////am getting my grid's column headers
            ////////  int columnscount = GridView_Result.Columns.Count;

            //////foreach (DataColumn dc in dt.Columns)
            //////{
            //////    //Page.Response.Write(tab + dc.ColumnName);
            //////    //tab = "\t";

            //////    HttpContext.Current.Response.Write("<Td>");
            //////    //Get column headers  and make it as bold in excel columns
            //////    HttpContext.Current.Response.Write("<B>");
            //////    HttpContext.Current.Response.Write(dc.ColumnName);
            //////    HttpContext.Current.Response.Write("</B>");
            //////    HttpContext.Current.Response.Write("</Td>");
            //////}


            ////////for (int j = 0; j < columnscount; j++)
            ////////{      //write in new column
            ////////    HttpContext.Current.Response.Write("<Td>");
            ////////    //Get column headers  and make it as bold in excel columns
            ////////    HttpContext.Current.Response.Write("<B>");
            ////////    HttpContext.Current.Response.Write(GridView_Result.Columns[j].HeaderText.ToString());
            ////////    HttpContext.Current.Response.Write("</B>");
            ////////    HttpContext.Current.Response.Write("</Td>");
            ////////}
            //////HttpContext.Current.Response.Write("</TR>");
            //////foreach (DataRow row in dt.Rows)
            //////{//write in new row
            //////    HttpContext.Current.Response.Write("<TR>");
            //////    for (int i = 0; i < dt.Columns.Count; i++)
            //////    {
            //////        HttpContext.Current.Response.Write("<Td>");
            //////        if (i == 5)
            //////        {
            //////            HttpContext.Current.Response.Write(GetHyperlink(row[i].ToString()));
            //////        }
            //////        else
            //////        {
            //////            HttpContext.Current.Response.Write(row[i].ToString());
            //////        }



            //////        HttpContext.Current.Response.Write("</Td>");
            //////    }

            //////    HttpContext.Current.Response.Write("</TR>");
            //////}
            //////HttpContext.Current.Response.Write("</Table>");


            //////HttpContext.Current.Response.Write("<BR><BR><BR>");
            ////////sets the table border, cell spacing, border color, font of the text, background, foreground, font height
            //////HttpContext.Current.Response.Write("<Table border='1' bgColor='#ffffff' " +
            //////  "borderColor='#000000' cellSpacing='0' cellPadding='0' " +
            //////  "style='font-size:10.0pt; font-family:Calibri; background:white;'> <TR>");

            //////foreach (DataColumn dc in dt1.Columns)
            //////{
            //////    //Page.Response.Write(tab + dc.ColumnName);
            //////    //tab = "\t";

            //////    HttpContext.Current.Response.Write("<Td>");
            //////    //Get column headers  and make it as bold in excel columns
            //////    HttpContext.Current.Response.Write("<B>");
            //////    HttpContext.Current.Response.Write(dc.ColumnName);
            //////    HttpContext.Current.Response.Write("</B>");
            //////    HttpContext.Current.Response.Write("</Td>");
            //////}


            ////////for (int j = 0; j < columnscount; j++)
            ////////{      //write in new column
            ////////    HttpContext.Current.Response.Write("<Td>");
            ////////    //Get column headers  and make it as bold in excel columns
            ////////    HttpContext.Current.Response.Write("<B>");
            ////////    HttpContext.Current.Response.Write(GridView_Result.Columns[j].HeaderText.ToString());
            ////////    HttpContext.Current.Response.Write("</B>");
            ////////    HttpContext.Current.Response.Write("</Td>");
            ////////}
            //////HttpContext.Current.Response.Write("</TR>");
            //////foreach (DataRow row in dt1.Rows)
            //////{//write in new row
            //////    HttpContext.Current.Response.Write("<TR>");
            //////    for (int i = 0; i < dt1.Columns.Count; i++)
            //////    {
            //////        HttpContext.Current.Response.Write("<Td>");
            //////        HttpContext.Current.Response.Write(row[i].ToString());
            //////        HttpContext.Current.Response.Write("</Td>");
            //////    }

            //////    HttpContext.Current.Response.Write("</TR>");
            //////}
            //////HttpContext.Current.Response.Write("</Table>");




            //////HttpContext.Current.Response.Write("</font>");
            //////HttpContext.Current.Response.Flush();
            //////HttpContext.Current.Response.End();
        }

        private string GetHyperlink(string p)
        {
            string returnAnch = string.Empty;
            returnAnch = "<table   class='ReportTable'   id='tblVEDReport' runat='server' visible='false'>";
            returnAnch += "<tr><th>Links</th></tr>";
            returnAnch += "<tr>";

            if (!string.IsNullOrEmpty(p))
            {
                string[] arr = p.Split(',');

                for (int i = 0; i < arr.Length; i++)
                {
                    returnAnch += "<td><a href='" + arr[i].Trim() + "'>ViewImages</a></td>";

                }
                returnAnch += "</tr>";
                returnAnch += "</table>";

            }
            return returnAnch;
        }
    }
}