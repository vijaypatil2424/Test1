﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Net.Mail;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VED_WebService.SharePoint.BusinessLayer;
using VED_WebService.SharePoint.DTO;

namespace Demo.WebSite.ASPX
{
    public partial class PoorFOrm : System.Web.UI.Page
    {
        Business BL = null;
        string executionContext = "";
        string loginName = string.Empty;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                string VEDID = Request.QueryString["VEDID"].ToString();
                BindPoorData(VEDID);
            }
        }
        public PoorFOrm()
        {
            BL = new Business();
            executionContext = Guid.NewGuid().ToString();
            loginName = ConfigurationManager.AppSettings["loginUser"].ToString();
        }
        private void BindPoorData(string VEDID)
        {

            string[] arr = new string[1];
            arr[0] = "VEDScheduledID=" + VEDID;
            ServiceResult<Generic> results = BL.GenericMethod("usp_Report_GetAssessmentDetailsByVEDSchedulesIDForPoor", executionContext, loginName, VED_WebService.SharePoint.RequestType.Portal, arr);
            DataSet ds = JsonConvert.DeserializeObject<DataSet>(results.Data.ResultData);
            grdAssessmentReadOnly.DataSource = ds.Tables[0];
            //lstJCOffice.DataTextField = "Title";
            //lstJCOffice.DataValueField = "ID";
            grdAssessmentReadOnly.DataBind();

        }
        protected void btnSendMail_Click(object sender, EventArgs e)
        {

            GridViewRow row = (sender as Button).NamingContainer as GridViewRow;
            string comments = ((TextBox)row.FindControl("txtComments")).Text;
            int ID = Convert.ToInt32(grdAssessmentReadOnly.Rows[row.RowIndex].Cells[8].Text);
            MailShooting(comments, ID);
           // ClientScript.RegisterStartupScript(this.GetType(), "PopupScript", "alert('Successfuly posted');", true);
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "script", "alert('Mail sent successfully');", true);
        }
        private void MailShooting(string comments, int ID)
        {

            try
            {
                //<add key="smtpServer" value="emailsmtp.ril.com" />
                //<add key="smtpUser1" value="IT.PMCoE@zmail.ril.com" />
                //<add key="smtpUser2" value="it.academy@zmail.ril.com" />
                MailAddress emailFrom = new MailAddress("IT.PMCoE@zmail.ril.com");
                string body = string.Empty;

                //// DateTime dt = Convert.ToDateTime(currItem["TrainingDate"].ToString());
                // string format = "dd MMM yyyy";
                // string newDate = dt.ToString(format);

                body = "<table style='font-family:Calibri;font-size:15px'><tr><td>Dear Sachin,</br></br><td></tr>"
                    + "<tr><td>Comments : " + comments + "</td></tr>"
                    + "<tr><td>Regards,</br>Sachin Jain.</br>(An Initiaitive by IT PM CoE)</td></tr></table>";

                MailMessage mail = new MailMessage();
                mail.IsBodyHtml = true;
                mail.From = emailFrom;
                mail.To.Add("sachin7.jain@ril.com");
                mail.Subject = "Regarding Interest in Training";
                mail.Body = body;

                SmtpClient smtp = new SmtpClient("emailsmtp.ril.com");
                smtp.UseDefaultCredentials = true;
              //  smtp.Send(mail);
                UpdateAssessmentTable(comments, ID);
            }
            catch (Exception ex)
            {

                throw;
            }

        }

        private void UpdateAssessmentTable(string comments, int ID, string mailSentTO = "sachin7.jain")
        {

            string[] arr = new string[6];
            arr[0] = "MailComments=" + comments;
            arr[1] = "MailSentDate=" + DateTime.Now;
            arr[2] = "MailSentToEmailID=" + mailSentTO;
            arr[3] = "IsMailSent=" + 1;
            arr[4] = "ID=" + ID;
            arr[5] = "UserID=" + loginName;
            ServiceResult<Generic> results = BL.GenericMethod("usp_Report_UpdateMailDetailsBasedOnID", executionContext, loginName, VED_WebService.SharePoint.RequestType.Portal, arr);
            DataSet ds = JsonConvert.DeserializeObject<DataSet>(results.Data.ResultData);
            BindPoorData(Request.QueryString["VEDID"].ToString());

       

        }
        protected void grdAssessmentReadOnly_DataBound(object sender, EventArgs e)
        {
            for (int i = grdAssessmentReadOnly.Rows.Count - 1; i > 0; i--)
            {
                GridViewRow row1 = grdAssessmentReadOnly.Rows[i];
                GridViewRow previousRow = grdAssessmentReadOnly.Rows[i - 1];
                //for (int j = 0; j < row.Cells.Count; j++)
                //{
                int j = 0;
                if (row1.Cells[0].Text == previousRow.Cells[0].Text)
                {
                    if (previousRow.Cells[j].RowSpan == 0)
                    {
                        if (row1.Cells[j].RowSpan == 0)
                        {
                            previousRow.Cells[j].RowSpan += 2;
                        }
                        else
                        {
                            previousRow.Cells[j].RowSpan = row1.Cells[j].RowSpan + 1;
                        }
                        row1.Cells[j].Visible = false;
                    }
                }
                //}
            }
        }

    }
}