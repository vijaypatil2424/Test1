﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VED_WebService.SharePoint.BusinessLayer;
using VED_WebService.SharePoint.DTO;
using System.Data;
using Newtonsoft.Json;
using System.IO;
using System.Drawing;

namespace Demo.WebSite.ASPX
{
    public partial class Report1 : System.Web.UI.Page
    {
        Business BL = null;
        string executionContext = "";
        string loginName = string.Empty;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindZones();
            }
        }

        private void BindZones()
        {
            ServiceResult<Generic> results = BL.GenericMethod("usp_Report_GetZones", executionContext, loginName, VED_WebService.SharePoint.RequestType.Portal, null);
            DataSet ds = JsonConvert.DeserializeObject<DataSet>(results.Data.ResultData);
            lstZones.DataSource = ds.Tables[0];
            lstZones.DataTextField = "Title";
            lstZones.DataValueField = "ID";
            lstZones.DataBind();
            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "script", "convertToMultiselect();", true);
        }

        public Report1()
        {
            BL = new Business();
            executionContext = Guid.NewGuid().ToString();
            loginName = ConfigurationManager.AppSettings["loginUser"].ToString();
            //"IsImageAvailable"
        }

        protected void lstZones_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                lstJCOffice.Items.Clear();
                lstState.Items.Clear();
                string zoneIDs = string.Empty;
                foreach (ListItem item in lstZones.Items)
                {
                    if (item.Selected == true)
                    {
                        zoneIDs += item.Value + ",";
                    }
                }
                zoneIDs = zoneIDs.EndsWith(",") ? zoneIDs.TrimEnd(',') : zoneIDs;

                BindState(zoneIDs);

                ltrVEDReport.Visible = false;
                btnExportExcel.Visible = false;
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "script", "convertToMultiselect();", true);
            }
            catch (Exception ex)
            {
                string ErrorLog = ex.Message + "\n\n" + ex.StackTrace + "lstZones_SelectedIndexChanged User entry Report page";
                // sbErrorMessage.AppendLine(ErrorLog);
            }
        }

        private void BindState(string zoneIDs)
        {

            string[] arr = new string[1];
            arr[0] = "ZoneIDs=" + zoneIDs;
            ServiceResult<Generic> results = BL.GenericMethod("usp_Report_StatesBasedOnZoneIds", executionContext, loginName, VED_WebService.SharePoint.RequestType.Portal, arr);
            DataSet ds = JsonConvert.DeserializeObject<DataSet>(results.Data.ResultData);
            lstState.DataSource = ds.Tables[0];
            lstState.DataTextField = "Title";
            lstState.DataValueField = "StateID";
            lstState.DataBind();



        }
        protected void lstState_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                lstJCOffice.Items.Clear();
                string stateIDs = string.Empty;
                foreach (ListItem item in lstState.Items)
                {
                    if (item.Selected == true)
                    {
                        stateIDs += item.Value + ",";
                    }
                }
                stateIDs = stateIDs.EndsWith(",") ? stateIDs.TrimEnd(',') : stateIDs;
                BindJCOffice(stateIDs);

                ltrVEDReport.Visible = false;
                btnExportExcel.Visible = false;
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "script", "convertToMultiselect();", true);
            }
            catch (Exception ex)
            {
                string ErrorLog = ex.Message + "\n\n" + ex.StackTrace + "lstState_SelectedIndexChanged User entry Report page";
                // sbErrorMessage.AppendLine(ErrorLog);
            }
        }


        protected void ExportToExcel(object sender, EventArgs e)
        {
            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=GridViewExport.xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-excel";
            using (StringWriter sw = new StringWriter())
            {
                HtmlTextWriter hw = new HtmlTextWriter(sw);

                //To Export all pages
                grdVEDDetails.AllowPaging = false;
                BindVED();

                grdVEDDetails.HeaderRow.BackColor = Color.White;
                foreach (TableCell cell in grdVEDDetails.HeaderRow.Cells)
                {
                    cell.BackColor = grdVEDDetails.HeaderStyle.BackColor;
                }
                foreach (GridViewRow row in grdVEDDetails.Rows)
                {
                    row.BackColor = Color.White;
                    foreach (TableCell cell in row.Cells)
                    {
                        if (row.RowIndex % 2 == 0)
                        {
                            cell.BackColor = grdVEDDetails.AlternatingRowStyle.BackColor;
                        }
                        else
                        {
                            cell.BackColor = grdVEDDetails.RowStyle.BackColor;
                        }
                        cell.CssClass = "textmode";
                    }
                }

                grdVEDDetails.RenderControl(hw);

                //style to format numbers to string
                string style = @"<style> .textmode { } </style>";
                Response.Write(style);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
        }



        private void BindJCOffice(string stateIDs)
        {
            string[] arr = new string[1];
            arr[0] = "StateIDs=" + stateIDs;
            ServiceResult<Generic> results = BL.GenericMethod("usp_Report_OfficesBasedOnStateIds", executionContext, loginName, VED_WebService.SharePoint.RequestType.Portal, arr);
            DataSet ds = JsonConvert.DeserializeObject<DataSet>(results.Data.ResultData);
            lstJCOffice.DataSource = ds.Tables[0];
            lstJCOffice.DataTextField = "Title";
            lstJCOffice.DataValueField = "ID";
            lstJCOffice.DataBind();
        }

        protected void lstJCOffice_SelectedIndexChanged(object sender, EventArgs e)
        {

            ////            usp_Report_VEDDetailsBasedOnOfficeIds 
            ////--usp_Report_StatesBasedOnZoneIds 
            ////    @OfficeIDs varchar(100)
            try
            {
                //    string officeIDs = string.Empty;
                //    foreach (ListItem item in lstJCOffice.Items)
                //    {
                //        if (item.Selected == true)
                //        {
                //            officeIDs += item.Value + ",";
                //        }
                //    }
                //    officeIDs = officeIDs.EndsWith(",") ? officeIDs.TrimEnd(',') : officeIDs;
                //    BindVEDDetails(officeIDs);

                //    ltrVEDReport.Visible = false;
                //    btnExportExcel.Visible = false;
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "script", "convertToMultiselect();", true);
                //btnExportExcel.Visible = true;
            }
            catch (Exception ex)
            {
                string ErrorLog = ex.Message + "\n\n" + ex.StackTrace + "lstState_SelectedIndexChanged User entry Report page";
                // sbErrorMessage.AppendLine(ErrorLog);
            }
        }

        private void BindVEDDetails(string officeIDs, string fromDate, string toDate)
        {
            string[] arr = null;
            if (fromDate != string.Empty && toDate != string.Empty)
            {
                arr = new string[3];
                arr[0] = "officeIDs=" + officeIDs;
                arr[1] = "fromDate=" + fromDate;
                arr[2] = "toDate=" + toDate;
            }
            else
            {
                arr = new string[1];
                arr[0] = "officeIDs=" + officeIDs;
            }
            ServiceResult<Generic> results = BL.GenericMethod("usp_Report_VEDDetailsBasedOnOfficeIds", executionContext, loginName, VED_WebService.SharePoint.RequestType.Portal, arr);
            DataSet ds = JsonConvert.DeserializeObject<DataSet>(results.Data.ResultData);
            grdVEDDetails.DataSource = ds.Tables[0];
            //lstJCOffice.DataTextField = "Title";
            //lstJCOffice.DataValueField = "ID";
            grdVEDDetails.DataBind();
        }

        protected void btnExportExcel_Click(object sender, EventArgs e)
        {
            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=GridViewExport.xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-excel";
            using (StringWriter sw = new StringWriter())
            {
                HtmlTextWriter hw = new HtmlTextWriter(sw);
                //To Export all pages
                grdVEDDetails.AllowPaging = false;
                BindVED();
                grdVEDDetails.HeaderRow.BackColor = Color.White;
                grdVEDDetails.Columns[4].Visible = false;
                grdVEDDetails.Columns[9].Visible = false;
                foreach (TableCell cell in grdVEDDetails.HeaderRow.Cells)
                {
                    cell.BackColor = grdVEDDetails.HeaderStyle.BackColor;
                }
                foreach (GridViewRow row in grdVEDDetails.Rows)
                {


                    row.Cells[4].Visible = false;
                    row.Cells[9].Visible = false;
                    row.BackColor = Color.White;
                    foreach (TableCell cell in row.Cells)
                    {
                        if (row.RowIndex % 2 == 0)
                        {
                            cell.BackColor = grdVEDDetails.AlternatingRowStyle.BackColor;
                        }
                        else
                        {
                            cell.BackColor = grdVEDDetails.RowStyle.BackColor;
                        }
                        cell.CssClass = "textmode";
                    }
                }

                grdVEDDetails.RenderControl(hw);

                //style to format numbers to string
                string style = @"<style> .textmode { } </style>";
                Response.Write(style);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
        }
        public override void VerifyRenderingInServerForm(Control control)
        {
            /* Verifies that the control is rendered */
        }
        private bool ValidateFilters()
        {
            bool isValid = false;
            foreach (ListItem item in lstZones.Items)
            {
                if (item.Selected == true)
                {
                    isValid = true;
                }
            }
            if (!isValid)
            {
                lblErrorMessage.Text = "Please select Zone";
                return isValid;
            }
            isValid = false;
            foreach (ListItem item in lstState.Items)
            {
                if (item.Selected == true)
                {
                    isValid = true;
                }
            }
            if (!isValid)
            {
                lblErrorMessage.Text = "Please select State";
                return isValid;
            }
            isValid = false;
            foreach (ListItem item in lstJCOffice.Items)
            {
                if (item.Selected == true)
                {
                    isValid = true;
                }
            }
            if (!isValid)
            {
                lblErrorMessage.Text = "Please select Office";
                return isValid;
            }
            if (txtFromDate.Text != "" && txtToDate.Text == "")
            {
                isValid = false;
                lblErrorMessage.Text = "Please select To Date";
            }
            else if (txtFromDate.Text == "" && txtToDate.Text != "")
            {
                isValid = false;
                lblErrorMessage.Text = "Please select From Date";
            }
            else if (txtFromDate.Text != "" && txtToDate.Text != "")
            {
                if (DateTime.Parse(txtToDate.Text) < DateTime.Parse(txtFromDate.Text))
                {
                    isValid = false;
                    lblErrorMessage.Text = "To Date Should be Greater than From Date";
                }
                else
                {
                    isValid = true;
                }
            }
            if (isValid)
            {
                lblErrorMessage.Text = string.Empty;
            }
            return isValid;
        }
        protected void btnGetData_Click(object sender, EventArgs e)
        {
            try
            {
                if (ValidateFilters())
                {
                    string officeIDs = string.Empty;
                    foreach (ListItem item in lstJCOffice.Items)
                    {
                        if (item.Selected == true)
                        {
                            officeIDs += item.Value + ",";
                        }
                    }
                    officeIDs = officeIDs.EndsWith(",") ? officeIDs.TrimEnd(',') : officeIDs;
                    BindVEDDetails(officeIDs, txtFromDate.Text, txtToDate.Text);
                    ltrVEDReport.Visible = false;
                    btnExportExcel.Visible = true;
                    ScriptManager.RegisterStartupScript(Page, Page.GetType(), "script", "convertToMultiselect();", true);

                }
            }
            catch (Exception ex)
            {

            }
        }

        protected void grdVEDDetails_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdVEDDetails.PageIndex = e.NewPageIndex;
            BindVED();
        }

        private void BindVED()
        {
            string officeIDs = string.Empty;
            foreach (ListItem item in lstJCOffice.Items)
            {
                if (item.Selected == true)
                {
                    officeIDs += item.Value + ",";
                }
            }
            officeIDs = officeIDs.EndsWith(",") ? officeIDs.TrimEnd(',') : officeIDs;
            BindVEDDetails(officeIDs, txtFromDate.Text, txtToDate.Text);
        }
    }
}