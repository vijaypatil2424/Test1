﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using VED_WebService.SharePoint.BusinessLayer;
using VED_WebService.SharePoint.DTO;
using Newtonsoft.Json;
using VED_WebService.SharePoint;

namespace Demo.WebSite.ASPX
{
    public partial class ScheduledVEDManagement : System.Web.UI.Page
    {
        Business BL = null;
        string executionContext = "";
        string loginName = string.Empty;
        //string siteURL = 
        public ScheduledVEDManagement()
        {
            BL = new Business();
            executionContext = Guid.NewGuid().ToString();
            loginName = ConfigurationManager.AppSettings["loginUser"].ToString();
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //GetCity(loginName,type=State or Zone);
                BindState(loginName);
                BindVEDScheduled();
                BindPreviousAssessment(loginName, hdnType.Value);

                //On CITY Change get the centers 
                //On change of Centers get the Details Of the  VEd
                //On Subkit click saved the data on the VEDSchedules :need to add the  DelegatedCreatedBy , DelegationLevel )
                //Getting the Data Created by  thde Deleagated for Editing
                //Writing code of editing the Same
                //Managing the click for Begin Assessment
                //Getting the Previous Assessment Done Data
            }

        }

        private void BindPreviousAssessment(string loginName, string p)
        {
            //throw new NotImplementedException();


            try
            {
                string[] arr = new string[3];
                arr[0] = "count=100";
                arr[1] = "UserID=" + loginName + "";
                arr[2] = "Type=" + p;
                ServiceResult<Generic> data = BL.GenericMethod("usp_GetTheScheduleHistoryOfCenterByUserID", executionContext, loginName, VED_WebService.SharePoint.RequestType.Portal, arr);
                DataSet result = JsonConvert.DeserializeObject<DataSet>(data.Data.ResultData);
                if (result.Tables.Count > 0)
                {
                    grdPreviousSchedules.DataSource = result.Tables[0];
                    grdPreviousSchedules.DataBind();
                }
            }
            catch (Exception ex)
            {
                //Common.ErrorLog(Type.Error, "CreateVEDSchedule : BindPreviouScheduledByUserID", "", "", loginName, executionContext, ex, RequestType.Portal);
            }



        }

        private void BindState(string loginName)
        {

            string[] arr = new string[1];
            arr[0] = "UserID=" + loginName;
            ServiceResult<Generic> results = BL.GenericMethod("usp_Audit_GetStateBasedOnUserID", executionContext, loginName, VED_WebService.SharePoint.RequestType.Portal, arr);
            DataSet ds = JsonConvert.DeserializeObject<DataSet>(results.Data.ResultData);
            if (ds.Tables.Count <= 2)
            {

                ddlState.DataSource = ds.Tables[1];
                ddlState.DataTextField = "Title";
                ddlState.DataValueField = "ID";
                ddlState.DataBind();

                hdnType.Value = ds.Tables[0].Rows[0]["Type"].ToString();
                lblType.Text = hdnType.Value;

            }
            else
            {
                ddlState.DataSource = ds.Tables[1];
                ddlState.DataTextField = "Title";
                ddlState.DataValueField = "ID";
                ddlState.DataBind();


                ddlCity.DataSource = ds.Tables[2];
                ddlCity.DataTextField = "City";
                ddlCity.DataValueField = "City";
                ddlCity.DataBind();

                hdnType.Value = ds.Tables[0].Rows[0]["Type"].ToString();
                lblType.Text = hdnType.Value;
            }
        }

        protected void hypCreateSchedule_Click(object sender, EventArgs e)
        {

        }

        protected void hypBeginAssessment_Click(object sender, EventArgs e)
        {

        }

        protected void hypEditSchedules_Click(object sender, EventArgs e)
        {
            Page.Response.Redirect("/sites/rcs/jcved/pages/Edit-Schedule.aspx", true);
        }

        protected void ddlCity_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindCenter(ddlCity.SelectedValue, ddlType.SelectedValue);
        }

        private void BindCenter(string city, string officeCategoryType)
        {
            string[] arr = new string[2];
            arr[0] = "City=" + city;
            arr[1] = "officeCategoryID=" + officeCategoryType;
            ServiceResult<Generic> results = BL.GenericMethod("usp_Audit_GetCenterBasedOnCityID", executionContext, loginName, VED_WebService.SharePoint.RequestType.Portal, arr);
            DataSet ds = JsonConvert.DeserializeObject<DataSet>(results.Data.ResultData);
            if (ds.Tables.Count > 0)
            {
                ddlCenters.DataSource = ds.Tables[0];
                ddlCenters.DataTextField = "Title";
                ddlCenters.DataValueField = "ID";
                ddlCenters.DataBind();

                ddlCenters.Items.Insert(0, new ListItem("Select Center", "0"));
            }
        }

        protected void ddlCenters_SelectedIndexChanged(object sender, EventArgs e)
        {

            ServiceResult<Office> officeDetails = BL.GetCenterDetailsByID(ddlCenters.SelectedValue, executionContext, loginName);
            if (officeDetails.ErrorCode == "1")
            {
                if (officeDetails.Data != null)
                {
                    lblCity.Text = officeDetails.Data.City;
                    lblOfficeAddress.Text = officeDetails.Data.Address;
                    ddlOfficeAdmins.Items.Clear();
                    //ddlOfficeAdmins.DataBind(); 
                    string[] admins = null;
                    if (officeDetails.Data.OfficeAdmins.Contains(";"))
                    {
                        admins = officeDetails.Data.OfficeAdmins.Split(';');
                        for (int i = 0; i < admins.Length; i++)
                        {
                            ddlOfficeAdmins.Items.Insert(i, new ListItem(admins[i].ToString(), admins[i].ToString()));
                        }
                    }
                    else
                    {
                        ddlOfficeAdmins.Items.Insert(0, new ListItem(officeDetails.Data.OfficeAdmins, officeDetails.Data.OfficeAdmins));
                    }
                    lblOfficeType.Text = officeDetails.Data.OfficeType;
                    //lblZone.Text = officeDetails.Data.Zone;
                    lblOfficeArea.Text = officeDetails.Data.CarpetArea;
                    lblZone.Text = officeDetails.Data.Zone;
                    btnSubmit.Text = "Submit";
                    txtComments.Visible = false;
                    lblError.Text = string.Empty;
                    detailsDIV.Visible = true;
                }
                else
                {
                    lblError.Text = "No data found for the selected center";

                }
            }
            else
            {
                lblError.Text = officeDetails.ErrorMessage + "Error code : " + executionContext;
            }
        }

        protected void btnBeginAssessment_Click(object sender, EventArgs e)
        {
            //string[] arr = new string[7];
            //if (hdnVEDID.Value == string.Empty)
            //{
            //    arr[0] = "ID=" + "";
            //}
            //else
            //{
            //    arr[0] = "ID=" + hdnVEDID.Value;
            //}
            //arr[1] = "UserID=" + ddlOfficeAdmins.SelectedValue;
            //arr[2] = "OfficeID=" + ddlCenters.SelectedValue;
            //arr[3] = "ScheduledOn=" + txtScheduleDate.Text;
            //arr[4] = "Comments=" + txtComments.Text;
            //arr[5] = "AssessmentType=" + (Int32)VED_WebService.SharePoint.AssessmentType.StateLevel;
            //arr[6] = "DelegatedBy=" + loginName;
            //DataSet ds = null;

            //ServiceResult<Generic> result = null;
            //result = BL.GenericMethod("usp_Audit_InsertUpdateVEDSchedule", executionContext, loginName, VED_WebService.SharePoint.RequestType.Portal, arr);
            //ds = JsonConvert.DeserializeObject<DataSet>(result.Data.ResultData);

            //if (ds.Tables[0].Rows[0]["ErrorCode"].ToString() == "1")
            //{
            //    lblError.Text = result.ErrorMessage;
            //    // ClearControls();
            //    ddlCenters.SelectedIndex = 0;
            //    //BindVEDScheduled();
            //    string VEDID = ds.Tables[1].Rows[0]["VEDID"].ToString();
            //    Response.Redirect("/sites/rcs/jcved/pages/Assessment.aspx?VEDID=" + VEDID, true);

            //}
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {

            string request = "scheduleDate : " + txtScheduleDate.Text.Trim() + " ddlCenters.SelectedValue : " + ddlCenters.SelectedValue + "View State  : Current Item : " + ViewState["currentItem"] != null ? "NULL" : ViewState["currentItem"].ToString();
            ServiceResult<Generic> result = null;
            try
            {
                string scheduleDate = txtScheduleDate.Text.Trim();
                if (ddlCenters.SelectedValue == "0")
                {
                    lblError.Text = "Please select the center";
                }
                else if (scheduleDate == string.Empty)
                {
                    lblError.Text = "Please select the date.";
                }
                else if (btnSubmit.Text.ToUpper() == "UPDATE" && txtComments.Text == string.Empty)
                {
                    lblError.Text = "Please provide Comments.";
                }
                else
                {
                    string[] arr = new string[7];
                    if (hdnVEDID.Value == string.Empty)
                    {
                        arr[0] = "ID=" + "";
                    }
                    else
                    {
                        arr[0] = "ID=" + hdnVEDID.Value;
                    }

                    arr[1] = "UserID=" + ddlOfficeAdmins.SelectedValue;
                    arr[2] = "OfficeID=" + ddlCenters.SelectedValue;
                    arr[3] = "ScheduledOn=" + txtScheduleDate.Text;
                    arr[4] = "Comments=" + txtComments.Text;
                    arr[5] = "AssessmentType=" + (Int32)VED_WebService.SharePoint.AssessmentType.StateLevel;
                    arr[6] = "DelegatedBy=" + loginName;
                    DataSet ds = null;

                    result = BL.GenericMethod("usp_Audit_InsertUpdateVEDSchedule", executionContext, loginName, VED_WebService.SharePoint.RequestType.Portal, arr);
                    ds = JsonConvert.DeserializeObject<DataSet>(result.Data.ResultData);

                    if (ds.Tables[0].Rows[0]["ErrorCode"].ToString() == "1")
                    {
                        lblError.Text = result.ErrorMessage;
                        // ClearControls();
                        ddlCenters.SelectedIndex = 0;
                        BindVEDScheduled();
                    }
                    else
                    {
                        lblError.Text = ds.Tables[0].Rows[0]["ErrorMessage"].ToString() + " Error Code : " + result.ExecutionContext;
                    }
                }
            }
            catch (Exception ex)
            {
                //Common.ErrorLog(Type.Error, "CreateVEDSchedule : btnSubmit_Click", request, JsonConvert.SerializeObject(result), loginName, executionContext, ex, RequestType.Portal);
            }
        }

        private void BindVEDScheduled()
        {
            //          [dbo].[usp_Audit_GetAllVEDSchedule] --null,null,1,'GETBYOFFICEID'
            //--[usp_GetAllVEDSchedule] null,null,1,'GETBYOFFICEID'
            //   @ID INT = NULL   ----VED  Schedule ID
            // , @UserID VARCHAR(200) = NULL   ----LoggedIn User ID
            // , @OfficeID INT = NULL ---- OFFICE ID
            // , @Type VARCHAR(100) AS -

            string[] arr = new string[4];
            arr[0] = "ID=" + "";
            arr[1] = "UserID=" + loginName;
            arr[2] = "OfficeID=" + "";
            arr[3] = "Type=GETALL";

            DataSet ds = null;
            ServiceResult<Generic> results = BL.GenericMethod("usp_Audit_GetAllVEDSchedule", executionContext, loginName, VED_WebService.SharePoint.RequestType.Portal, arr);
            ds = JsonConvert.DeserializeObject<DataSet>(results.Data.ResultData);
            grdCentersDetails.DataSource = ds.Tables[0];
            grdCentersDetails.DataBind();
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {

        }

        protected void EditSchedule(object sender, EventArgs e)
        {
            btnSubmit.Text = "Update";
            GridViewRow row = (sender as LinkButton).NamingContainer as GridViewRow;
            int ID = Convert.ToInt32(grdCentersDetails.Rows[row.RowIndex].Cells[5].Text);
            GetVEDScheduledData(ID);
            hdnVEDID.Value = ID.ToString(); ;
        }

        private void GetVEDScheduledData(int VEDId)
        {
            string request = "VEDId : " + VEDId; //GETBYID
            try
            {
                string[] arr = new string[4];
                arr[0] = "ID=" + VEDId;
                arr[1] = "UserID=" + loginName;
                arr[2] = "OfficeID=" + "";
                arr[3] = "Type=GETBYID";

                DataSet ds = null;
                ServiceResult<Generic> results = BL.GenericMethod("usp_Audit_GetAllVEDSchedule", executionContext, loginName, VED_WebService.SharePoint.RequestType.Portal, arr);
                ds = JsonConvert.DeserializeObject<DataSet>(results.Data.ResultData);


                if (ds.Tables[0].Rows.Count > 0)
                {
                    ddlState.SelectedValue = ds.Tables[0].Rows[0]["State"].ToString();
                    ddlState.Enabled = false;
                    ddlCity.SelectedValue = ds.Tables[0].Rows[0]["City"].ToString();
                    ddlCity.Enabled = false;
                    BindCenter(ddlCity.SelectedValue, ddlType.SelectedValue);
                    ddlCenters.SelectedValue = ds.Tables[0].Rows[0]["OfficeID"].ToString();
                    ddlCenters.Enabled = false;

                    ddlType.SelectedValue = ds.Tables[0].Rows[0]["OfficeCategoryID"].ToString();
                    ddlType.Enabled = false;
                    lblZone.Text = ds.Tables[0].Rows[0]["Zone"].ToString();
                    lblOfficeArea.Text = ds.Tables[0].Rows[0]["CarpetArea"].ToString();
                    string[] admins = null;
                    ddlOfficeAdmins.Items.Clear();
                    if (ds.Tables[0].Rows[0]["OfficeAdmins"].ToString().Contains(";"))
                    {
                        admins = ds.Tables[0].Rows[0]["OfficeAdmins"].ToString().Split(';');
                        for (int i = 0; i < admins.Length; i++)
                        {
                            ddlOfficeAdmins.Items.Insert(i, new ListItem(admins[i].ToString(), admins[i].ToString()));
                        }
                    }
                    else
                    {
                        ddlOfficeAdmins.Items.Insert(0, new ListItem(ds.Tables[0].Rows[0]["OfficeAdmins"].ToString(), ds.Tables[0].Rows[0]["OfficeAdmins"].ToString()));
                    }
                    ddlOfficeAdmins.SelectedValue = ds.Tables[0].Rows[0]["ScheduledBy"].ToString();
                    txtScheduleDate.Text = ds.Tables[0].Rows[0]["ScheduledOn"].ToString();
                    lblOfficeAddress.Text = ds.Tables[0].Rows[0]["Address"].ToString();
                    txtComments.Visible = true;

                }



                //       ddlState.SelectedItem = ""



                //SELECT
                //    ved.ID,
                //    OfficeID,
                //    REPLACE(CONVERT(NVARCHAR,ScheduledOn, 106), ' ', '-') as ScheduledOn,
                //   ScheduledBy,
                //   ActualAssesstmentDate,
                //   OM.Title as Center,
                //   zm.Title as Zone,
                //   OM.Address as Address,
                //   OM.City,
                //   OCM.TItle AS OfficeCategory,
                //   OT.Title AS OfficeType,
                //   OT.ID AS OfficeTypeID,
                //   OM.CarpetArea AS CarpetArea,
                //   'IsEditAllowed' = (Select dbo.ufnToConfirmScheduleEditOrNot(ved.ID))
                //   ,om.Latitude
                //   ,om.Longitude
                //   ,om.OfficeAdmins
                //   ,sm.Title as State
                //ViewState["currentItem"] = string.Empty;
                //ServiceResult<VEDSchedule> data = BL.GetScheduledVEDDetailsByID(VEDId.ToString(), executionContext, loginName, RequestType.Portal);
                //executionContext = data.ExecutionContext;
                //lblCity.Text = data.Data.City;
                //lblOfficeAddress.Text = data.Data.Address;
                //lblOfficeCSPerson.Text = data.Data.OfficeAdmins;
                //lblOfficeType.Text = data.Data.OfficeType;
                //// lblZone.Text = data.Data.Zone;
                //lblOfficeArea.Text = data.Data.CarpetArea;
                //txtScheduleDate.Text = data.Data.ScheduledOn;
                //ddlCenters.ClearSelection();
                //ddlCenters.Items.FindByValue(data.Data.OfficeID).Selected = true;
                //ddlCenters.Enabled = false;
                //ViewState["currentItem"] = VEDId;
                //txtComments.Visible = true;
                //txtComments.Text = string.Empty;
                //lblError.Text = string.Empty;
                //detailsDIV.Visible = true;
                //divButtons.Visible = true;
                //lblZone.Text = data.Data.Zone;
            }
            catch (Exception ex)
            {
                // Common.ErrorLog(Type.Error, "CreateVEDSchedule : GetVEDScheduledData", request, "", loginName, executionContext, ex, RequestType.Portal);
            }

        }

        protected void grdCentersDetails_RowDataBound(object sender, GridViewRowEventArgs e)
        {

        }

        protected void grdCentersDetails_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {

        }

        protected void hypBeginAssessment_Click1(object sender, EventArgs e)
        {

        }

        protected void btnBeginAssessment_Click1(object sender, EventArgs e)
        {
            string[] arr = new string[4];
            arr[0] = "UserID=" + loginName;
            arr[1] = "OfficeID=" + ddlCenters.SelectedValue;
            arr[2] = "ScheduledOn=" + txtScheduleDate.Text;
            arr[3] = "AssessmentType=" + (Int32)VED_WebService.SharePoint.AssessmentType.StateLevel;
            DataSet ds = null;

            ServiceResult<Generic> result = null;
            result = BL.GenericMethod("usp_Audit_InsertVEDScheduleForStateAndZonal", executionContext, loginName, VED_WebService.SharePoint.RequestType.Portal, arr);
            ds = JsonConvert.DeserializeObject<DataSet>(result.Data.ResultData);

            if (ds.Tables[0].Rows[0]["ErrorCode"].ToString() == "1")
            {
                lblError.Text = result.ErrorMessage;
                // ClearControls();
                //ddlCenters.SelectedIndex = 0;
                //BindVEDScheduled();
                string VEDID = ds.Tables[1].Rows[0]["VEDID"].ToString();
                Response.Redirect(  "/pages/Assessment.aspx?VEDID=" + VEDID + "&Type=3", true);
            }
        }

        protected void ddlState_SelectedIndexChanged(object sender, EventArgs e)
        {

            string[] arr = new string[1];
            arr[0] = "StateID=" + ddlState.SelectedValue;
            DataSet ds = null;
            ServiceResult<Generic> results = BL.GenericMethod("usp_Audit_GetCityBasedOnStateID", executionContext, loginName, VED_WebService.SharePoint.RequestType.Portal, arr);
            ds = JsonConvert.DeserializeObject<DataSet>(results.Data.ResultData);
            if (ds.Tables.Count > 0)
            {

                ddlCity.DataSource = ds.Tables[0];
                ddlCity.DataTextField = "City";
                ddlCity.DataValueField = "City";
                ddlCity.DataBind();
            }


        }
    }
}