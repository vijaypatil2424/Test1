﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Demo.WebSite
{
    public class CommonWeb
    {

    }
    public class AttachmentVar
    {
        public static string Attachment = "Attachment";
        public static string FileName = "FileName";
        public static string FilePath = "FilePath";
        public static string FileGUID = "FileGUID";
        public static string FileDelete = "FileDelete";
        public static string FolderGUID = "FolderGUID";
        //Attachment Columns for Operational data
        public static string ID = "ID";
        public static string OperationalStatus = "OperationalStatus";
        public static string RowIndex = "RowIndex";
        public static string Index = "Index";
        public static string ParentIndex = "ParentIndex";
        public static string AttachmentsList = "Attachments";
    }
    public enum RequestType
    {
        Mobile = 1,
        Portal
    }
}