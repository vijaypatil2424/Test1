﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using VED_WebService.SharePoint.BusinessLayer;
using VED_WebService.SharePoint.DTO;

namespace Demo.WebSite
{
    /// <summary>
    /// Summary description for Image
    /// </summary>
    public class Image : IHttpHandler
    {
        private const string connectionString = "Data Source=SP13DEVDB01;Initial Catalog=VEDDB;User Id=veduser;Password =pass@123";
        //public void ProcessRequest(HttpContext context)
        //{
        //    context.Response.ContentType = "text/plain";
        //    context.Response.Write("Hello World");
        //}

        public Image()
        {

        }
        public void ProcessRequest(HttpContext context)
        {
            ////////////////Business BL = new Business();
            ////////////////string executionContext = "";
            ////////////////string loginName = string.Empty;

            ////////////////executionContext = Guid.NewGuid().ToString();
            ////////////////loginName = ConfigurationManager.AppSettings["loginUser"].ToString();
            ////////////////int ID;

            ////////////////if (context.Request.QueryString["ID"] != null)
            ////////////////{
            ////////////////    ID = Convert.ToInt32(context.Request.QueryString["ID"]);

            ////////////////}
            ////////////////else
            ////////////////    throw new ArgumentException("No parameter specified");

            //////////////////string[] arr = new string[1];
            //////////////////arr[0] = "ID=" + 14;


            //////////////////ServiceResult<Generic> results = BL.GenericMethod("usp_Report_GetImages", executionContext, loginName, VED_WebService.SharePoint.RequestType.Portal, arr);
            //////////////////DataSet ds = JsonConvert.DeserializeObject<DataSet>(results.Data.ResultData);
            //////////////////if (ds.Tables[0].Rows.Count > 0)
            //////////////////{
            //////////////////    if (ds.Tables[0].Rows[0]["Image"] != DBNull.Value)
            //////////////////    {
            //////////////////        context.Response.ContentType =
            //////////////////           GetContentType(ds.Tables[0].Rows[0]["ImageName"].ToString());

            //////////////////        byte[] toBytes = (Byte[])(ds.Tables[0].Rows[0]["Image"]);
            //////////////////        context.Response.BinaryWrite(toBytes);
            //////////////////    }
            //////////////////}

            ////////////////using (SqlConnection conn = new SqlConnection(connectionString))
            ////////////////{
            ////////////////    conn.Open();
            ////////////////    SqlCommand cmd = new SqlCommand();
            ////////////////    cmd.Connection = conn;
            ////////////////    cmd.CommandType = CommandType.StoredProcedure;
            ////////////////    cmd.CommandText = "usp_Report_GetImages";
            ////////////////    cmd.Parameters.AddWithValue("@ID", ID);
            ////////////////    // cmd.Parameters.AddWithValue("@FaciltyDetailsID", FacilityDetailsID);
            ////////////////    SqlDataAdapter da = new SqlDataAdapter(cmd);
            ////////////////    DataSet ds = new DataSet();
            ////////////////    da.Fill(ds);
            ////////////////    if (ds.Tables.Count > 0)
            ////////////////    {
            ////////////////        context.Response.ContentType =
            ////////////////           GetContentType(ds.Tables[0].Rows[0]["ImageName"].ToString());

            ////////////////        byte[] toBytes = (Byte[])(ds.Tables[0].Rows[0]["Image"]);
            ////////////////        context.Response.BinaryWrite(toBytes);
            ////////////////    }
            ////////////////}
        }
        private string GetContentType(string imageName)
        {
            string imageExtension = imageName.Split('.')[1];
            string type = string.Empty;
            switch (imageExtension)
            {
                case "png":
                    type = "image/png";
                    break;
                case "jpg":
                case "jpeg":
                    type = "image/jpeg";
                    break;
                default:
                    type = "image/jpeg";
                    break;
            }
            return type;
            //case type :
            //case png :
            //return "image/png";


        }
        public bool IsReusable
        {
            get
            {
                return false;
            }
        }

    }
}