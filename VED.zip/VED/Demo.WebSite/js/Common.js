﻿if (jQuery) {
    (
    function ($) {


        function GetImages(VEDID, facilityAreaID) {

            $.ajax({
                type: "POST",
                url: "http://sp13devwfe01:19999/sites/rcs/_LAYOUTS/15/VED_WebService/VED_WebService.asmx/GetAssessmentDetails",
                data: "{ VEDScheduleID: '" + VEDID + "', executionContext: '" + VEDID + "', loggedInUser: '" + VEDID + "', type: '" + 1 + "'}",
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                success: function (r) {
                    alert(r.d);
                },
                error: function (r) {
                    alert(r.responseText);
                },
                failure: function (r) {
                    alert(r.responseText);
                }
            });


            //function handleHtml(data, status) {
            //    for (var count in data.d) {
            //        alert(data.d[count].Author);
            //        alert(data.d[count].BookName);
            //    }
            //}

            //function ajaxFailed(xmlRequest) {
            //    alert(xmlRequest.status + ' \n\r ' + 
            //          xmlRequest.statusText + '\n\r' + 
            //          xmlRequest.responseText);
            //}

        }


        $(document).ready(function () {
            $(".datepickerClass").datepicker({
                dateFormat: "dd-M-yy"
               //, minDate: GetMinDate()
               //  , maxDate: GetMaxDate()
            });
           
            $('.datepickerClass').keyup(function () {
                $(this).val('');
                alert('Please select date from Calendar');
            });

            $('.lnlViewImages').each(function () {
                // alert('Hello');
                $(this).click(function () {
                    var VEDID = $(this).attr('data-VEDID');
                    var facilityID = $(this).attr('data-FacilityID');
                    // alert("VEDID " + VEDID + " facilityID" + facilityID);
                    GetImages(VEDID, facilityID)
                    return false;
                });
            });

            function GetMinDate() {

                var currentDate = new Date()
                var currentDay = currentDate.getUTCDate();
                var currentMonthLastDay = new Date(currentDate.getUTCFullYear(), currentDate.getMonth() + 1, 0);
                if (currentDay >= 25 && currentDay <= currentMonthLastDay.getUTCDate()) {
                    return new Date(currentDate.getUTCFullYear(), currentDate.getUTCMonth() + 1, 1)
                }
                else {
                    return new Date(currentDate.getUTCFullYear(), currentDate.getUTCMonth(), 1)
                }
            }

            function GetMaxDate() {

                //var currentDate = new Date();
                var currentDate = new Date();
                var currentDay = currentDate.getUTCDate();
                var currentMonthLastDay = new Date(currentDate.getUTCFullYear(), currentDate.getUTCMonth() + 1, 0);
                if (currentDay >= 25 && currentDay <= currentMonthLastDay.getUTCDate()) {
                    return new Date(currentDate.getUTCFullYear(), currentDate.getUTCMonth() + 2, 0)
                }
                else {
                    return new Date(currentDate.getUTCFullYear(), currentDate.getUTCMonth() + 1, 0)
                }
            }
        });
    }(jQuery));
}