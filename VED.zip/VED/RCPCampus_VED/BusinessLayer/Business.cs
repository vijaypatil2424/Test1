﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RCPCampus_VED.DataAccessLayer;
using RCPCampus_VED.DTO;


namespace RCPCampus_VED.BusinessLayer
{
    public class Business
    {
        DataAccess da = new DataAccess();
        #region VED Schedule
        public ServiceResult<List<CommonDDL>> GetAllCentersByUserID(string userName, string executionContext, string loggedInUser, string officeType, RequestType type = RequestType.Mobile)
        {
            return da.GetAllCentersByUserID(userName, executionContext, loggedInUser, officeType, type);
        }
        public ServiceResult<Office> GetCenterDetailsByID(string centerID, string executionContext, string loggedInUser, RequestType type = RequestType.Mobile)
        {
            return da.GetCenterDetailsByID(centerID, executionContext, loggedInUser, type);
        }
        public ServiceResult<List<VEDSchedule>> GetAllScheduleForCurrentMonth(string userName, string executionContext, string loggedInUser,string officeType,RequestType type = RequestType.Mobile)
        {
            return da.GetAllScheduleForCurrentMonth(userName, executionContext, loggedInUser,officeType,type);
        }
        public ServiceResult AddVEDSchedule(string vedID, string officeID, string scheduledOn, string comments, string executionContext, string loggedInUser, RequestType type = RequestType.Mobile, AssessmentType assessmentType = AssessmentType.AreaLevel)
        {
            return da.AddVEDSchedule(vedID, officeID, scheduledOn, comments, executionContext, loggedInUser, type, assessmentType);
        }
        public ServiceResult<VEDSchedule> GetScheduledVEDDetailsByID(string VEDID,string executionContext, string loggedInUser, RequestType type = RequestType.Mobile)
        {
            return da.GetScheduledVEDDetailsByID(VEDID,executionContext, loggedInUser, type);
        }
        public ServiceResult<List<VEDFinalData>> GetScheduleHistoryOfCenter(string centerID, string count, string executionContext, string loggedInUser, RequestType type = RequestType.Mobile)
        {
            return da.GetScheduleHistoryOfCenter(centerID, count, executionContext, loggedInUser, type);
        }
        public ServiceResult<List<VEDSchedule>> GetManagerLevelScheduleData(string userID, string typeOfLevel, string executionContext, string loggedInUser,String officeType, RequestType type = RequestType.Portal)
        {
            return da.GetManagerLevelScheduleData(userID, typeOfLevel, executionContext, loggedInUser,officeType, type);
        }
        #endregion

        #region Assessment Details
        public ServiceResult<Facility> GetFaciltyAreaDetailsMasters(string centerTypeID, string VEDScheduleID, string executionContext, string loggedInUser, RequestType type = RequestType.Mobile)
        {
            return da.GetFaciltyAreaDetailsMasters(centerTypeID, VEDScheduleID, executionContext, loggedInUser, type);
        }
        public ServiceResult<VEDScore> SaveAsessmentDetails_Web(List<AssesstmentDetails> assesmentData, string executionContext, string loggedInUser, RequestType type = RequestType.Mobile, AssessmentType assessmentType  = AssessmentType.AreaLevel)
        {
            return da.SaveAsessmentDetails_Web(assesmentData, executionContext, loggedInUser, type, assessmentType);
        }

        public ServiceResult UploadAssessmentImages_Web(List<Image> imagesData, string executionContext, string loggedInUser, RequestType type = RequestType.Mobile)
        {
            return da.UploadAssessmentImages_Web(imagesData, executionContext, loggedInUser, type);
        }
        public ServiceResult<VEDScore> SaveAsessmentDetails(List<AssesstmentDetails> assesmentData, string executionContext, string loggedInUser, RequestType type = RequestType.Mobile, AssessmentType assessmentType = AssessmentType.AreaLevel)
        {
            return da.SaveAsessmentDetails(assesmentData, executionContext, loggedInUser, type, assessmentType);
        }
        public ServiceResult UploadAssessmentImages(List<Image> imagesData, string executionContext, string loggedInUser, RequestType type = RequestType.Mobile)
        {
            return da.UploadAssessmentImages(imagesData, executionContext, loggedInUser, type);
        }
        public ServiceResult<FinalAssessmentData> GetAssessmentDetails(string VEDScheduleID,string executionContext, string loggedInUser, RequestType type = RequestType.Mobile)
        {
            return da.GetAssessmentDetails(VEDScheduleID,executionContext, loggedInUser, type);
        }
        //
        
        public ServiceResult<List<Image>> GetImagesBasedOnVEDID(string VEDID, string FacilityDetailsID, string executionContext, string loggedInUser, RequestType type = RequestType.Mobile)
        {
            return da.GetImagesBasedOnVEDID(VEDID, FacilityDetailsID, executionContext, loggedInUser, type);
        }

        #endregion

        #region Generic
        public ServiceResult<Generic> GenericMethod(string spName, string executionContext, string loggedInUser, RequestType type = RequestType.Mobile, params string[] arr)
        {
            return da.GenericMethod(spName, executionContext, loggedInUser, type, arr);
        }

        public ServiceResult GenericInsertUpdateMethod(string spName, string executionContext, string loggedInUser, RequestType type = RequestType.Mobile, params string[] arr)
        {
            return da.GenericInsertUpdateMethod(spName, executionContext, loggedInUser, type, arr);
        }

          public ServiceResult LoginLogOut(string executionContext, string loggedInUser, string loginType = "LogOut", RequestType type = RequestType.Mobile)
        {
            return da.LoginLogOut(executionContext, loggedInUser, loginType, type);
        }

        #endregion
        # region Audit Methods
        public ServiceResult<FinalAssessmentData> GetAssessmentDetails_Audit(string VEDScheduleID, string executionContext, string loggedInUser, RequestType type = RequestType.Mobile)
        {
            return da.GetAssessmentDetails_Audit(VEDScheduleID, executionContext, loggedInUser, type);
        }
        public ServiceResult<FinalAssessmentData> GetAssessmentDetailsForView_Audit(string VEDScheduleID, string executionContext, string loggedInUser, RequestType type = RequestType.Mobile)
        {
            return da.GetAssessmentDetailsForView_Audit(VEDScheduleID, executionContext, loggedInUser, type);
        }
        public ServiceResult<VEDScore> SaveAsessmentDetails_Web_Audit(List<AssesstmentDetails> assesmentData, string executionContext, string loggedInUser, RequestType type = RequestType.Mobile, AssessmentType assessmentType = AssessmentType.AreaLevel)
        {
            return da.SaveAsessmentDetails_Web_Audit(assesmentData, executionContext, loggedInUser, type, assessmentType);
        }
        public ServiceResult<Generic> GetZoneData(string spName)
        {
            return da.GetZoneData(spName);
        }
        public ServiceResult<Generic> GetOfficeType(string spName)
        {
            return da.GetOfficeType(spName);
        }
        #endregion

    }
}
