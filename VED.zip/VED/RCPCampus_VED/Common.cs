﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using Microsoft.SharePoint;
using System.Net.Mail;
using Newtonsoft.Json;
using RCPCampus_VED.DTO;
using RCPCampus_VED.BusinessLayer;

namespace RCPCampus_VED
{

    public class Common
    {
        private static string connectionString = ConfigurationManager.ConnectionStrings["RCPCampusConnection"].ToString();//  
        public static void ErrorLog(Type type, string methodName, string request, string response, string createdBy, string executionContext, Exception exception = null, RequestType reqType = RequestType.Mobile)
        {
            //TODO : Uncomment the Ocde
            bool isLogging = Convert.ToBoolean(ConfigurationManager.AppSettings["IsLogging"]);
           // bool isLogging = Convert.ToBoolean("true");
            string exceptionMessage = string.Empty;
            if (exception != null)
            {
                exceptionMessage = "Stack Trace : " + exception.StackTrace + " Message : " + exception.Message + " InnerException : " + exception.InnerException;
            }

            try
            {
                string siteURL = Convert.ToString(ConfigurationManager.AppSettings["siteURL"]);
                if ((int)type == (int)Type.Error)
                {
                    using (SPSite oSPsite = new SPSite(siteURL))
                    {
                        using (SPWeb oSPWeb = oSPsite.OpenWeb())
                        {
                            SPList lst = oSPWeb.Lists["ErrorLog"];
                            SPListItem item = lst.Items.Add();
                            item["ErrorType"] = (int)type;
                            item["MethodName"] = methodName;
                            item["ExecutionContext"] = executionContext;
                            item["Request"] = request;
                            item["Response"] = "Response : " + response + "Exception :" + exceptionMessage;
                            item["RequestType"] = (int)reqType;
                            oSPsite.AllowUnsafeUpdates = true;
                            item.Update();
                            oSPsite.AllowUnsafeUpdates = false;
                        }
                    }
                }
                else
                {
                    if (isLogging)
                    {

                        {
                            using (SqlConnection conn = new SqlConnection(connectionString))
                            {
                                conn.Open();
                                SqlCommand cmd = new SqlCommand();
                                cmd.Connection = conn;
                                cmd.CommandType = CommandType.StoredProcedure;
                                cmd.CommandText = "usp_InsertErrorLog";
                                cmd.Parameters.AddWithValue("@Type ", type);
                                cmd.Parameters.AddWithValue("@MethodName ", methodName);
                                cmd.Parameters.AddWithValue("@Request ", request);
                                cmd.Parameters.AddWithValue("@Response ", "Response : " + response + "Exception :" + exceptionMessage);
                                cmd.Parameters.AddWithValue("@CreatedBy ", createdBy);
                                cmd.Parameters.AddWithValue("@ExecutionContext", executionContext);
                                cmd.Parameters.AddWithValue("@RequestType", reqType);
                                int rowsAffected = cmd.ExecuteNonQuery();
                                if (rowsAffected < 1)
                                {
                                    ErrorLog1(methodName, request, response, createdBy, executionContext, null);
                                }
                            }
                        }
                    }
                }
            }

            catch (Exception ex)
            {

                //  ErrorLog1(methodName, request, response, createdBy, executionContext, ex);
            }
        }
        public static void ErrorLog1(string methodName, string request, string response, string createdBy, string executionContext, Exception exception = null)
        {
            string exceptionMessage = string.Empty;
            if (exception != null)
            {
                exceptionMessage = "Stack Trace : " + exception.StackTrace + " Message : " + exception.Message + " InnerException : " + exception.InnerException;
            }

            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "usp_InsertErrorLog";
                    cmd.Parameters.AddWithValue("@Type ", "1");
                    cmd.Parameters.AddWithValue("@MethodName ", methodName + " : Error 1");
                    cmd.Parameters.AddWithValue("@Request ", request);
                    cmd.Parameters.AddWithValue("@Response ", "Response : " + response + "Exception :" + exceptionMessage);
                    cmd.Parameters.AddWithValue("@CreatedBy ", createdBy);
                    cmd.Parameters.AddWithValue("@ExecutionContext", executionContext);
                    cmd.Parameters.AddWithValue("@RequestType", "1");
                    int rowsAffected = cmd.ExecuteNonQuery();
                    if (rowsAffected < 1)
                    {
                        //ErrorLog1(methodName, request, response, createdBy, executionContext, null);
                    }
                }
            }
            catch (Exception)
            {
                //using (SqlConnection conn = new SqlConnection(connectionString))
                //{
                //    conn.Open();
                //    SqlCommand cmd = new SqlCommand();
                //    cmd.Connection = conn;
                //    cmd.CommandType = CommandType.StoredProcedure;
                //    cmd.CommandText = "usp_InsertErrorLog";
                //    cmd.Parameters.AddWithValue("@Type ", type);
                //    cmd.Parameters.AddWithValue("@MethodName ", methodName);
                //    cmd.Parameters.AddWithValue("@Request ", request);
                //    cmd.Parameters.AddWithValue("@Response ", "Stack Trace : " + ex.StackTrace + " Message : " + ex.Message + " InnerException : " + ex.InnerException);
                //    cmd.Parameters.AddWithValue("@CreatedBy ", createdBy);
                //    cmd.Parameters.AddWithValue("@ExecutionContext", executionContext);
                //    //  cmd.Parameters.AddWithValue("@RequestType", reqType);
                //    int rowsAffected = cmd.ExecuteNonQuery();
                //}
                //ErrorLog1(methodName, request, response, createdBy, executionContext, ex);
            }
        }
        public static bool ValidateToken(string executionContext, string loginName)
        {
            bool isValidate = true;
            string request = "executionContext : " + executionContext + " loginName : " + loginName;
            //Common.ErrorLog(Type.Information, "ValidateToken : Start", request, "", loginName, currentContext, reqType: type);
            //List<VEDSchedule> VEDSchedules = new List<VEDSchedule>();
            //ServiceResult results = new ServiceResult();
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "usp_ValidateExecutionContext";
                    cmd.Parameters.AddWithValue("@LoginName", loginName);
                    cmd.Parameters.AddWithValue("@ExecutionContext", executionContext);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);
                    if (ds.Tables.Count > 0)
                    {
                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            isValidate = Convert.ToBoolean(ds.Tables[0].Rows[0]["Validate"]);
                        }
                    }
                }
                //Common.ErrorLog(Type.Information, "AddVEDSchedule : End", request, JsonConvert.SerializeObject(results), loggedInUser, currentContext, reqType: type);
            }
            catch (Exception ex)
            {
                //results.ErrorCode = "0";
                //results.ErrorMessage = "Oops! Something went wrong, please try again.";
                //results.ExecutionContext = currentContext;
                //Common.ErrorLog(Type.Error, "GetAllCenters : End", request, "", loggedInUser, currentContext, ex, reqType: type);

            }
            return isValidate;
        }
        //public static void SendPoorMail(List<MailData> mailDetails, string loginName, string executionContext)
        //{
        //    string mailFrom = ConfigurationManager.AppSettings["fromEmail"].ToString();
        //    string smtpServer = ConfigurationManager.AppSettings["smtpServer"].ToString();
        //    string mailSubject = ConfigurationManager.AppSettings["mailSubject"].ToString();
        //    string helpdesk = ConfigurationManager.AppSettings["helpdesk"].ToString();
        //    try
        //    {
        //        foreach (MailData item in mailDetails)
        //        {
        //            if (!string.IsNullOrEmpty(mailFrom))
        //            {
        //                StringBuilder body = new StringBuilder();
        //                body.Append("Dear Sir/Madam,");
        //                body.AppendLine();
        //                body.Append("Request has been generated. Please find the details.");
        //                body.AppendLine();
        //                body.Append("Zone : " + item.Zone + "");
        //                body.AppendLine();
        //                body.Append("State : " + item.State + "");
        //                body.AppendLine();
        //                body.Append("City : " + item.City + "");
        //                body.AppendLine();
        //                body.Append("Jio Centre No. : " + item.Center + "");
        //                body.AppendLine();
        //                body.Append("CheckAssessment Condition : Poor");
        //                body.AppendLine();
        //                body.Append("Facility Area : " + item.FacilityArea + "");
        //                body.AppendLine();
        //                body.Append("Facility Details : " + item.FacilityDetails + "");
        //                body.AppendLine();
        //                body.Append("Comments : " + item.Comments + "");
        //                body.AppendLine();
        //                body.Append("Created By : " + item.ScheduleBy + "");
        //                body.AppendLine();
        //                body.Append("Creation Date : " + DateTime.Now + "");
        //                body.AppendLine();
        //                body.Append("Best regards,");
        //                body.AppendLine();
        //                body.Append("JIO VED Team");
        //                body.AppendLine();
        //                body.Append("***Note: This is an auto generated mail. Please do not reply to this email id.");
        //                MailAddress emailFrom = new MailAddress(mailFrom, SPContext.Current.Web.AllUsers["i:0#.w|in\\" + item.ScheduleBy + ""].Name);
        //                //  emailFrom.DisplayName = 
        //                string CCEmail = string.Empty;
        //                if (!string.IsNullOrEmpty(Convert.ToString(item.StateHeadID)))
        //                {
        //                    CCEmail = SPContext.Current.Web.AllUsers["i:0#.w|in\\" + item.StateHeadID + ""].Email;
        //                }
        //                string emailID = SPContext.Current.Web.AllUsers["i:0#.w|in\\" + item.ScheduleBy + ""].Email;
        //                //  emailID += "," + helpdesk;
        //                MailMessage mail = new MailMessage();
        //                //mail.IsBodyHtml = true;
        //                mail.From = emailFrom;
        //                mail.To.Add(helpdesk);
        //                mail.To.Add(emailID);
        //                if (!string.IsNullOrEmpty(CCEmail))
        //                {
        //                    mail.CC.Add(CCEmail);
        //                }
        //                mail.Subject = mailSubject;
        //                mail.SubjectEncoding = System.Text.UTF8Encoding.UTF8;
        //                mail.Body = body.ToString();
        //                mail.BodyEncoding = System.Text.UTF8Encoding.UTF8;
        //                mail.IsBodyHtml = false;
        //                SmtpClient smtp = new SmtpClient(smtpServer);
        //                smtp.UseDefaultCredentials = true;
        //                smtp.Send(mail);
        //                UpdateAssessmentTable(item.Comments, Convert.ToInt32(item.ID), emailID);
        //            }
        //        }


        //    }
        //    catch (Exception ex)
        //    {

        //        Common.ErrorLog(Type.Information, "VEDAssessment : SendPoorMail", "", JsonConvert.SerializeObject(mailDetails), loginName, executionContext, null, RequestType.Portal);
        //    }

        //}
        //private void UpdateAssessmentTable(string comments, int ID, string mailSentTO, string loginName, string executionContext)
        //{
        //    Business BL = new Business();
        //    try
        //    {
        //        string[] arr = new string[5];
        //        arr[0] = "MailComments=" + comments;
        //        // arr[1] = "MailSentDate=" + DateTime.Now;
        //        arr[1] = "MailSentToEmailID=" + mailSentTO;
        //        arr[2] = "IsMailSent=" + 1;
        //        arr[3] = "ID=" + ID;
        //        arr[4] = "UserID=" + loginName;
        //        ServiceResult<Generic> results = BL.GenericMethod("usp_Report_UpdateMailDetailsBasedOnID", executionContext, loginName, RequestType.Portal, arr);
        //        DataSet ds = JsonConvert.DeserializeObject<DataSet>(results.Data.ResultData);
        //        // BindPoorData(Page.Request.QueryString["VEDID"].ToString());
        //    }
        //    catch (Exception)
        //    {

        //        throw;
        //    }
        //}


        public static DataSet GettingMailDetails(string vedID, string loginName, string executionContext, RequestType reqType = RequestType.Mobile)
        {
            Business BL = new Business();
            string[] arr = new string[1];
            arr[0] = "VEDScheduleID=" + vedID;
            ServiceResult<Generic> resultGeneric = BL.GenericMethod("usp_Report_GetMailDetails", executionContext, loginName, reqType, arr);
            DataSet ds = JsonConvert.DeserializeObject<DataSet>(resultGeneric.Data.ResultData);
            return ds;
        }

        public static DataSet GettingAreaDetails(string facilityAreaID, string facilityDetail, string loginName, string executionContext, RequestType reqType = RequestType.Mobile)
        {

            Business BL = new Business();
            string[] arr = new string[2];
            arr[0] = "FacilityArea=" + facilityAreaID;
            arr[1] = "FacilityDetails=" + facilityDetail;
            ServiceResult<Generic> resultGeneric = BL.GenericMethod("usp_Get_MasterDataByID", executionContext, loginName, reqType, arr);
            DataSet ds = JsonConvert.DeserializeObject<DataSet>(resultGeneric.Data.ResultData);
            return ds;
        }

        public static void SendPoorMail(List<MailData> mailDetails, string loginName, string executionContext, RequestType reqType = RequestType.Mobile)
        {
            string mailFrom = ConfigurationManager.AppSettings["fromEmail"].ToString();
            string smtpServer = ConfigurationManager.AppSettings["smtpServer"].ToString();
            string mailSubject = ConfigurationManager.AppSettings["mailSubject"].ToString();
            string helpdesk = ConfigurationManager.AppSettings["helpdesk"].ToString();
            string SiteUrl = ConfigurationManager.AppSettings["SiteUrl"].ToString();
            try
            {
                //string body = string.Empty;
                foreach (MailData item in mailDetails)
                {
                    if (!string.IsNullOrEmpty(mailFrom))
                    {
                        try
                        {
                            StringBuilder body = new StringBuilder();
                            //body += "Dear Sir/Madam,<br /><br />Request has been generated. Please find the details.";
                            //body += "<table  id='tblVEDReport' runat='server' style='width:90%; border:1px solid black; border-collapse: collapse'>";
                            //body += "<tr><th style='padding: 8px; color: White; background-color: #507CD1; font-weight: bold; border:1px solid black;'>Zone</th>";
                            //body += "<th style='padding: 8px; color: White; background-color: #507CD1; font-weight: bold; border:1px solid black;'>State</th>";
                            //body += "<th style='padding: 8px; color: White; background-color: #507CD1; font-weight: bold; border:1px solid black;'>City</th>";
                            //body += "<th style='padding: 8px; color: White; background-color: #507CD1; font-weight: bold; border:1px solid black;'>Jio Centre No.</th>";
                            //body += "<th style='padding: 8px; color: White; background-color: #507CD1; font-weight: bold; border:1px solid black;'>CheckAssessment Condition</th>";
                            //body += "<th style='padding: 8px; color: White; background-color: #507CD1; font-weight: bold; border:1px solid black;'>Facility Area</th>";
                            //body += "<th style='padding: 8px; color: White; background-color: #507CD1; font-weight: bold; border:1px solid black;'>Facility Details</th>";
                            //body += "<th style='padding: 8px; color: White; background-color: #507CD1; font-weight: bold; border:1px solid black;'>Comments</th>";
                            //body += "<th style='padding: 8px; color: White; background-color: #507CD1; font-weight: bold; border:1px solid black;'>Created By</th>";
                            //body += "<th style='padding: 8px; color: White; background-color: #507CD1; font-weight: bold; border:1px solid black;'>Creation Date</th>";
                            //body += "</tr>";
                            //body += "<tr>";
                            //body += "<td style='border:1px solid black; padding: 8px; align=center'>" + item.Zone + "</td>";
                            //body += "<td style='border:1px solid black; padding: 8px; align=center'>" + item.State + "</td>";
                            //body += "<td style='border:1px solid black; padding: 8px; align=center'>" + item.City + "</td>";
                            //body += "<td>" + item.Center + "</td>";
                            //body += "<td style='border:1px solid black; padding: 8px; align=center'>Poor</td>";
                            //body += "<td style='border:1px solid black; padding: 8px; align=center'>" + item.FacilityArea + "</td>";
                            //body += "<td style='border:1px solid black; padding: 8px; align=center'>" + item.FacilityDetails + "</td>";
                            //body += "<td style='border:1px solid black; padding: 8px; align=center'>" + item.Comments + "</td>";
                            //body += "<td style='border:1px solid black; padding: 8px; align=center'>" + item.ScheduleBy + "</td>";
                            //body += "<td style='border:1px solid black; padding: 8px; align=center'>" + DateTime.Now + "</td>";
                            //body += "</tr>";
                            //body += "</table>";


                            //body += "<span>Best regards,</span></br>";
                            //body += "JIO VED Team</br>";
                            //body += "<br /><br />***Note: This is an auto generated mail. Please do not reply to this email id.<br />";
                            body.Append("Dear Sir/Madam,");
                            body.AppendLine();
                            body.Append("Request has been generated. Please find the details.");
                            body.AppendLine();
                            body.Append("Zone : " + item.Zone + "");
                            body.AppendLine();
                            body.Append("State : " + item.State + "");
                            body.AppendLine();
                            body.Append("City : " + item.City + "");
                            body.AppendLine();
                            body.Append("Jio Centre No. : " + item.Center + "");
                            body.AppendLine();
                            body.Append("CheckAssessment Condition : Poor");
                            body.AppendLine();
                            body.Append("Facility Area : " + item.FacilityArea + "");
                            body.AppendLine();
                            body.Append("Facility Details : " + item.FacilityDetails + "");
                            body.AppendLine();
                            body.Append("Comments : " + item.Comments + "");
                            body.AppendLine();
                            body.Append("Created By : " + item.ScheduleBy + "");
                            body.AppendLine();
                            body.Append("Creation Date : " + DateTime.Now + "");
                            body.AppendLine();
                            body.Append("Best regards,");
                            body.AppendLine();
                            body.Append("JIO VED Team");
                            body.AppendLine();
                            body.Append("***Note: This is an auto generated mail. Please do not reply to this email id.");
                            MailAddress emailFrom = new MailAddress(mailFrom, SPContext.Current.Web.AllUsers["i:0#.w|in\\" + item.ScheduleBy + ""].Name);
                            //  emailFrom.DisplayName = 
                            string CCEmail = string.Empty;
                            SPSite site = new SPSite(SiteUrl);
                            SPWeb Web;
                            if (!string.IsNullOrEmpty(Convert.ToString(item.StateHeadID)))
                            {
                                //new SPFieldUserValue(web, item[SPBuiltInFieldId.Author].ToString());
                                //SPFieldUserValue userValue =
                                //new SPFieldUserValue(SPContext.Current.Web.AllUsers, item.StateHeadI;
                                //SPUser user = userValue.User;
                                //string email = user.Email;

                               
                                SPSecurity.RunWithElevatedPrivileges(delegate()
                                {
                                    using (Web = site.OpenWeb())
                                    {
                                        string user = Web.CurrentUser.Name;
                                        CCEmail = Web.AllUsers["i:0#.w|in\\" + item.StateHeadID + ""].Email;
                                        //Operations that need high level access.
                                    }

                                });

                                //CCEmail = web.AllUsers["i:0#.w|in\\" + item.StateHeadID + ""].Email;
                            }
                            SPSite site1 = new SPSite(SiteUrl);
                            SPWeb Web1;
                            string emailID = string.Empty;
                            SPSecurity.RunWithElevatedPrivileges(delegate()
                            {
                                using (Web1 = site1.OpenWeb())
                                {
                                    string user = Web1.CurrentUser.Name;
                                    emailID = Web1.AllUsers["i:0#.w|in\\" + item.ScheduleBy + ""].Email;
                                    //Operations that need high level access.
                                }

                            });
                            
                            //  emailID += "," + helpdesk;
                            MailMessage mail = new MailMessage();
                            //mail.IsBodyHtml = true;
                            mail.From = emailFrom;
                            mail.To.Add(helpdesk);
                            mail.To.Add(emailID);
                            if (!string.IsNullOrEmpty(CCEmail))
                            {
                                mail.CC.Add(CCEmail);
                            }
                            mail.Subject = mailSubject;
                            mail.SubjectEncoding = System.Text.UTF8Encoding.UTF8;
                            mail.Body = body.ToString();
                            mail.BodyEncoding = System.Text.UTF8Encoding.UTF8;
                            mail.IsBodyHtml = false;
                            SmtpClient smtp = new SmtpClient(smtpServer);
                            smtp.UseDefaultCredentials = true;
                            smtp.Send(mail);
                            UpdateAssessmentTable(item.Comments, Convert.ToInt32(item.ID), emailID, item.VEDScheduleID, loginName, executionContext);
                        }
                        catch (Exception ex)
                        {

                            Common.ErrorLog(Type.Error, "VEDAssessment : SendPoorMail_loop", "", JsonConvert.SerializeObject(item), loginName, executionContext, ex, RequestType.Portal);
                        }
                    }
                }


            }
            catch (Exception ex)
            {

                Common.ErrorLog(Type.Error, "VEDAssessment : SendPoorMail", "", JsonConvert.SerializeObject(mailDetails), loginName, executionContext, ex, RequestType.Portal);
            }

        }
        private static void UpdateAssessmentTable(string comments, int ID, string mailSentTO, int VEDScheduleID,string loginName, string executionContext)
        {

            try
            {
                Business BL = new Business();
                string[] arr = new string[6];
                arr[0] = "MailComments=" + comments;
                // arr[1] = "MailSentDate=" + DateTime.Now;
                arr[1] = "MailSentToEmailID=" + mailSentTO;
                arr[2] = "IsMailSent=" + 1;
                arr[3] = "ID=" + ID;
                arr[4] = "UserID=" + loginName;
                arr[5] = "VEDScheduleID=" + VEDScheduleID;
                ServiceResult<Generic> results = BL.GenericMethod("usp_Report_UpdateMailDetailsBasedOnID", executionContext, loginName, RequestType.Portal, arr);
                DataSet ds = JsonConvert.DeserializeObject<DataSet>(results.Data.ResultData);
                // BindPoorData(Page.Request.QueryString["VEDID"].ToString());
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
    public class AttachmentVar
    {
        public static string Attachment = "Attachment";
        public static string FileName = "FileName";
        public static string FilePath = "FilePath";
        public static string FileGUID = "FileGUID";
        public static string FileDelete = "FileDelete";
        public static string FolderGUID = "FolderGUID";
        //Attachment Columns for Operational data
        public static string ID = "ID";
        public static string OperationalStatus = "OperationalStatus";
        public static string RowIndex = "RowIndex";
        public static string Index = "Index";
        public static string ParentIndex = "ParentIndex";
        public static string AttachmentsList = "Attachments";
    }
    public enum RequestType
    {
        Mobile = 1,
        Portal,
        IOS
    }
    public enum Type
    {
        Error = 0,
        Information
    }
    public enum AssessmentType
    {
        AreaLevel = 1,
        StateLevel,
        ZoneLevel
    }
}




