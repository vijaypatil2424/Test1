﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCPCampus_VED.DTO
{
    public class AssesstmentDetails : FacilityMaster
    {
        public int VEDScheduleID { get; set; }
        public string Condition { get; set; }
        public int Points { get; set; }
        public string AssessmentDoneBy { get; set; }
        public DateTime AssessmentDate { get; set; }
        public string Comments { get; set; }
        public bool IsImageAvailable { get; set; }
        public string ImageURL { get; set; }
        public string AuditorComment { get; set; }
        public string AuditorCondition { get; set; }
    }
}
