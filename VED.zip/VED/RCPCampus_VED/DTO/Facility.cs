﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCPCampus_VED.DTO
{
    [Serializable]
    public class Facility
    {
        public List<ScoringMaster> ScoringMaster { get; set; }
        public List<FacilityMaster> FacilityMaster { get; set; }
        public List<VEDFinalData> VEDSchedules { get; set; }
    }
}
