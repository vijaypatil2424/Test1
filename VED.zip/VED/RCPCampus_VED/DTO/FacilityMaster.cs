﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCPCampus_VED.DTO
{
    [Serializable]
    public class FacilityMaster
    {
        public int ID { get; set; }
        public int FacilityAreaID { get; set; }
        public string FacilityArea { get; set; }
        public int FacilityDetailsID { get; set; }
        public string FacilityDetails { get; set; }
        public int CriticalityID { get; set; }
        public string Criticality { get; set; }
        public int OfficetypeID { get; set; }
        public string Officetype { get; set; }
        public string Comments { get; set; }
        
        public string AuditorComment { get; set; }
        //public CommonDDL Criticality { get; set; }
    }
}
