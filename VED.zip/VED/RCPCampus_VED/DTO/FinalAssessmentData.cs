﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCPCampus_VED.DTO
{
    public class FinalAssessmentData
    {
        public List<AssesstmentDetails> AssesstmentDetails { get; set; }
        public List<VEDFinalData> VEDFinalData { get; set; }
    }
}
