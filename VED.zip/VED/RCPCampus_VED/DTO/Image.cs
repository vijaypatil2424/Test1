﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCPCampus_VED.DTO
{
    public class Image : AssesstmentDetails
    {
        public string ImageContent { get; set; }
        public string ImageName { get; set; }
        public byte[] ImageContentBytes { get; set; }
        public string ImageType { get; set; }
        public string ImageSize { get; set; }
        public string ImageExtension { get; set; }
    }
}
