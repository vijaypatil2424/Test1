﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCPCampus_VED.DTO
{
    public class MailData
    {
        //body = "<span>Kindly create corporate service Help Desk complaint as per following details : </span></br>"
        //                  + "<span>Zone : " + ds.Tables[0].Rows[0]["Zone"].ToString() + " </span></br>"
        //                  + "<span>State : " + ds.Tables[0].Rows[0]["State"].ToString() + " </span></br>"
        //                  + "<span>City : " + ds.Tables[0].Rows[0]["city"].ToString() + " </span></br>"
        //                  + "<span>Jio Centre No. : " + ds.Tables[0].Rows[0]["CEnter"].ToString() + " </span></br>"
        //                  + "<span>Assessment condition : Poor </span></br>"
        //                    + "<span>Facility Area  : " + hdnFacilityArea.Value + " </span></br>"
        //                + "<span>Facility Details  : " + hdnFacilityDetails.Value + " </span></br>"
        //                + "<span>Assessment comments : " + hdnComments.Value + " </span></br>"
        //                 + "<span>Created by : " + ds.Tables[0].Rows[0]["Created On"].ToString() + " </span></br>"
        //                 + "<span>Comments : " + hdnActualComments.Value + " </span></br>"
        //                 + "</br></br>"
        //                 + "<span>Best regards,</span></br>"
        //                 + "Jio VED Team</br>";



        public string Zone { get; set; }
        public string ID { get; set; }
        public string State { get; set; }
        public string City { get; set; }
        public string Center { get; set; }
        public string AssessmentCondition { get; set; }
        public string FacilityArea { get; set; }
        public string FacilityDetails { get; set; }
        public string CreatedOn { get; set; }
        public string Comments { get; set; }
        public string ScheduleBy { get; set; }
        public string StateHeadID { get; set; }
        public int VEDScheduleID { get; set; }
    }
}
