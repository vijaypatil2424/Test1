﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCPCampus_VED.DTO
{
    [Serializable]
    public class Office
    {
        public string ID { get; set; }
        public string Center { get; set; }
        public string Zone { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string OfficeCategory { get; set; }
        public string OfficeType { get; set; }
        public string CarpetArea { get; set; }
        public string Latitude { get; set; }
        public string Longitude { get; set; }
        public string OfficeAdmins { get; set; }
        public string Area { get; set; }
    }
}
