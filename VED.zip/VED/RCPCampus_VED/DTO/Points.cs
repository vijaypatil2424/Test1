﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCPCampus_VED.DTO
{
    public class Points
    {
        public int OnTime { get; set; }
        public int WithAcceptableDelay { get; set; }
        public int WithNotAcceptableDelay { get; set; }
        public int NotDone { get; set; }
        public int NotScheduled { get; set; }
    }
}
