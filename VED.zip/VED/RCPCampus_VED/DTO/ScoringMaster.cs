﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCPCampus_VED.DTO
{
    [Serializable]
    public class ScoringMaster
    {
        public string OfficeType { get; set; }
        public string Criticality { get; set; }
        public int FacilityCheckPoints { get; set; }
        public int Good { get; set; }
        public int Poor { get; set; }
        public int NotWorking { get; set; }
        public int NotAvailable { get; set; }
    }
}
