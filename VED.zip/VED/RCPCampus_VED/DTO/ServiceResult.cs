﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCPCampus_VED.DTO
{
    [Serializable]
    public class ServiceResult
    {
        public string ErrorCode { get; set; }
        public string ErrorMessage { get; set; }
        public string ExecutionContext { get; set; }
        private string currentDate = DateTime.Now.Day + "-" + DateTime.Now.Month + "-" + DateTime.Now.Year;
        public string CurrentDate
        {
            get
            {
                return currentDate;
            }
        }
    }
    [Serializable]
    public class ServiceResult<T> : ServiceResult
    {
        public T Data { get; set; }
    }
}
