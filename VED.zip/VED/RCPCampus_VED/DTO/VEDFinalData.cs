﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCPCampus_VED.DTO
{
    [Serializable]
    public class VEDFinalData : VEDSchedule
    {
        public double Vital { get; set; }
        public double Essential { get; set; }
        public double Desirable { get; set; }
        public double TotalVEDByType { get; set; }
        public double VitalNotApplicable { get; set; }
        public double EssentialNotApplicable { get; set; }
        public double DesirableNotApplicable { get; set; }
        public double VEDSCORE { get; set; }
        public double MAXVEDSCORE { get; set; }
        public double VEDSCOREPER { get; set; }
        public int VEDScheduleId { get; set; }
    }

}
