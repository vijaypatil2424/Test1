﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RCPCampus_VED.DTO
{
    [Serializable]
    public class VEDSchedule : Office
    {
        public string VEDID { get; set; }
        public string OfficeID { get; set; }
        public string ScheduledOn { get; set; }
        public string ScheduledBy { get; set; }
        public string ActualAssesstmentDate { get; set; }
        public string AuditingDate { get; set; }
        public bool IsEditAllowed { get; set; }
        public int OfficeTypeID { get; set; }
        public string URL { get; set; }
    }
}
