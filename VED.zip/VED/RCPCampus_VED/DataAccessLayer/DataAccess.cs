﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;
using RCPCampus_VED.DTO;
using Newtonsoft.Json;
using Microsoft.SharePoint;
using System.Configuration;
using Microsoft.SharePoint.Utilities;

namespace RCPCampus_VED.DataAccessLayer
{
    public class DataAccess
    {
        //  private const string connectionString = "Data Source=SP13DEVDB01;Initial Catalog=VEDDB;User Id=veduser;Password =pass@123";
        private string connectionString = ConfigurationManager.ConnectionStrings["RCPCampusConnection"].ToString();
        string executionContextP = Guid.NewGuid().ToString();

        #region VED Schedules

        private string ValidateExecutionContext(string executionContext, string loggedInUser, RequestType type = RequestType.Portal)
        {
            string executionContext_C = string.Empty;
            if (type == RequestType.Portal)
            {
                executionContext_C = Guid.NewGuid().ToString();
            }
            else
            {
                if (string.IsNullOrEmpty(executionContext))
                {
                    //Create New 
                    ServiceResult result = LoginLogOut(executionContextP, loggedInUser, "LOGIN");
                    executionContext_C = result.ExecutionContext;
                }
                else if (Common.ValidateToken(executionContext, loggedInUser))
                {
                    executionContext_C = executionContext;
                }
                else
                {
                    executionContext_C = string.Empty;
                }
            }
            return executionContext_C;

        }
        public ServiceResult<List<CommonDDL>> GetAllCentersByUserID(string userName, string executionContext, string loggedInUser,string officeType,RequestType type = RequestType.Mobile)
        {
            //ServiceResult<List<AssesstmentDetails>> results = new ServiceResult<List<AssesstmentDetails>>();

            //AssesstmentDetails obj = new AssesstmentDetails();
            //List<Image> images = new List<Image>();
            //obj.ImageContent = images;
            //obj.FacilityDetailsID = 1;
            //obj.FacilityAreaID = 1;


            //List<AssesstmentDetails> data = new List<AssesstmentDetails>();
            //data.Add(obj);


            //results.Data = data;
            ServiceResult<List<CommonDDL>> results = new ServiceResult<List<CommonDDL>>();
            string currentContext = string.Empty;
            string request = "UserName : " + userName;
            executionContext = ValidateExecutionContext(executionContext, userName, type);
            if (!string.IsNullOrEmpty(executionContext))
            {
                currentContext = executionContext;
                Common.ErrorLog(Type.Information, "GetAllCentersByUserID : Start", request, "", loggedInUser, currentContext, reqType: type);
                List<CommonDDL> items = new List<CommonDDL>();

                try
                {
                    if (!string.IsNullOrEmpty(userName))
                    {
                        using (SqlConnection conn = new SqlConnection(connectionString))
                        {
                            conn.Open();
                            SqlCommand cmd = new SqlCommand();
                            cmd.Connection = conn;
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.CommandText = "usp_GetAllVEDSchedule";
                            cmd.Parameters.AddWithValue("@UserID", userName);
                            cmd.Parameters.AddWithValue("@Type", "GETALLVED");
                            cmd.Parameters.AddWithValue("@OfficeType", officeType);
                            SqlDataAdapter da = new SqlDataAdapter(cmd);
                            DataSet ds = new DataSet();
                            da.Fill(ds);
                            if (ds.Tables.Count > 0)
                            {
                                if (ds.Tables[0].Rows.Count > 0)
                                {
                                    results.ErrorCode = "1";
                                    results.ErrorMessage = "Success";
                                    results.ExecutionContext = currentContext;
                                    // List<CommonDDL> colls = new List<CommonDDL>();
                                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                                    {
                                        CommonDDL ddl = new CommonDDL();
                                        ddl.ID = Convert.ToInt32(ds.Tables[0].Rows[i]["ID"]);
                                        ddl.Title = ds.Tables[0].Rows[i]["Title"].ToString();
                                        items.Add(ddl);

                                    }
                                    results.Data = items;
                                }
                                else
                                {
                                    results.ErrorCode = "0";
                                    results.ErrorMessage = "No Center found.";
                                    results.ExecutionContext = currentContext;
                                }
                            }
                            else
                            {
                                results.ErrorCode = "0";
                                results.ErrorMessage = "No Center found.";
                                results.ExecutionContext = currentContext;
                            }
                        }
                    }
                    else
                    {
                        results.ErrorCode = "0";
                        results.ErrorMessage = "UserName not found";
                        results.ExecutionContext = currentContext;
                    }

                    Common.ErrorLog(Type.Information, "GetAllCentersByUserID : End", request, JsonConvert.SerializeObject(results), loggedInUser, currentContext, reqType: type);

                }
                catch (Exception ex)
                {
                    results.ErrorCode = "0";
                    results.ErrorMessage = "Oops! Something went wrong, please try again.";
                    results.ExecutionContext = currentContext;
                    Common.ErrorLog(Type.Error, "GetAllCentersByUserID : End", request, "", loggedInUser, currentContext, ex, reqType: type);

                }
            }
            else
            {
                results.ErrorCode = "0";
                results.ErrorMessage = "Invalid Token.";
                results.ExecutionContext = currentContext;
            }
            return results;
        }
        public ServiceResult<Office> GetCenterDetailsByID(string centerID, string executionContext, string loggedInUser, RequestType type = RequestType.Mobile)
        {
            string currentContext = string.Empty;
            string request = "centerID : " + centerID;
            Office office = new Office();
            ServiceResult<Office> results = new ServiceResult<Office>();
            executionContext = ValidateExecutionContext(executionContext, loggedInUser, type);
            if (!string.IsNullOrEmpty(executionContext))
            {
                currentContext = executionContext;
                Common.ErrorLog(Type.Information, "GetCenterDetailsByID : Start", request, "", loggedInUser, currentContext, reqType: type);

                try
                {
                    if (!string.IsNullOrEmpty(centerID))
                    {
                        using (SqlConnection conn = new SqlConnection(connectionString))
                        {
                            conn.Open();
                            SqlCommand cmd = new SqlCommand();
                            cmd.Connection = conn;
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.CommandText = "usp_GetAllVEDSchedule";
                            cmd.Parameters.AddWithValue("@OfficeID", centerID);
                            cmd.Parameters.AddWithValue("@Type", "GETBYOFFICEID");
                            SqlDataAdapter da = new SqlDataAdapter(cmd);
                            DataSet ds = new DataSet();
                            da.Fill(ds);
                            if (ds.Tables.Count > 0)
                            {
                                if (ds.Tables[0].Rows.Count > 0)
                                {
                                    results.ErrorCode = "1";
                                    results.ErrorMessage = "Success";
                                    results.ExecutionContext = currentContext;
                                    office.ID = Convert.ToString(ds.Tables[0].Rows[0]["ID"]);
                                    office.Zone = Convert.ToString(ds.Tables[0].Rows[0]["Zone"]);
                                    office.City = Convert.ToString(ds.Tables[0].Rows[0]["City"]);
                                    office.Address = Convert.ToString(ds.Tables[0].Rows[0]["Address"]);
                                    office.OfficeType = Convert.ToString(ds.Tables[0].Rows[0]["OfficeType"]);
                                    office.OfficeCategory = Convert.ToString(ds.Tables[0].Rows[0]["OfficeCategory"]);
                                    office.Center = Convert.ToString(ds.Tables[0].Rows[0]["Center"]);
                                    office.CarpetArea = Convert.ToString(ds.Tables[0].Rows[0]["CarpetArea"]);
                                    office.Latitude = Convert.ToString(ds.Tables[0].Rows[0]["Latitude"]);
                                    office.Longitude = Convert.ToString(ds.Tables[0].Rows[0]["Longitude"]);
                                    office.OfficeAdmins = Convert.ToString(ds.Tables[0].Rows[0]["OfficeAdmins"]);
                                    office.Area = Convert.ToString(ds.Tables[0].Rows[0]["Area"]);
                                    results.Data = office;
                                }
                            }
                            else
                            {
                                results.ErrorCode = "0";
                                results.ErrorMessage = "No data found for Center ID";
                                results.ExecutionContext = currentContext;
                            }
                        }
                    }
                    else
                    {
                        results.ErrorCode = "0";
                        results.ErrorMessage = "CenterID not found";
                        results.ExecutionContext = currentContext;
                    }
                    Common.ErrorLog(Type.Information, "GetCenterDetailsByID : End", request, JsonConvert.SerializeObject(results), loggedInUser, currentContext, reqType: type);

                }
                catch (Exception ex)
                {
                    results.ErrorCode = "0";
                    results.ErrorMessage = "Oops! Something went wrong, please try again.";
                    results.ExecutionContext = currentContext;
                    Common.ErrorLog(Type.Error, "GetCenterDetailsByID : End", request, "", loggedInUser, currentContext, ex, reqType: type);

                }
            }
            else
            {
                results.ErrorCode = "0";
                results.ErrorMessage = "Invalid Token.";
                results.ExecutionContext = currentContext;
            }
            return results;
        }
        public ServiceResult<List<VEDSchedule>> GetAllScheduleForCurrentMonth(string userName, string executionContext, string loggedInUser,string officeType,RequestType type = RequestType.Mobile)
        {
            string currentContext = string.Empty;
            string request = "userName : " + userName;
            List<VEDSchedule> VEDSchedules = new List<VEDSchedule>();
            ServiceResult<List<VEDSchedule>> results = new ServiceResult<List<VEDSchedule>>();
            executionContext = ValidateExecutionContext(executionContext, userName, type);
            if (!string.IsNullOrEmpty(executionContext))
            {
                currentContext = executionContext;
                Common.ErrorLog(Type.Information, "GetAllScheduleForCurrentMonth : Start", request, "", loggedInUser, currentContext, reqType: type);

                try
                {
                    if (!string.IsNullOrEmpty(userName))
                    {
                        using (SqlConnection conn = new SqlConnection(connectionString))
                        {
                            conn.Open();
                            SqlCommand cmd = new SqlCommand();
                            cmd.Connection = conn;
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.CommandText = "usp_GetAllVEDSchedule";
                            cmd.Parameters.AddWithValue("@UserId", userName);
                            cmd.Parameters.AddWithValue("@Type", "GETALL");
                            cmd.Parameters.AddWithValue("@OfficeType", officeType);
                            SqlDataAdapter da = new SqlDataAdapter(cmd);
                            DataSet ds = new DataSet();
                            da.Fill(ds);
                            Common.ErrorLog(Type.Information, "GetAllScheduleForCurrentMonth : Step 1", request, JsonConvert.SerializeObject(ds), loggedInUser, currentContext, reqType: type);
                            if (ds.Tables.Count > 0)
                            {
                                if (ds.Tables[0].Rows.Count > 0)
                                {
                                    results.ErrorCode = "1";
                                    results.ErrorMessage = "Success";
                                    results.ExecutionContext = currentContext;


                                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                                    {
                                        VEDSchedule VEDSchedule = new DTO.VEDSchedule();
                                        VEDSchedule.VEDID = Convert.ToString(ds.Tables[0].Rows[i]["ID"]);
                                        VEDSchedule.OfficeID = Convert.ToString(ds.Tables[0].Rows[i]["OfficeID"]);
                                        VEDSchedule.ScheduledOn = Convert.ToString(ds.Tables[0].Rows[i]["ScheduledOn"]);
                                        VEDSchedule.ScheduledBy = Convert.ToString(ds.Tables[0].Rows[i]["ScheduledBy"]);
                                        VEDSchedule.ActualAssesstmentDate = ds.Tables[0].Rows[i]["ActualAssesstmentDate"] != null ? Convert.ToString(ds.Tables[0].Rows[i]["ActualAssesstmentDate"]) : "";
                                        VEDSchedule.Center = Convert.ToString(ds.Tables[0].Rows[i]["Center"]);
                                        VEDSchedule.Zone = Convert.ToString(ds.Tables[0].Rows[i]["Zone"]);
                                        VEDSchedule.Address = Convert.ToString(ds.Tables[0].Rows[i]["Address"]);
                                        VEDSchedule.City = Convert.ToString(ds.Tables[0].Rows[i]["City"]);
                                        VEDSchedule.OfficeCategory = Convert.ToString(ds.Tables[0].Rows[i]["OfficeCategory"]);
                                        VEDSchedule.OfficeType = Convert.ToString(ds.Tables[0].Rows[i]["OfficeType"]);
                                        VEDSchedule.CarpetArea = ds.Tables[0].Rows[i]["CarpetArea"].ToString();
                                        VEDSchedule.IsEditAllowed = Convert.ToBoolean(ds.Tables[0].Rows[i]["IsEditAllowed"]);
                                        VEDSchedule.Latitude = Convert.ToString(ds.Tables[0].Rows[0]["Latitude"]);
                                        VEDSchedule.Longitude = Convert.ToString(ds.Tables[0].Rows[0]["Longitude"]);
                                        VEDSchedule.OfficeAdmins = Convert.ToString(ds.Tables[0].Rows[0]["OfficeAdmins"]);
                                        VEDSchedule.URL = SPUrlUtility.CombineUrl(SPContext.Current.Web.Url, "/pages/Assessment.aspx?VEDID=" + VEDSchedule.VEDID + "&type=" + officeType + "&utype=" + officeType + "");
                                        //VEDSchedule.URL = SPUrlUtility.CombineUrl(SPContext.Current.Web.Url, "/pages/Assessment.aspx?VEDID=" + VEDSchedule.VEDID + "");
                                        VEDSchedules.Add(VEDSchedule);
                                    }
                                    results.Data = VEDSchedules;
                                }
                            }
                            else
                            {
                                results.ErrorCode = "0";
                                results.ErrorMessage = "No Schedules found.";
                                results.ExecutionContext = currentContext;
                            }
                        }
                    }
                    else
                    {
                        results.ErrorCode = "0";
                        results.ErrorMessage = "please provide the UserName";
                        results.ExecutionContext = currentContext;
                    }
                    Common.ErrorLog(Type.Information, "GetAllScheduleForCurrentMonth : End", request, JsonConvert.SerializeObject(results), loggedInUser, currentContext, reqType: type);

                }
                catch (Exception ex)
                {
                    results.ErrorCode = "0";
                    results.ErrorMessage = "Oops! Something went wrong, please try again.";
                    results.ExecutionContext = currentContext;
                    Common.ErrorLog(Type.Error, "GetAllScheduleForCurrentMonth : End", request, "", loggedInUser, currentContext, ex, reqType: type);

                }
            }
            else
            {
                results.ErrorCode = "0";
                results.ErrorMessage = "Invalid Token.";
                results.ExecutionContext = currentContext;
            }
            return results;
        }
        public ServiceResult AddVEDSchedule(string vedID, string officeID, string scheduledOn, string comments, string executionContext, string loggedInUser, RequestType type = RequestType.Mobile, AssessmentType assessmentType = AssessmentType.AreaLevel)
        {
            string currentContext = string.Empty;
            string request = "vedID : " + vedID + " officeID : " + officeID + " scheduledOn : " + scheduledOn + " comments : " + comments + " loggedInUser : " + loggedInUser + " assessmentType : " + assessmentType + "type : " + type;
            List<VEDSchedule> VEDSchedules = new List<VEDSchedule>();
            ServiceResult results = new ServiceResult();
            int ScheduleDoneFrom = Convert.ToInt32(type);
            executionContext = ValidateExecutionContext(executionContext, loggedInUser, type);
            if (!string.IsNullOrEmpty(executionContext))
            {
                currentContext = executionContext;
                Common.ErrorLog(Type.Information, "AddVEDSchedule : Start", request, "", loggedInUser, currentContext, reqType: type);

                try
                {
                    if (string.IsNullOrEmpty(officeID))
                    {
                        results.ErrorCode = "0";
                        results.ErrorMessage = "please provide Center ID.";
                        results.ExecutionContext = currentContext;
                    }
                    else if (string.IsNullOrEmpty(scheduledOn))
                    {
                        results.ErrorCode = "0";
                        results.ErrorMessage = "please provide Schedule Date";
                        results.ExecutionContext = currentContext;
                    }
                    else if (string.IsNullOrEmpty(loggedInUser))
                    {
                        results.ErrorCode = "0";
                        results.ErrorMessage = "please provide LoggedIn User";
                        results.ExecutionContext = currentContext;
                    }
                    else if (!string.IsNullOrEmpty(vedID) && string.IsNullOrEmpty(comments))
                    {

                        results.ErrorCode = "0";
                        results.ErrorMessage = "please provide comments";
                        results.ExecutionContext = currentContext;

                    }
                    else
                    {
                        using (SqlConnection conn = new SqlConnection(connectionString))
                        {
                            conn.Open();
                            SqlCommand cmd = new SqlCommand();
                            cmd.Connection = conn;
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.CommandText = "usp_InsertUpdateVEDSchedule";
                            cmd.Parameters.AddWithValue("@ID", vedID);
                            cmd.Parameters.AddWithValue("@UserID", loggedInUser);
                            cmd.Parameters.AddWithValue("@OfficeID", officeID);
                            cmd.Parameters.AddWithValue("@ScheduledOn", scheduledOn);
                            cmd.Parameters.AddWithValue("@Comments", comments);
                            cmd.Parameters.AddWithValue("@AssessmentType", assessmentType);
                            cmd.Parameters.AddWithValue("@ScheduleDoneFrom", ScheduleDoneFrom);
                            SqlDataAdapter da = new SqlDataAdapter(cmd);
                            DataSet ds = new DataSet();
                            da.Fill(ds);
                            if (ds.Tables.Count > 0)
                            {
                                if (ds.Tables[0].Rows.Count > 0)
                                {
                                    string errorCode = ds.Tables[0].Rows[0]["ErrorCode"].ToString();
                                    if (errorCode == "0")
                                    {
                                        results.ErrorCode = "0";
                                        results.ErrorMessage = ds.Tables[0].Rows[0]["ErrorMessage"].ToString();
                                        results.ExecutionContext = currentContext;
                                    }
                                    else
                                    {
                                        results.ErrorCode = "1";
                                        results.ErrorMessage = ds.Tables[0].Rows[0]["ErrorMessage"].ToString();
                                        results.ExecutionContext = currentContext;

                                    }
                                }
                            }
                        }
                        Common.ErrorLog(Type.Information, "AddVEDSchedule : End", request, JsonConvert.SerializeObject(results), loggedInUser, currentContext, reqType: type);
                    }


                }
                catch (Exception ex)
                {
                    results.ErrorCode = "0";
                    results.ErrorMessage = "Oops! Something went wrong, please try again.";
                    results.ExecutionContext = currentContext;
                    Common.ErrorLog(Type.Error, "GetAllCenters : End", request, "", loggedInUser, currentContext, ex, reqType: type);

                }
            }
            else
            {
                results.ErrorCode = "0";
                results.ErrorMessage = "Invalid Token.";
                results.ExecutionContext = currentContext;
            }
            return results;
        }

        public ServiceResult<VEDSchedule> GetScheduledVEDDetailsByID(string VEDID,string executionContext, string loggedInUser, RequestType type = RequestType.Mobile)
        {
            string currentContext = string.Empty;
            string request = "VEDID : " + VEDID;
            executionContext = ValidateExecutionContext(executionContext, loggedInUser, type);
            VEDSchedule VEDSchedule = new VEDSchedule();
            ServiceResult<VEDSchedule> results = new ServiceResult<VEDSchedule>();
            if (!string.IsNullOrEmpty(executionContext))
            {
                currentContext = executionContext;
                Common.ErrorLog(Type.Information, "GetScheduledVEDDetailsByID : Start", request, "", loggedInUser, currentContext, reqType: type);

                try
                {
                    if (!string.IsNullOrEmpty(VEDID))
                    {
                        using (SqlConnection conn = new SqlConnection(connectionString))
                        {
                            conn.Open();
                            SqlCommand cmd = new SqlCommand();
                            cmd.Connection = conn;
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.CommandText = "usp_GetAllVEDSchedule";
                            cmd.Parameters.AddWithValue("@ID", VEDID);
                            cmd.Parameters.AddWithValue("@Type", "GETBYID");
                            
                            SqlDataAdapter da = new SqlDataAdapter(cmd);
                            DataSet ds = new DataSet();
                            da.Fill(ds);
                            if (ds.Tables.Count > 0)
                            {
                                if (ds.Tables[0].Rows.Count > 0)
                                {
                                    results.ErrorCode = "1";
                                    results.ErrorMessage = "Success";
                                    results.ExecutionContext = currentContext;

                                    VEDSchedule.VEDID = Convert.ToString(ds.Tables[0].Rows[0]["ID"]);
                                    VEDSchedule.OfficeID = Convert.ToString(ds.Tables[0].Rows[0]["OfficeID"]);
                                    VEDSchedule.ScheduledOn = Convert.ToString(ds.Tables[0].Rows[0]["ScheduledOn"]);
                                    VEDSchedule.ScheduledBy = Convert.ToString(ds.Tables[0].Rows[0]["ScheduledBy"]);
                                    VEDSchedule.ActualAssesstmentDate = ds.Tables[0].Rows[0]["ActualAssesstmentDate"] != null ? Convert.ToString(ds.Tables[0].Rows[0]["ActualAssesstmentDate"]) : "";
                                    VEDSchedule.Center = Convert.ToString(ds.Tables[0].Rows[0]["Center"]);
                                    VEDSchedule.Zone = Convert.ToString(ds.Tables[0].Rows[0]["Zone"]);
                                    VEDSchedule.Address = Convert.ToString(ds.Tables[0].Rows[0]["Address"]);
                                    VEDSchedule.City = Convert.ToString(ds.Tables[0].Rows[0]["City"]);
                                    VEDSchedule.OfficeCategory = Convert.ToString(ds.Tables[0].Rows[0]["OfficeCategory"]);
                                    VEDSchedule.OfficeType = Convert.ToString(ds.Tables[0].Rows[0]["OfficeType"]);
                                    VEDSchedule.OfficeTypeID = Convert.ToInt32(ds.Tables[0].Rows[0]["OfficeTypeID"]);
                                    VEDSchedule.CarpetArea = ds.Tables[0].Rows[0]["CarpetArea"].ToString();
                                    VEDSchedule.IsEditAllowed = Convert.ToBoolean(ds.Tables[0].Rows[0]["IsEditAllowed"]);
                                    VEDSchedule.Latitude = Convert.ToString(ds.Tables[0].Rows[0]["Latitude"]);
                                    VEDSchedule.Longitude = Convert.ToString(ds.Tables[0].Rows[0]["Longitude"]);
                                    VEDSchedule.OfficeAdmins = Convert.ToString(ds.Tables[0].Rows[0]["OfficeAdmins"]);
                                    VEDSchedule.Area = ds.Tables[0].Rows[0]["Area"].ToString();
                                    results.Data = VEDSchedule;
                                }
                            }
                            else
                            {
                                results.ErrorCode = "0";
                                results.ErrorMessage = "No data found for VED ID";
                                results.ExecutionContext = currentContext;
                            }
                        }
                    }
                    else
                    {
                        results.ErrorCode = "0";
                        results.ErrorMessage = "VEDID not found";
                        results.ExecutionContext = currentContext;
                    }
                    Common.ErrorLog(Type.Information, "GetScheduledVEDDetailsByID : End", request, JsonConvert.SerializeObject(results), loggedInUser, currentContext, reqType: type);

                }
                catch (Exception ex)
                {
                    results.ErrorCode = "0";
                    results.ErrorMessage = "Oops! Something went wrong, please try again.";
                    results.ExecutionContext = currentContext;
                    Common.ErrorLog(Type.Error, "GetScheduledVEDDetailsByID : End", request, "", loggedInUser, currentContext, ex, reqType: type);

                }
            }
            else
            {
                results.ErrorCode = "0";
                results.ErrorMessage = "Invalid Token.";
                results.ExecutionContext = currentContext;
            }
            return results;
        }
        public ServiceResult<List<VEDFinalData>> GetScheduleHistoryOfCenter(string centerID, string count, string executionContext, string loggedInUser, RequestType type = RequestType.Mobile)
        {
            string currentContext = string.Empty;
            if (string.IsNullOrEmpty(count))
            {
                count = "5";
            }
            List<VEDFinalData> VEDSchedules = new List<VEDFinalData>();
            ServiceResult<List<VEDFinalData>> results = new ServiceResult<List<VEDFinalData>>();
            string request = "centerID : " + centerID + "count : " + count;
            executionContext = ValidateExecutionContext(executionContext, loggedInUser, type);
            if (!string.IsNullOrEmpty(executionContext))
            {
                Common.ErrorLog(Type.Information, "GetScheduleHistoryOfCenter : Start", request, "", loggedInUser, currentContext, reqType: type);

                try
                {
                    if (!string.IsNullOrEmpty(centerID))
                    {
                        using (SqlConnection conn = new SqlConnection(connectionString))
                        {
                            conn.Open();
                            SqlCommand cmd = new SqlCommand();
                            cmd.Connection = conn;
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.CommandText = "usp_GetTheScheduleHistoryOfCenter";
                            cmd.Parameters.AddWithValue("@count", count);
                            cmd.Parameters.AddWithValue("@centerID ", centerID);
                            SqlDataAdapter da = new SqlDataAdapter(cmd);
                            DataSet ds = new DataSet();
                            da.Fill(ds);
                            // Common.ErrorLog(Type.Information, "GetAllCenters : Step 1", request, JsonConvert.SerializeObject(ds), loggedInUser ,currentContext, reqType: type);
                            if (ds.Tables.Count > 0)
                            {
                                if (ds.Tables[0].Rows.Count > 0)
                                {
                                    results.ErrorCode = "1";
                                    results.ErrorMessage = "Success";
                                    results.ExecutionContext = currentContext;


                                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                                    {
                                        VEDFinalData schedule = new VEDFinalData();
                                        schedule.ScheduledOn = Convert.ToString(ds.Tables[0].Rows[i]["ScheduledOn"]);
                                        schedule.ScheduledBy = Convert.ToString(ds.Tables[0].Rows[i]["ScheduledBy"]);
                                        schedule.ActualAssesstmentDate = ds.Tables[0].Rows[i]["ActualAssesstmentDate"] != null ? Convert.ToString(ds.Tables[0].Rows[i]["ActualAssesstmentDate"]) : "";
                                        schedule.Center = Convert.ToString(ds.Tables[0].Rows[i]["Center"]);
                                        schedule.Zone = Convert.ToString(ds.Tables[0].Rows[i]["Zone"]);
                                        schedule.Address = Convert.ToString(ds.Tables[0].Rows[i]["Address"]);
                                        schedule.City = Convert.ToString(ds.Tables[0].Rows[i]["City"]);
                                        schedule.OfficeCategory = Convert.ToString(ds.Tables[0].Rows[i]["OfficeCategory"]);
                                        schedule.OfficeType = Convert.ToString(ds.Tables[0].Rows[i]["OfficeType"]);
                                        schedule.CarpetArea = ds.Tables[0].Rows[i]["CarpetArea"].ToString();
                                        schedule.Vital = Convert.ToDouble(ds.Tables[0].Rows[i]["VitalCount"]);
                                        schedule.Essential = Convert.ToDouble(ds.Tables[0].Rows[i]["EssentialCount"]);
                                        schedule.Desirable = Convert.ToDouble(ds.Tables[0].Rows[i]["DesirableCount"]);
                                        schedule.VitalNotApplicable = Convert.ToDouble(ds.Tables[0].Rows[i]["VitalNotApplicable"]);
                                        schedule.EssentialNotApplicable = Convert.ToDouble(ds.Tables[0].Rows[i]["EssentialNotApplicable"]);
                                        schedule.DesirableNotApplicable = Convert.ToDouble(ds.Tables[0].Rows[i]["DesirableNotApplicable"]);
                                        schedule.TotalVEDByType = Convert.ToDouble(ds.Tables[0].Rows[i]["TotalVEDByType"]);
                                        schedule.VEDSCORE = Convert.ToDouble(ds.Tables[0].Rows[i]["VEDScore"]);
                                        schedule.MAXVEDSCORE = Convert.ToDouble(ds.Tables[0].Rows[i]["MAXVEDScore"]);
                                        schedule.VEDSCOREPER = (schedule.VEDSCORE / schedule.MAXVEDSCORE) * 100;
                                        VEDSchedules.Add(schedule);
                                    }
                                    results.Data = VEDSchedules;
                                }
                                else
                                {
                                    results.ErrorCode = "0";
                                    results.ErrorMessage = "No Schedules found.";
                                    results.ExecutionContext = currentContext;
                                }
                            }
                            else
                            {
                                results.ErrorCode = "0";
                                results.ErrorMessage = "No Schedules found.";
                                results.ExecutionContext = currentContext;
                            }
                        }
                    }
                    else
                    {
                        results.ErrorCode = "0";
                        results.ErrorMessage = "please provide the Center ID";
                        results.ExecutionContext = currentContext;
                    }
                    Common.ErrorLog(Type.Information, "GetScheduleHistoryOfCenter : End", request, JsonConvert.SerializeObject(results), loggedInUser, currentContext, reqType: type);

                }
                catch (Exception ex)
                {
                    results.ErrorCode = "0";
                    results.ErrorMessage = "Oops! Something went wrong, please try again.";
                    results.ExecutionContext = currentContext;
                    Common.ErrorLog(Type.Error, "GetScheduleHistoryOfCenter : End", request, "", loggedInUser, currentContext, ex, reqType: type);

                }
            }
            else
            {
                results.ErrorCode = "0";
                results.ErrorMessage = "Invalid Token.";
                results.ExecutionContext = string.Empty;
            }
            return results;
        }
        public ServiceResult<List<VEDSchedule>> GetManagerLevelScheduleData(string userID, string typeOfLevel, string executionContext, string loggedInUser,string officeType, RequestType type = RequestType.Portal)
        {
            string currentContext = string.Empty;
            string request = "userID : " + userID + " type : " + typeOfLevel;
            if (string.IsNullOrEmpty(executionContext))
            {
                currentContext = executionContextP;
            }
            else
            {
                currentContext = executionContext;
            }
            Common.ErrorLog(Type.Information, "GetManagerLevelScheduleData : Start", request, "", loggedInUser, currentContext, reqType: type);
            List<VEDSchedule> VEDSchedules = new List<VEDSchedule>();
            ServiceResult<List<VEDSchedule>> results = new ServiceResult<List<VEDSchedule>>();
            try
            {
                if (!string.IsNullOrEmpty(userID))
                {
                    using (SqlConnection conn = new SqlConnection(connectionString))
                    {
                        conn.Open();
                        SqlCommand cmd = new SqlCommand();
                        cmd.Connection = conn;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "usp_GetManagerLevelSchedules";
                        cmd.Parameters.AddWithValue("@userID", userID);
                        cmd.Parameters.AddWithValue("@type", typeOfLevel);
                        cmd.Parameters.AddWithValue("@OfficeType", officeType);
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataSet ds = new DataSet();
                        da.Fill(ds);
                        Common.ErrorLog(Type.Information, "GetManagerLevelScheduleData : Step 1", request, JsonConvert.SerializeObject(ds), loggedInUser, currentContext, reqType: type);
                        if (ds.Tables.Count > 0)
                        {
                            if (ds.Tables[0].Rows.Count > 0)
                            {
                                results.ErrorCode = "1";
                                results.ErrorMessage = "Success";
                                results.ExecutionContext = currentContext;


                                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                                {

                                    VEDSchedule VEDSchedule = new DTO.VEDSchedule();
                                    VEDSchedule.VEDID = Convert.ToString(ds.Tables[0].Rows[i]["ID"]);
                                    VEDSchedule.OfficeID = Convert.ToString(ds.Tables[0].Rows[i]["OfficeID"]);
                                    VEDSchedule.ScheduledOn = Convert.ToString(ds.Tables[0].Rows[i]["ScheduledOn"]);
                                    VEDSchedule.ScheduledBy = Convert.ToString(ds.Tables[0].Rows[i]["ScheduledBy"]);
                                    VEDSchedule.ActualAssesstmentDate = ds.Tables[0].Rows[i]["ActualAssesstmentDate"] != null ? Convert.ToString(ds.Tables[0].Rows[i]["ActualAssesstmentDate"]) : "";
                                    VEDSchedule.Center = Convert.ToString(ds.Tables[0].Rows[i]["Center"]);
                                    VEDSchedule.Zone = Convert.ToString(ds.Tables[0].Rows[i]["Zone"]);
                                    VEDSchedule.Address = Convert.ToString(ds.Tables[0].Rows[i]["Address"]);
                                    VEDSchedule.City = Convert.ToString(ds.Tables[0].Rows[i]["City"]);
                                    VEDSchedule.OfficeCategory = Convert.ToString(ds.Tables[0].Rows[i]["OfficeCategory"]);
                                    VEDSchedule.OfficeType = Convert.ToString(ds.Tables[0].Rows[i]["OfficeType"]);
                                    VEDSchedule.OfficeAdmins = Convert.ToString(ds.Tables[0].Rows[0]["OfficeAdmins"]);
                                    VEDSchedule.IsEditAllowed = true;
                                    VEDSchedule.CarpetArea = ds.Tables[0].Rows[i]["CarpetArea"].ToString();
                                    VEDSchedules.Add(VEDSchedule);
                                }
                                results.Data = VEDSchedules;
                            }
                        }
                        else
                        {
                            results.ErrorCode = "0";
                            results.ErrorMessage = "No Schedules found.";
                            results.ExecutionContext = currentContext;
                        }
                    }
                }
                else
                {
                    results.ErrorCode = "0";
                    results.ErrorMessage = "please provide the UserName";
                    results.ExecutionContext = currentContext;
                }
                Common.ErrorLog(Type.Information, "GetManagerLevelScheduleData : End", request, JsonConvert.SerializeObject(results), loggedInUser, currentContext, reqType: type);

            }
            catch (Exception ex)
            {
                results.ErrorCode = "0";
                results.ErrorMessage = "Oops! Something went wrong, please try again.";
                results.ExecutionContext = currentContext;
                Common.ErrorLog(Type.Error, "GetManagerLevelScheduleData : End", request, "", loggedInUser, currentContext, ex, reqType: type);

            }
            return results;
        }
        #endregion

        #region Assessment Details
        public ServiceResult<Facility> GetFaciltyAreaDetailsMasters(string centerTypeID, string VEDScheduleID, string executionContext, string loggedInUser, RequestType type = RequestType.Mobile)
        {
            string currentContext = string.Empty;
            string request = "centerType : " + centerTypeID + " VEDScheduleID : " + VEDScheduleID;
            List<FacilityMaster> facilityMaster = new List<FacilityMaster>();
            List<ScoringMaster> scoringMasters = new List<ScoringMaster>();
            List<VEDFinalData> schedules = new List<VEDFinalData>();
            Facility facilty = new Facility();
            ServiceResult<Facility> results = new ServiceResult<Facility>();
            executionContext = ValidateExecutionContext(executionContext, loggedInUser, type);
            if (!string.IsNullOrEmpty(executionContext))
            {
                Common.ErrorLog(Type.Information, "GetFaciltyAreaDetailsMasters : Start", request, "", loggedInUser, currentContext, reqType: type);

                try
                {
                    if (!string.IsNullOrEmpty(centerTypeID))
                    {
                        using (SqlConnection conn = new SqlConnection(connectionString))
                        {
                            conn.Open();
                            SqlCommand cmd = new SqlCommand();
                            cmd.Connection = conn;
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.CommandText = "usp_GetFacilityDetailsAndAreaMaster";
                            cmd.Parameters.AddWithValue("@OfficeTypeID", centerTypeID);
                            cmd.Parameters.AddWithValue("@VEDScheduleID", VEDScheduleID);
                            SqlDataAdapter da = new SqlDataAdapter(cmd);
                            DataSet ds = new DataSet();
                            da.Fill(ds);
                            if (ds.Tables.Count > 0)
                            {
                                results.ErrorCode = "1";
                                results.ErrorMessage = "Success";
                                results.ExecutionContext = currentContext;
                                if (ds.Tables[0].Rows.Count > 0)
                                {
                                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                                    {
                                        FacilityMaster fm = new FacilityMaster();
                                        fm.ID = Convert.ToInt32(ds.Tables[0].Rows[i]["FACILITYDETAILSID"]);
                                        fm.FacilityArea = ds.Tables[0].Rows[i]["FacilityArea"].ToString();
                                        fm.FacilityDetails = ds.Tables[0].Rows[i]["FacilityDetails"].ToString();
                                        fm.Criticality = ds.Tables[0].Rows[i]["Criticality"].ToString();
                                        fm.Officetype = ds.Tables[0].Rows[i]["Officetype"].ToString();
                                        fm.FacilityAreaID = Convert.ToInt32(ds.Tables[0].Rows[i]["FacilityAreaID"]);
                                        fm.FacilityDetailsID = Convert.ToInt32(ds.Tables[0].Rows[i]["FacilityDetailsID"]);
                                        fm.CriticalityID = Convert.ToInt32(ds.Tables[0].Rows[i]["CriticalityID"]);
                                        fm.OfficetypeID = Convert.ToInt32(ds.Tables[0].Rows[i]["OfficetypeID"]);
                                        fm.Comments = (ds.Tables[0].Rows[i]["Comments"]).ToString();
                                        facilityMaster.Add(fm);
                                    }
                                }
                                if (ds.Tables[1].Rows.Count > 0)
                                {
                                    for (int i = 0; i < ds.Tables[1].Rows.Count; i++)
                                    {
                                        ScoringMaster sm = new ScoringMaster();
                                        sm.OfficeType = ds.Tables[1].Rows[i]["Officetype"].ToString();
                                        sm.Criticality = ds.Tables[1].Rows[i]["Criticality"].ToString();
                                        sm.FacilityCheckPoints = Convert.ToInt32(ds.Tables[1].Rows[i]["FacilityCheckPoints"]);
                                        sm.Good = Convert.ToInt32(ds.Tables[1].Rows[i]["Good"]);
                                        sm.Poor = Convert.ToInt32(ds.Tables[1].Rows[i]["Poor"]);
                                        sm.NotWorking = Convert.ToInt32(ds.Tables[1].Rows[i]["NotWorking"]);
                                        sm.NotAvailable = Convert.ToInt32(ds.Tables[1].Rows[i]["NotAvailable"]);
                                        scoringMasters.Add(sm);
                                    }
                                }

                                if (ds.Tables[2].Rows.Count > 0)
                                {
                                    for (int i = 0; i < ds.Tables[2].Rows.Count; i++)
                                    {
                                        VEDFinalData schedule = new VEDFinalData();
                                        schedule.ScheduledOn = Convert.ToString(ds.Tables[2].Rows[i]["ScheduledOn"]);
                                        schedule.ScheduledBy = Convert.ToString(ds.Tables[2].Rows[i]["ScheduledBy"]);
                                        schedule.ActualAssesstmentDate = ds.Tables[2].Rows[i]["ActualAssesstmentDate"] != null ? Convert.ToString(ds.Tables[2].Rows[i]["ActualAssesstmentDate"]) : "";
                                        schedule.Center = Convert.ToString(ds.Tables[2].Rows[i]["Center"]);
                                        schedule.Zone = Convert.ToString(ds.Tables[2].Rows[i]["Zone"]);
                                        schedule.Address = Convert.ToString(ds.Tables[2].Rows[i]["Address"]);
                                        schedule.City = Convert.ToString(ds.Tables[2].Rows[i]["City"]);
                                        schedule.OfficeCategory = Convert.ToString(ds.Tables[2].Rows[i]["OfficeCategory"]);
                                        schedule.OfficeType = Convert.ToString(ds.Tables[2].Rows[i]["OfficeType"]);
                                        schedule.CarpetArea = ds.Tables[2].Rows[i]["CarpetArea"].ToString();
                                        schedule.Vital = ds.Tables[2].Rows[i]["VitalCount"] == null ? 0.0 : Convert.ToDouble(ds.Tables[2].Rows[i]["VitalCount"]);
                                        schedule.Essential = ds.Tables[2].Rows[i]["EssentialCount"] == null ? 0.0 : Convert.ToDouble(ds.Tables[2].Rows[i]["EssentialCount"]);
                                        schedule.Desirable = ds.Tables[2].Rows[i]["DesirableCount"] == null ? 0.0 : Convert.ToDouble(ds.Tables[2].Rows[i]["DesirableCount"]);
                                        schedule.VitalNotApplicable = ds.Tables[2].Rows[i]["VitalNotApplicable"] == null ? 0.0 : Convert.ToDouble(ds.Tables[2].Rows[i]["VitalNotApplicable"]);
                                        schedule.EssentialNotApplicable = ds.Tables[2].Rows[i]["EssentialNotApplicable"] == null ? 0.0 : Convert.ToDouble(ds.Tables[2].Rows[i]["EssentialNotApplicable"]);
                                        schedule.DesirableNotApplicable = ds.Tables[2].Rows[i]["DesirableNotApplicable"] == null ? 0.0 : Convert.ToDouble(ds.Tables[2].Rows[i]["DesirableNotApplicable"]);
                                        schedule.TotalVEDByType = ds.Tables[2].Rows[i]["TotalVEDByType"] == null ? 0.0 : Convert.ToDouble(ds.Tables[2].Rows[i]["TotalVEDByType"]);
                                        schedule.VEDSCORE = ds.Tables[2].Rows[i]["VEDScore"] == null ? 0.0 : Convert.ToDouble(ds.Tables[2].Rows[i]["VEDScore"]);
                                        schedule.MAXVEDSCORE = ds.Tables[2].Rows[i]["MAXVEDScore"] == null ? 0.0 : Convert.ToDouble(ds.Tables[2].Rows[i]["MAXVEDScore"]);
                                        schedule.VEDSCOREPER = (schedule.VEDSCORE / schedule.MAXVEDSCORE) * 100;
                                        schedules.Add(schedule);
                                    }
                                }


                                facilty.FacilityMaster = facilityMaster;
                                facilty.ScoringMaster = scoringMasters;
                                facilty.VEDSchedules = schedules;
                                results.Data = facilty;
                            }
                            else
                            {
                                results.ErrorCode = "0";
                                results.ErrorMessage = "No data found for the Center Type";
                                results.ExecutionContext = currentContext;
                            }
                        }
                    }
                    else
                    {
                        results.ErrorCode = "0";
                        results.ErrorMessage = "Center Type not found";
                        results.ExecutionContext = currentContext;
                    }
                    Common.ErrorLog(Type.Information, "GetFaciltyAreaDetailsMasters : End", request, JsonConvert.SerializeObject(results), loggedInUser, currentContext, reqType: type);

                }
                catch (Exception ex)
                {
                    results.ErrorCode = "0";
                    results.ErrorMessage = "Oops! Something went wrong, please try again.";
                    results.ExecutionContext = currentContext;
                    Common.ErrorLog(Type.Error, "GetFaciltyAreaDetailsMasters : End", request, "", loggedInUser, currentContext, ex, reqType: type);

                }
            }
            else
            {
                results.ErrorCode = "0";
                results.ErrorMessage = "Invalid Token.";
                results.ExecutionContext = string.Empty;
            }
            return results;
        }
        public ServiceResult<VEDScore> SaveAsessmentDetails_Web(List<AssesstmentDetails> assesmentData, string executionContext, string loggedInUser, RequestType type = RequestType.Mobile, AssessmentType assesssmentType = AssessmentType.AreaLevel)
        {
            string currentContext = string.Empty;
            int vedid = 0;
            int AssessmentDoneFrom = Convert.ToInt32(type);
            string request = "assesmentData : " + JsonConvert.SerializeObject(assesmentData);
            if (string.IsNullOrEmpty(executionContext))
            {
                currentContext = executionContextP;
            }
            else
            {
                currentContext = executionContext;
            }
            Common.ErrorLog(Type.Information, "SaveAsessmentDetails : Start", request, "", loggedInUser, currentContext, reqType: type);
            ServiceResult<VEDScore> results = new ServiceResult<VEDScore>();
            //Calculation  wala Part to be taken here;
            VEDScore score = GetVEDScore(assesmentData, executionContext, loggedInUser, RequestType.Portal);
            try
            {
                if (assesmentData.Count() > 0)
                {
                    DataTable dt = new DataTable();
                    dt.Columns.AddRange(new DataColumn[8]
                        {
                            new DataColumn("VEDScheduleID"),          //[VEDScheduleID] [int] NOT NULL,
                            new DataColumn("FacilityAreaID"),         //[FacilityAreaID] [int] NOT NULL,
                            new DataColumn("FacilityDetailsID"),      //[FacilityDetailsID] [int] NOT NULL,
                            new DataColumn("CriticalityID"),          //[CriticalityID] [int] NOT NULL,
                            new DataColumn("Condition"),              //[Condition] [varchar](20) NOT NULL,
                            new DataColumn("AssessmentDoneBy"),       //[AssessmentDoneBy] [varchar](200) NOT NULL,
                            new DataColumn("AssessmentType"),         //[AssessmentDate] [datetime] NOT NULL,
                            new DataColumn("Comments"),               //[Comments] [varchar](max) NOT NULL,
                        }
                        );
                    foreach (AssesstmentDetails item in assesmentData)
                    {
                        dt.Rows.Add(item.VEDScheduleID, item.FacilityAreaID, item.FacilityDetailsID, item.CriticalityID, item.Condition, item.AssessmentDoneBy, (Int32)assesssmentType, item.Comments);
                        vedid = item.VEDScheduleID;
                    }
                    using (SqlConnection conn = new SqlConnection(connectionString))
                    {
                        conn.Open();
                        SqlCommand cmd = new SqlCommand();
                        cmd.Connection = conn;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "usp_SaveAssesstmentDetails";
                        cmd.Parameters.AddWithValue("@Data", dt);
                        cmd.Parameters.AddWithValue("@VEDScheduleID", assesmentData.FirstOrDefault().VEDScheduleID.ToString());
                        int rowAffected = cmd.ExecuteNonQuery();
                        if (rowAffected > 0)
                        {
                            results.ErrorCode = "1";
                            results.ErrorMessage = "Success";
                            results.ExecutionContext = currentContext;
                            ServiceResult result = AddVEDScore(score, assesmentData.FirstOrDefault().VEDScheduleID, loggedInUser);
                            results.Data = score;
                            UpdateAssesmentStatus(vedid, AssessmentDoneFrom, currentContext, loggedInUser, type);
                        }
                        else
                        {
                            results.ErrorCode = "0";
                            results.ErrorMessage = "Some error occurred while processing the request, requestingyou to please again later.";
                            results.ExecutionContext = currentContext;

                        }
                    }
                }
                else
                {
                    results.ErrorCode = "0";
                    results.ErrorMessage = "No data available";
                    results.ExecutionContext = currentContext;
                }
                Common.ErrorLog(Type.Information, "SaveAsessmentDetails : End", request, JsonConvert.SerializeObject(results), loggedInUser, currentContext, reqType: type);

            }
            catch (Exception ex)
            {
                results.ErrorCode = "0";
                results.ErrorMessage = "Oops! Something went wrong, please try again.";
                results.ExecutionContext = currentContext;
                Common.ErrorLog(Type.Error, "SaveAsessmentDetails : End", request, "", loggedInUser, currentContext, ex, reqType: type);

            }
            return results;
        }

        public void UpdateAssesmentStatus(int vedid, int AssessmentDoneFrom, string executionContext, string loggedInUser, RequestType type = RequestType.Mobile)
        {

            string request = "vedid : " + vedid + "AssessmentDoneFrom : " + AssessmentDoneFrom;
            int rowAffected = 0;
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "usp_UpdateAssesmentStatusDoneFromDetails";
                    cmd.Parameters.AddWithValue("@VEDScheduleID", vedid);
                    cmd.Parameters.AddWithValue("@AssessmentDoneFrom", AssessmentDoneFrom);
                    //cmd.Parameters.AddWithValue("@VEDScheduleID", assesmentData.FirstOrDefault().VEDScheduleID.ToString());
                    rowAffected = cmd.ExecuteNonQuery();
                }

            }
            catch (Exception ex)
            {
                Common.ErrorLog(Type.Error, "UpdateAssesmentStatus", request, Convert.ToString(rowAffected), loggedInUser, executionContext, exception: ex, reqType: type);
            }
        }
        public ServiceResult<VEDScore> SaveAsessmentDetails(List<AssesstmentDetails> assesmentData, string executionContext, string loggedInUser, RequestType type = RequestType.Mobile, AssessmentType assesssmentType = AssessmentType.AreaLevel)
        {
            string currentContext = string.Empty;
            int vedid = 0;
            int AssessmentDoneFrom = Convert.ToInt32(type);
            string request = "assesmentData : " + JsonConvert.SerializeObject(assesmentData);
            if (string.IsNullOrEmpty(executionContext))
            {
                currentContext = executionContextP;
            }
            else
            {
                currentContext = executionContext;
            }
            Common.ErrorLog(Type.Information, "SaveAsessmentDetails : Start", request, "", loggedInUser, currentContext, reqType: type);
            ServiceResult<VEDScore> results = new ServiceResult<VEDScore>();
            //Calculation  wala Part to be taken here;
            VEDScore score = GetVEDScore(assesmentData, executionContext, loggedInUser, type);
            try
            {
                if (assesmentData.Count() > 0)
                {
                    DataTable dt = new DataTable();
                    dt.Columns.AddRange(new DataColumn[8]
                        {
                            new DataColumn("VEDScheduleID"),          //[VEDScheduleID] [int] NOT NULL,
                            new DataColumn("FacilityAreaID"),         //[FacilityAreaID] [int] NOT NULL,
                            new DataColumn("FacilityDetailsID"),      //[FacilityDetailsID] [int] NOT NULL,
                            new DataColumn("CriticalityID"),          //[CriticalityID] [int] NOT NULL,
                            new DataColumn("Condition"),              //[Condition] [varchar](20) NOT NULL,
                            new DataColumn("AssessmentDoneBy"),       //[AssessmentDoneBy] [varchar](200) NOT NULL,
                            new DataColumn("AssessmentType"),         //[AssessmentDate] [datetime] NOT NULL,
                            new DataColumn("Comments"),               //[Comments] [varchar](max) NOT NULL,
                        }
                        );
                    foreach (AssesstmentDetails item in assesmentData)
                    {
                        dt.Rows.Add(item.VEDScheduleID, item.FacilityAreaID, item.FacilityDetailsID, item.CriticalityID, item.Condition, item.AssessmentDoneBy, (Int32)assesssmentType, item.Comments);
                        vedid = item.VEDScheduleID;
                    }
                    using (SqlConnection conn = new SqlConnection(connectionString))
                    {
                        conn.Open();
                        SqlCommand cmd = new SqlCommand();
                        cmd.Connection = conn;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "usp_SaveAssesstmentDetails";
                        cmd.Parameters.AddWithValue("@Data", dt);
                        cmd.Parameters.AddWithValue("@VEDScheduleID", assesmentData.FirstOrDefault().VEDScheduleID.ToString());
                        int rowAffected = cmd.ExecuteNonQuery();
                        if (rowAffected > 0)
                        {
                            results.ErrorCode = "1";
                            results.ErrorMessage = "Success";
                            results.ExecutionContext = currentContext;
                            ServiceResult result = AddVEDScore(score, assesmentData.FirstOrDefault().VEDScheduleID, loggedInUser);
                            results.Data = score;
                            UpdateAssesmentStatus(vedid, AssessmentDoneFrom, currentContext, loggedInUser, type);
                            //Object Creation for Mail


                            DataSet ds = Common.GettingMailDetails(assesmentData.FirstOrDefault().VEDScheduleID.ToString(), loggedInUser, executionContext, RequestType.Portal);
                            List<MailData> mailDetails = new List<MailData>();


                            string facilityAreaID = string.Empty, facilityDetail = string.Empty;
                            foreach (AssesstmentDetails item in assesmentData)
                            {
                                if ((item.Criticality.ToUpper() == "VITAL" || item.Criticality.ToUpper() == "ESSENTIAL") && item.Condition.ToUpper() == "POOR")
                                {
                                    facilityAreaID += item.FacilityAreaID + ",";
                                    facilityDetail += item.FacilityDetailsID + ",";
                                }
                            }

                            DataSet dsFaciltyDetails = Common.GettingAreaDetails(facilityAreaID, facilityDetail, loggedInUser, executionContext, RequestType.Mobile);
                            //return two DataTable

                            foreach (AssesstmentDetails item in assesmentData)
                            {
                                if ((item.Criticality.ToUpper() == "VITAL" || item.Criticality.ToUpper() == "ESSENTIAL") && item.Condition.ToUpper() == "POOR")
                                {
                                    MailData mailDetail = new MailData();
                                    mailDetail.Zone = ds.Tables[0].Rows[0]["Zone"].ToString();
                                    mailDetail.State = ds.Tables[0].Rows[0]["State"].ToString();
                                    mailDetail.City = ds.Tables[0].Rows[0]["city"].ToString();
                                    mailDetail.Center = ds.Tables[0].Rows[0]["CEnter"].ToString();
                                    mailDetail.ScheduleBy = ds.Tables[0].Rows[0]["Created By"].ToString();
                                    mailDetail.FacilityArea = (dsFaciltyDetails.Tables[0].Select("ID=" + item.FacilityAreaID + ""))[0]["Title"].ToString();
                                    mailDetail.FacilityDetails = (dsFaciltyDetails.Tables[1].Select("ID=" + item.FacilityDetailsID + ""))[0]["Title"].ToString();
                                    mailDetail.ID = item.FacilityDetailsID.ToString();
                                    mailDetail.AssessmentCondition = "Poor";
                                    mailDetail.StateHeadID = ds.Tables[0].Rows[0]["StateHeadID"].ToString();
                                    mailDetail.Comments = item.Comments;
                                    mailDetail.VEDScheduleID = item.VEDScheduleID;
                                    mailDetails.Add(mailDetail);
                                }
                            }
                            Common.SendPoorMail(mailDetails, loggedInUser, executionContext, RequestType.Mobile);
                        }
                        else
                        {
                            results.ErrorCode = "0";
                            results.ErrorMessage = "Some error occurred while processing the request, requestingyou to please again later.";
                            results.ExecutionContext = currentContext;

                        }
                    }
                }
                else
                {
                    results.ErrorCode = "0";
                    results.ErrorMessage = "No data available";
                    results.ExecutionContext = currentContext;
                }
                Common.ErrorLog(Type.Information, "SaveAsessmentDetails : End", request, JsonConvert.SerializeObject(results), loggedInUser, currentContext, reqType: type);

            }
            catch (Exception ex)
            {
                results.ErrorCode = "0";
                results.ErrorMessage = "Oops! Something went wrong, please try again.";
                results.ExecutionContext = currentContext;
                Common.ErrorLog(Type.Error, "SaveAsessmentDetails : End", request, "", loggedInUser, currentContext, ex, reqType: type);

            }
            return results;
        }
        private ServiceResult AddVEDScore(VEDScore score, int VEDScheduleID, string loggedInUser)
        {
            ServiceResult result = new ServiceResult();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "usp_UpdateVEDScoreBasedOnVEDID";
                cmd.Parameters.AddWithValue("@VitalCount ", score.Vital);
                cmd.Parameters.AddWithValue("@EssentialCount ", score.Essential);
                cmd.Parameters.AddWithValue("@DesirableCount ", score.Desirable);
                cmd.Parameters.AddWithValue("@TotalVEDByType ", score.TotalVEDByType);
                cmd.Parameters.AddWithValue("@VitalNotApplicable ", score.VitalNotApplicable);
                cmd.Parameters.AddWithValue("@EssentialNotApplicable", score.EssentialNotApplicable);
                cmd.Parameters.AddWithValue("@DesirableNotApplicable", score.DesirableNotApplicable);
                cmd.Parameters.AddWithValue("@VEDScore ", score.VEDSCORE);
                cmd.Parameters.AddWithValue("@MAXVEDScore ", score.MAXVEDSCORE);
                cmd.Parameters.AddWithValue("@VEDScheduleID ", VEDScheduleID);
                cmd.Parameters.AddWithValue("@ModifiedBy ", loggedInUser);

                int rowsAffected = cmd.ExecuteNonQuery();
                if (rowsAffected > 0)
                {
                    result.ErrorCode = "0";
                    result.ErrorMessage = "Success";
                }
                else
                {
                    result.ErrorCode = "1";
                    result.ErrorMessage = "Success";
                }
            }
            return result;
        }
        private Points GetPoints(int officeTypeID)
        {
            Points point = null;


            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "usp_GetPointsForTimelyCompletionOFVEDMaster";
                cmd.Parameters.AddWithValue("@OfficeTypeID", officeTypeID);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables.Count > 0)
                {
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        point = new Points();
                        // ScoringMaster master = new ScoringMaster();
                        point.OnTime = Convert.ToInt32(ds.Tables[0].Rows[0]["OnTime"]);
                        point.WithAcceptableDelay = Convert.ToInt32(ds.Tables[0].Rows[0]["WithAcceptableDelay"]);
                        point.WithNotAcceptableDelay = Convert.ToInt32(ds.Tables[0].Rows[0]["WithNotAcceptableDelay"]);
                        point.NotScheduled = Convert.ToInt32(ds.Tables[0].Rows[0]["NotScheduled"]);
                        point.NotDone = Convert.ToInt32(ds.Tables[0].Rows[0]["NotDone"]);
                        //  masters.Add(master);
                    }
                }
                else
                {

                }
            }
            return point;
        }
        private VEDScore GetVEDScore(List<AssesstmentDetails> assesmentData, string executionContext, string loggedInUser, RequestType type = RequestType.Mobile)
        {

            ServiceResult<VEDSchedule> schedule = GetScheduledVEDDetailsByID(assesmentData.ToList().FirstOrDefault().VEDScheduleID.ToString(), executionContext, loggedInUser, type);
            VEDScore score = new VEDScore();
            //Step 1 : Get the VED Percentage
            score.Vital = assesmentData.Where(t => t.Criticality == "Vital").Count();
            score.Essential = assesmentData.Where(t => t.Criticality == "Essential").Count();
            score.Desirable = assesmentData.Where(t => t.Criticality == "Desirable").Count();
            score.TotalVEDByType = score.Vital + score.Essential + score.Desirable;
            score.VEDScheduleId = Convert.ToInt32(schedule.Data.VEDID);
            //Step 2 : Overall Total of Condition
            List<ScoringMaster> masters = GetScoringMaster(Convert.ToInt32(schedule.Data.OfficeTypeID));
            int totalPoints = 0;
            foreach (AssesstmentDetails item in assesmentData)
            {

                string criticalityType = item.Criticality;
                string condition = item.Condition;
                if (condition == "Good")
                {
                    totalPoints += masters.Where(t => t.Criticality == criticalityType).Select(y => y.Good).FirstOrDefault();
                }
                else if (condition == "Poor")
                {
                    totalPoints += masters.Where(t => t.Criticality == criticalityType).Select(y => y.Poor).FirstOrDefault();
                }
                else if (condition == "Not Working")
                {
                    totalPoints += masters.Where(t => t.Criticality == criticalityType).Select(y => y.NotWorking).FirstOrDefault();
                }
                else if (condition == "Not Available")
                {
                    totalPoints += masters.Where(t => t.Criticality == criticalityType).Select(y => y.NotAvailable).FirstOrDefault();
                }
                else if (condition == "Not Applicable")
                {
                    totalPoints += 0;
                }
            }
            score.VEDSCORE = totalPoints;
            //Step 3 : Get the Schedule date dofference
            //NotScheduled -- Not Scheduled
            ////////Points point = GetPoints(Convert.ToInt32(schedule.Data.OfficeTypeID));
            ////////DateTime scheduleDate = Convert.ToDateTime(schedule.Data.ScheduledOn);
            ////////int dateDifference = Convert.ToInt32(DateTime.Now.Subtract(scheduleDate).Days);

            ////////if (dateDifference <= 3) //OnTime,  --On time (+/- 3 days from scheduled date)
            ////////{
            ////////    totalPoints += point.OnTime;
            ////////}
            ////////else if (dateDifference > 3 && dateDifference <= 15)//WithAcceptableDelay, --With Acceptable Delay (within 15 Days from scheduled date)
            ////////{
            ////////    totalPoints += point.WithAcceptableDelay;
            ////////}
            ////////else if (dateDifference > 15 && dateDifference <= 30)//WithNotAcceptableDelay, -- With Not Acceptable Delay (Within 15-30 Days from Scheduled date)
            ////////{
            ////////    totalPoints += point.WithNotAcceptableDelay;
            ////////}
            ////////else//NotDone, -- Not Done as  per Scheduled date
            ////////{
            ////////    totalPoints += point.NotDone;
            ////////}
            if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["startDate"].ToString()))
            {
                DateTime startDate = Convert.ToDateTime(ConfigurationManager.AppSettings["startDate"]);
                if (startDate.AddMonths(1) <= DateTime.Now)
                {
                    totalPoints += GetTimelyScore(Convert.ToInt32(schedule.Data.OfficeID), schedule.Data.ScheduledOn, schedule.Data.OfficeTypeID);
                }

            }
            //Step 4 : Get the Best score for the VED according to Center Type
            int vitalGood = masters.Where(t => t.Criticality == "Vital").Select(y => y.Good).FirstOrDefault();
            int essentialGood = masters.Where(t => t.Criticality == "Essential").Select(y => y.Good).FirstOrDefault();
            int desirableGood = masters.Where(t => t.Criticality == "Desirable").Select(y => y.Good).FirstOrDefault();
            int vitalNA = assesmentData.Where(t => (t.Condition == "Not Applicable" && t.Criticality == "Vital")).Count();
            int essentialNA = assesmentData.Where(t => (t.Condition == "Not Applicable" && t.Criticality == "Essential")).Count();
            int desirableNA = assesmentData.Where(t => (t.Condition == "Not Applicable" && t.Criticality == "Desirable")).Count();
            score.VitalNotApplicable = vitalNA;
            score.EssentialNotApplicable = essentialNA;
            score.DesirableNotApplicable = desirableNA;
            //Step 5 : Final Calculation =((E59 - E51)*9+(E60 - E52)*3+(E61 - E53)*1+3)
            if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["startDate"].ToString()))
            {
                score.MAXVEDSCORE = Math.Round(((score.Vital - vitalNA) * vitalGood + (score.Essential - essentialNA) * 3 + (score.Desirable - desirableNA) * desirableGood + 3), 2, MidpointRounding.ToEven);
            }
            else
            {
                score.MAXVEDSCORE = Math.Round(((score.Vital - vitalNA) * vitalGood + (score.Essential - essentialNA) * 3 + (score.Desirable - desirableNA) * desirableGood), 2, MidpointRounding.ToEven);
            }
            score.VEDSCORE = Math.Round(Convert.ToDouble(totalPoints), 2, MidpointRounding.ToEven);
            score.VEDSCOREPER = Math.Round((totalPoints / score.MAXVEDSCORE) * 100, 2, MidpointRounding.ToEven);
            return score;
        }

        private int GetTimelyScore(int officeID, string ScheduleOn, int OfficeTypeID)
        {
            int points = 0;
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.Text;
                cmd.CommandText = "select dbo.ufnToGetPointBasedOnScheduleOnDate(@OfficeID,@ScheduleOn,@type)";
                //int ,
                //datetime = NULL
                cmd.Parameters.AddWithValue("@OfficeID", officeID);
                cmd.Parameters.AddWithValue("@ScheduleOn", ScheduleOn);
                cmd.Parameters.AddWithValue("@type", OfficeTypeID);
                var result = cmd.ExecuteScalar(); // should properly get your value
                points = (int)result;
            }
            return points;

            //throw new NotImplementedException();
        }
        //string finalURL = "http://sp13devwfe01:19999/sites/RCS/JCVED";
        //string listNm = "Assessment Documents";
        //private string UploadDocument(string imageContent, int ID, string currentContext)
        //{

        //    string finalFileURL = string.Empty;
        //    Common.ErrorLog(Type.Error, "UploadDocument : Start", "finalFileURL", finalFileURL, "", currentContext, reqType: type);
        //    try
        //    {


        //        SPSecurity.RunWithElevatedPrivileges(delegate()
        //        {
        //            using (SPSite site = new SPSite(finalURL))
        //            {
        //                using (SPWeb web = site.OpenWeb())
        //                {
        //                    string listName = listNm;
        //                    SPList list = web.Lists.TryGetList(listName);
        //                    if (list != null)
        //                    {
        //                        finalURL = AddDocumentInLibrary(web, imageContent, ID, currentContext, reqType: type);
        //                    }
        //                }
        //            }
        //        });

        //    }
        //    catch (Exception ex)
        //    {

        //        Common.ErrorLog(Type.Error, "UploadDocument : End", "", "", "", currentContext ,ex, reqType: type);
        //    }
        //    Common.ErrorLog(Type.Information, "UploadDocument : End", "finalURL", finalURL, "", currentContext, reqType: type);
        //    return finalURL;
        //}
        //private string AddDocumentInLibrary(SPWeb web, string imageContent, int ID, string currentContext)
        //{
        //    string fileURL = string.Empty;
        //    Common.ErrorLog(Type.Error, "AddDocumentInLibrary : Start", "finalURL", finalURL, "", currentContext, reqType: type);
        //    try
        //    {
        //        byte[] toBytes = Encoding.ASCII.GetBytes(imageContent);
        //        SPFolder folder = web.Folders[listNm];
        //        SPFile file = folder.Files.Add(folder.Url + "_" + DateTime.Now.Day + "_" + DateTime.Now.Month + "_" + DateTime.Now.Year + "_" + DateTime.Now.Minute + "_" + DateTime.Now.Second + "_" + ID, toBytes, true);
        //        file.Item.Update();
        //        fileURL = file.ServerRelativeUrl;
        //    }
        //    catch (Exception ex)
        //    {
        //        Common.ErrorLog(Type.Error, "AddDocumentInLibrary : End", "finalURL", finalURL, "", currentContext ,ex, reqType: type);
        //    }
        //    Common.ErrorLog(Type.Information, "AddDocumentInLibrary : End", "finalURL", finalURL, "", currentContext, reqType: type);
        //    return fileURL;

        //}
        public ServiceResult UploadAssessmentImages_Web(List<Image> imagesData, string executionContext, string loggedInUser, RequestType type = RequestType.Mobile)
        {
            string currentContext = string.Empty;
            string request = "imagesData : " + JsonConvert.SerializeObject(imagesData);
            if (string.IsNullOrEmpty(executionContext))
            {
                currentContext = executionContextP;
            }
            else
            {
                currentContext = executionContext;
            }
            Common.ErrorLog(Type.Information, "UploadAssessmentImages : Start", request, "", loggedInUser, currentContext, reqType: type);
            ServiceResult results = new ServiceResult();
            try
            {
                if (imagesData.Count() > 0)
                {
                    DataTable dt = new DataTable();
                    dt.Columns.AddRange(new DataColumn[5]
                        {
                            new DataColumn("VEDScheduleID"),     
                            new DataColumn("FacilityDetailID"),  
                            new DataColumn("Image", typeof(Byte[])),                              
                            new DataColumn("ImageName") ,
                            new DataColumn("CreatedBy")
                        }
                        );

                    foreach (Image item in imagesData)
                    {

                        byte[] toBytes = Convert.FromBase64String(item.ImageContent);
                        //string base64String = Convert.FromBase64String(toBytes);
                        dt.Rows.Add(item.VEDScheduleID, item.FacilityDetailsID, toBytes, item.ImageName, item.AssessmentDoneBy);
                    }
                    using (SqlConnection conn = new SqlConnection(connectionString))
                    {
                        conn.Open();
                        SqlCommand cmd = new SqlCommand();
                        cmd.Connection = conn;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "usp_InsertUpdateAssessmentImages";
                        cmd.Parameters.AddWithValue("@Data", dt);
                        int rowAffected = cmd.ExecuteNonQuery();
                        if (rowAffected > 0)
                        {
                            results.ErrorCode = "1";
                            results.ErrorMessage = "Success";
                            results.ExecutionContext = currentContext;
                        }
                        else
                        {
                            results.ErrorCode = "0";
                            results.ErrorMessage = "Some error occurred while processing the request, requesting you to please again later.";
                            results.ExecutionContext = currentContext;

                        }
                    }
                }
                else
                {
                    results.ErrorCode = "0";
                    results.ErrorMessage = "No data available";
                    results.ExecutionContext = currentContext;
                }
                Common.ErrorLog(Type.Information, "UploadAssessmentImages : End", request, JsonConvert.SerializeObject(results), loggedInUser, currentContext, reqType: type);

            }





            catch (Exception ex)
            {
                results.ErrorCode = "0";
                results.ErrorMessage = "Oops! Something went wrong, please try again.";
                results.ExecutionContext = currentContext;
                Common.ErrorLog(Type.Error, "UploadAssessmentImages : End", request, "", loggedInUser, currentContext, ex, reqType: type);

            }
            return results;
        }
        public ServiceResult UploadAssessmentImages(List<Image> imagesData, string executionContext, string loggedInUser, RequestType type = RequestType.Mobile)
        {
            string currentContext = string.Empty;
            string request = "imagesData : " + JsonConvert.SerializeObject(imagesData);
            if (string.IsNullOrEmpty(executionContext))
            {
                currentContext = executionContextP;
            }
            else
            {
                currentContext = executionContext;
            }
            Common.ErrorLog(Type.Information, "UploadAssessmentImages : Start", request, "", loggedInUser, currentContext, reqType: type);
            ServiceResult results = new ServiceResult();
            try
            {
                if (imagesData.Count() > 0)
                {
                    DataTable dt = new DataTable();
                    dt.Columns.AddRange(new DataColumn[5]
                        {
                            new DataColumn("VEDScheduleID"),     
                            new DataColumn("FacilityDetailID"),  
                            new DataColumn("Image", typeof(Byte[])),                              
                            new DataColumn("ImageName") ,
                            new DataColumn("CreatedBy")
                        }
                        );

                    bool isValid = true;
                    foreach (Image item in imagesData)
                    {

                        byte[] toBytes = Convert.FromBase64String(item.ImageContent);
                        //string base64String = Convert.FromBase64String(toBytes);
                        if ((!string.IsNullOrEmpty(item.VEDScheduleID.ToString())) || (!string.IsNullOrEmpty(item.FacilityDetailsID.ToString())) || toBytes == null)
                        {
                            dt.Rows.Add(item.VEDScheduleID, item.FacilityDetailsID, toBytes, item.ImageName, item.AssessmentDoneBy);
                        }
                        else
                        {
                            isValid = false;
                        }
                    }
                    if (isValid)
                    {
                        using (SqlConnection conn = new SqlConnection(connectionString))
                        {
                            conn.Open();
                            SqlCommand cmd = new SqlCommand();
                            cmd.Connection = conn;
                            cmd.CommandType = CommandType.StoredProcedure;
                            cmd.CommandText = "usp_InsertUpdateAssessmentImages";
                            cmd.Parameters.AddWithValue("@Data", dt);
                            int rowAffected = cmd.ExecuteNonQuery();
                            if (rowAffected > 0)
                            {
                                results.ErrorCode = "1";
                                results.ErrorMessage = "Success";
                                results.ExecutionContext = currentContext;
                            }
                            else
                            {
                                results.ErrorCode = "0";
                                results.ErrorMessage = "Some error occurred while processing the request, requesting you to please again later.";
                                results.ExecutionContext = currentContext;

                            }
                        }
                    }
                    else
                    {
                        results.ErrorCode = "0";
                        results.ErrorMessage = "Some error occurred while processing the request, missing some mandatory fields.";
                        results.ExecutionContext = currentContext;
                    }
                }
                else
                {
                    results.ErrorCode = "0";
                    results.ErrorMessage = "No data available";
                    results.ExecutionContext = currentContext;
                }
                Common.ErrorLog(Type.Information, "UploadAssessmentImages : End", request, JsonConvert.SerializeObject(results), loggedInUser, currentContext, reqType: type);

            }





            catch (Exception ex)
            {
                results.ErrorCode = "0";
                results.ErrorMessage = "Oops! Something went wrong, please try again.";
                results.ExecutionContext = currentContext;
                Common.ErrorLog(Type.Error, "UploadAssessmentImages : End", request, "", loggedInUser, currentContext, ex, reqType: type);

            }
            return results;
        }
        private List<ScoringMaster> GetScoringMaster(int officeTypeID)
        {
            List<ScoringMaster> masters = new List<ScoringMaster>();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "usp_GetScoringMasters";
                cmd.Parameters.AddWithValue("@OfficeTypeID", officeTypeID);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables.Count > 0)
                {
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                        {
                            ScoringMaster master = new ScoringMaster();
                            master.OfficeType = ds.Tables[0].Rows[i]["Officetype"].ToString();
                            master.Criticality = ds.Tables[0].Rows[i]["Criticality"].ToString();
                            master.FacilityCheckPoints = Convert.ToInt32(ds.Tables[0].Rows[i]["FacilityCheckPoints"]);
                            master.Good = Convert.ToInt32(ds.Tables[0].Rows[i]["Good"]);
                            master.Poor = Convert.ToInt32(ds.Tables[0].Rows[i]["Poor"]);
                            master.NotWorking = Convert.ToInt32(ds.Tables[0].Rows[i]["NotWorking"]);
                            master.NotAvailable = Convert.ToInt32(ds.Tables[0].Rows[i]["NotAvailable"]);
                            masters.Add(master);
                        }
                    }


                }
                else
                {

                }
            }
            return masters;
        }
        public ServiceResult<FinalAssessmentData> GetAssessmentDetails_Audit(string VEDScheduleID, string executionContext, string loggedInUser, RequestType type = RequestType.Mobile)
        {
            ServiceResult<FinalAssessmentData> results = new ServiceResult<FinalAssessmentData>();
            List<AssesstmentDetails> assessmentDetails = new List<AssesstmentDetails>();
            List<VEDFinalData> schedules = new List<VEDFinalData>();
            //AssesstmentDetails assessmentDetail = new AssesstmentDetails();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "usp_Audit_GetAssessmentDetailsByVEDSchedulesID";
                cmd.Parameters.AddWithValue("@VEDScheduledID", VEDScheduleID);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables.Count > 0)
                {
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                        {
                            AssesstmentDetails assessmentDetail = new AssesstmentDetails();
                            assessmentDetail.FacilityArea = ds.Tables[0].Rows[i]["FacilityArea"].ToString();
                            assessmentDetail.FacilityAreaID = Convert.ToInt32(ds.Tables[0].Rows[i]["FacilityAreaID"]);
                            assessmentDetail.Criticality = ds.Tables[0].Rows[i]["Criticality"].ToString();
                            assessmentDetail.CriticalityID = Convert.ToInt32(ds.Tables[0].Rows[i]["CriticalityID"]);
                            assessmentDetail.Condition = ds.Tables[0].Rows[i]["Condition"].ToString();
                            assessmentDetail.Comments = ds.Tables[0].Rows[i]["Comments"].ToString();
                            assessmentDetail.FacilityDetails = ds.Tables[0].Rows[i]["FacilityDetails"].ToString();
                            assessmentDetail.FacilityDetailsID = Convert.ToInt32(ds.Tables[0].Rows[i]["FacilityDetailsID"]);
                            assessmentDetail.IsImageAvailable = Convert.ToBoolean(ds.Tables[0].Rows[i]["IsImageAvailable"]);
                            assessmentDetail.VEDScheduleID = Convert.ToInt32(ds.Tables[0].Rows[i]["VEDScheduleID"]);
                            // assessmentDetail.ImageURL = ds.Tables[0].Rows[i]["ImagesURL"].ToString();
                            assessmentDetails.Add(assessmentDetail);
                        }
                    }

                    if (ds.Tables[1].Rows.Count > 0)
                    {
                        for (int i = 0; i < ds.Tables[1].Rows.Count; i++)
                        {
                            VEDFinalData schedule = new VEDFinalData();
                            schedule.ScheduledOn = Convert.ToString(ds.Tables[1].Rows[i]["ScheduledOn"]);
                            schedule.ScheduledBy = Convert.ToString(ds.Tables[1].Rows[i]["ScheduledBy"]);
                            schedule.ActualAssesstmentDate = ds.Tables[1].Rows[i]["ActualAssesstmentDate"] != null ? Convert.ToString(ds.Tables[1].Rows[i]["ActualAssesstmentDate"]) : "";
                            schedule.AuditingDate = ds.Tables[1].Rows[i]["AuditingDate"] != null ? Convert.ToString(ds.Tables[1].Rows[i]["AuditingDate"]) : "";
                            schedule.Center = Convert.ToString(ds.Tables[1].Rows[i]["Center"]);
                            schedule.Zone = Convert.ToString(ds.Tables[1].Rows[i]["Zone"]);
                            //schedule.Address = Convert.ToString(ds.Tables[1].Rows[i]["Address"]);
                            schedule.City = Convert.ToString(ds.Tables[1].Rows[i]["City"]);
                            //schedule.OfficeCategory = Convert.ToString(ds.Tables[1].Rows[i]["OfficeCategory"]);
                            schedule.OfficeType = Convert.ToString(ds.Tables[1].Rows[i]["OfficeType"]);
                            //schedule.CarpetArea = ds.Tables[1].Rows[i]["CarpetArea"].ToString();
                            schedule.Vital = Convert.ToDouble(ds.Tables[1].Rows[i]["VitalCount"]);
                            schedule.Essential = Convert.ToDouble(ds.Tables[1].Rows[i]["EssentialCount"]);
                            schedule.Desirable = Convert.ToDouble(ds.Tables[1].Rows[i]["DesirableCount"]);
                            schedule.VitalNotApplicable = Convert.ToDouble(ds.Tables[1].Rows[i]["VitalNotApplicable"]);
                            schedule.EssentialNotApplicable = Convert.ToDouble(ds.Tables[1].Rows[i]["EssentialNotApplicable"]);
                            schedule.DesirableNotApplicable = Convert.ToDouble(ds.Tables[1].Rows[i]["DesirableNotApplicable"]);
                            schedule.TotalVEDByType = Convert.ToDouble(ds.Tables[1].Rows[i]["TotalVEDByType"]);
                            schedule.VEDSCORE = Convert.ToDouble(ds.Tables[1].Rows[i]["VEDScore"]);
                            schedule.MAXVEDSCORE = Convert.ToDouble(ds.Tables[1].Rows[i]["MAXVEDScore"]);
                            schedule.VEDSCOREPER = (schedule.VEDSCORE / schedule.MAXVEDSCORE) * 100;
                            schedules.Add(schedule);
                        }
                    }

                    FinalAssessmentData data = new FinalAssessmentData();

                    data.AssesstmentDetails = assessmentDetails;
                    data.VEDFinalData = schedules;

                    results.Data = data;
                }
                else
                {

                }
            }
            return results;
        }
        public ServiceResult<FinalAssessmentData> GetAssessmentDetails(string VEDScheduleID,string executionContext, string loggedInUser, RequestType type = RequestType.Mobile)
        {
            ServiceResult<FinalAssessmentData> results = new ServiceResult<FinalAssessmentData>();
            List<AssesstmentDetails> assessmentDetails = new List<AssesstmentDetails>();
            List<VEDFinalData> schedules = new List<VEDFinalData>();
            //AssesstmentDetails assessmentDetail = new AssesstmentDetails();


            executionContext = ValidateExecutionContext(executionContext, loggedInUser, type);
            if (!string.IsNullOrEmpty(executionContext))
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "usp_GetAssessmentDetailsByVEDSchedulesID";
                    cmd.Parameters.AddWithValue("@VEDScheduledID", VEDScheduleID);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);
                    if (ds.Tables.Count > 0)
                    {
                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                            {
                                AssesstmentDetails assessmentDetail = new AssesstmentDetails();
                                assessmentDetail.FacilityArea = ds.Tables[0].Rows[i]["FacilityArea"].ToString();
                                assessmentDetail.FacilityDetails = ds.Tables[0].Rows[i]["FaciltyDetails"].ToString();
                                assessmentDetail.Criticality = ds.Tables[0].Rows[i]["Criticality"].ToString();
                                assessmentDetail.Condition = ds.Tables[0].Rows[i]["Condition"].ToString();
                                assessmentDetail.Comments = ds.Tables[0].Rows[i]["Comments"].ToString();
                                assessmentDetail.FacilityDetailsID = Convert.ToInt32(ds.Tables[0].Rows[i]["FacilityID"]);
                                assessmentDetail.IsImageAvailable = Convert.ToBoolean(ds.Tables[0].Rows[i]["IsImageAvailable"]);
                                assessmentDetail.VEDScheduleID = Convert.ToInt32(ds.Tables[0].Rows[i]["VEDScheduleID"]);
                                //  assessmentDetail.ImageURL = ds.Tables[0].Rows[i]["ImagesURL"].ToString();
                                assessmentDetails.Add(assessmentDetail);
                            }
                        }

                        if (ds.Tables[1].Rows.Count > 0)
                        {
                            for (int i = 0; i < ds.Tables[1].Rows.Count; i++)
                            {
                                VEDFinalData schedule = new VEDFinalData();
                                schedule.ScheduledOn = Convert.ToString(ds.Tables[1].Rows[i]["ScheduledOn"]);
                                schedule.ScheduledBy = Convert.ToString(ds.Tables[1].Rows[i]["ScheduledBy"]);
                                schedule.ActualAssesstmentDate = ds.Tables[1].Rows[i]["ActualAssesstmentDate"] != null ? Convert.ToString(ds.Tables[1].Rows[i]["ActualAssesstmentDate"]) : "";
                                schedule.Center = Convert.ToString(ds.Tables[1].Rows[i]["Center"]);
                                schedule.Zone = Convert.ToString(ds.Tables[1].Rows[i]["Zone"]);
                                //schedule.Address = Convert.ToString(ds.Tables[1].Rows[i]["Address"]);
                                schedule.City = Convert.ToString(ds.Tables[1].Rows[i]["City"]);
                                //schedule.OfficeCategory = Convert.ToString(ds.Tables[1].Rows[i]["OfficeCategory"]);
                                schedule.OfficeType = Convert.ToString(ds.Tables[1].Rows[i]["OfficeType"]);
                                //schedule.CarpetArea = ds.Tables[1].Rows[i]["CarpetArea"].ToString();
                                schedule.Vital = Convert.ToDouble(ds.Tables[1].Rows[i]["VitalCount"]);
                                schedule.Essential = Convert.ToDouble(ds.Tables[1].Rows[i]["EssentialCount"]);
                                schedule.Desirable = Convert.ToDouble(ds.Tables[1].Rows[i]["DesirableCount"]);
                                schedule.VitalNotApplicable = Convert.ToDouble(ds.Tables[1].Rows[i]["VitalNotApplicable"]);
                                schedule.EssentialNotApplicable = Convert.ToDouble(ds.Tables[1].Rows[i]["EssentialNotApplicable"]);
                                schedule.DesirableNotApplicable = Convert.ToDouble(ds.Tables[1].Rows[i]["DesirableNotApplicable"]);
                                schedule.TotalVEDByType = Convert.ToDouble(ds.Tables[1].Rows[i]["TotalVEDByType"]);
                                schedule.VEDSCORE = Convert.ToDouble(ds.Tables[1].Rows[i]["VEDScore"]);
                                schedule.MAXVEDSCORE = Convert.ToDouble(ds.Tables[1].Rows[i]["MAXVEDScore"]);
                                schedule.VEDSCOREPER = (schedule.VEDSCORE / schedule.MAXVEDSCORE) * 100;
                                schedules.Add(schedule);
                            }
                        }

                        FinalAssessmentData data = new FinalAssessmentData();

                        data.AssesstmentDetails = assessmentDetails;
                        data.VEDFinalData = schedules;

                        results.Data = data;
                    }
                    else
                    {

                    }
                }
            }
            else
            {
                results.ErrorCode = "0";
                results.ErrorMessage = "Invalid Token.";
                results.ExecutionContext = string.Empty;
            }
            return results;
        }
        public ServiceResult<List<Image>> GetImagesBasedOnVEDID(string VEDID, string FacilityDetailsID, string executionContext, string loggedInUser, RequestType type = RequestType.Mobile)
        {
            ServiceResult<List<Image>> result = new ServiceResult<List<Image>>();
            List<Image> images = new List<Image>();
            try
            {
                using (SqlConnection conn = new SqlConnection(connectionString))
                {
                    conn.Open();
                    SqlCommand cmd = new SqlCommand();
                    cmd.Connection = conn;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.CommandText = "usp_GetImagesBasedOnVEDID";
                    cmd.Parameters.AddWithValue("@VEDID", VEDID);
                    cmd.Parameters.AddWithValue("@FaciltyDetailsID", FacilityDetailsID);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataSet ds = new DataSet();
                    da.Fill(ds);
                    if (ds.Tables.Count > 0)
                    {
                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                            {
                                Image image = new Image();

                                image.ImageName = ds.Tables[0].Rows[i]["ImageName"].ToString();
                                image.ImageExtension = ds.Tables[0].Rows[i]["ImageName"].ToString().Split('.')[1];

                                byte[] toBytes = (Byte[])(ds.Tables[0].Rows[i]["Image"]);
                                image.ImageContentBytes = toBytes;
                                string base64String = Convert.ToBase64String(toBytes, 0, toBytes.Length);
                                //Here converting the byteArray to string
                                // string str = Encoding.ASCII.GetString(toBytes, 0, toBytes.Length);
                                image.ImageContent = base64String;


                                images.Add(image);
                            }
                            result.ErrorCode = "1";
                            result.ErrorMessage = "Success";
                            result.ExecutionContext = "";
                            result.Data = images;
                        }
                        else
                        {
                            result.ErrorCode = "0";
                            result.ErrorMessage = "Oops! Something went wrong, please try again.";
                            result.ExecutionContext = "";
                        }


                    }
                    else
                    {
                        result.ErrorCode = "0";
                        result.ErrorMessage = "Oops! Something went wrong, please try again.";
                        result.ExecutionContext = "";
                    }
                }
            }
            catch (Exception ex)
            {

                result.ErrorCode = "0";
                result.ErrorMessage = "Oops! Something went wrong, please try again.";
                result.ExecutionContext = "";
                Common.ErrorLog(Type.Error, "GetImagesBasedOnVEDID : End", "", "", loggedInUser, "", ex, reqType: type);
            }

            return result;
        }
        #endregion

        #region Generic
        public ServiceResult<Generic> GenericMethod(string spName, string executionContext, string loggedInUser, RequestType type = RequestType.Mobile, params string[] arr)
        {
            if (string.IsNullOrEmpty(executionContext))
            {
                executionContext = executionContextP;
            }
            ServiceResult<Generic> result = new ServiceResult<Generic>();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = spName;

                if (arr != null)
                {
                    SqlParameter[] param = new SqlParameter[arr.Length];

                    for (int i = 0; i < arr.Length; i++)
                    {
                        string[] par = arr[i].Split('=');
                        param[i] = new SqlParameter("@" + par[0], par[1]);
                    }

                    cmd.Parameters.AddRange(param);
                }
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                Generic gen = new Generic();

                if (ds.Tables.Count > 0)
                {
                    gen.ResultData = JsonConvert.SerializeObject(ds);
                }
                result.Data = gen;
                result.ExecutionContext = executionContext;
            }
            return result;

        }
        public ServiceResult GenericInsertUpdateMethod(string spName, string executionContext, string loggedInUser, RequestType type = RequestType.Mobile, params string[] arr)
        {
            if (string.IsNullOrEmpty(executionContext))
            {
                executionContext = executionContextP;
            }
            ServiceResult result = new ServiceResult();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = spName;

                if (arr != null)
                {
                    SqlParameter[] param = new SqlParameter[arr.Length];

                    for (int i = 0; i < arr.Length; i++)
                    {
                        string[] par = arr[i].Split('=');
                        param[i] = new SqlParameter("@" + par[0], par[1]);
                    }

                    cmd.Parameters.AddRange(param);
                }

                int rowsAffected = cmd.ExecuteNonQuery();
                if (rowsAffected > 0)
                {
                    result.ErrorCode = "1";
                }
                else
                {
                    result.ErrorCode = "0";
                }
                //SqlDataAdapter da = new SqlDataAdapter(cmd);
                //DataSet ds = new DataSet();
                //da.Fill(ds);
                result.ExecutionContext = executionContext;
            }
            return result;

        }
        public ServiceResult LoginLogOut(string executionContext, string loggedInUser, string loginType = "LogOut", RequestType type = RequestType.Mobile)
        {
            string currentContext = string.Empty;
            string request = "executionContext : " + executionContext + " loggedInUser : " + loggedInUser + " RequestType : " + type;
            Common.ErrorLog(Type.Information, "LoginLogOut : Start", request, "", loggedInUser, executionContext, reqType: type);
            ServiceResult results = new ServiceResult();
            try
            {

                if (string.IsNullOrEmpty(executionContext))
                {
                    results.ErrorCode = "0";
                    results.ErrorMessage = "please provide Execution Context.";
                    results.ExecutionContext = executionContext;
                }
                else if (string.IsNullOrEmpty(loggedInUser))
                {
                    results.ErrorCode = "0";
                    results.ErrorMessage = "please provide LoggedIn User";
                    results.ExecutionContext = currentContext;
                }
                else if (string.IsNullOrEmpty(loginType))
                {
                    results.ErrorCode = "0";
                    results.ErrorMessage = "please provide Login Type.";
                    results.ExecutionContext = currentContext;
                }
                else
                {
                    using (SqlConnection conn = new SqlConnection(connectionString))
                    {
                        conn.Open();
                        SqlCommand cmd = new SqlCommand();
                        cmd.Connection = conn;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "usp_InsertDeleteExecutionContext";
                        cmd.Parameters.AddWithValue("@LoginName", loggedInUser);
                        cmd.Parameters.AddWithValue("@ExecutionContext", executionContext);
                        cmd.Parameters.AddWithValue("@Type", loginType);
                        int rowsaffected = cmd.ExecuteNonQuery();
                        if (rowsaffected > 0)
                        {
                            results.ErrorCode = "1";
                            if (loginType == "Logout")
                            {
                                results.ErrorMessage = "Successfully logged out";
                            }
                            else
                            {
                                results.ErrorMessage = "Successfully updated date";
                                results.ExecutionContext = executionContext;
                            }
                        }
                        else
                        {
                            results.ErrorCode = "0";
                            results.ErrorMessage = "Error occurred while " + loginType;
                            results.ExecutionContext = currentContext;
                        }
                    }
                }
                Common.ErrorLog(Type.Information, "LoginLogOut : End", request, JsonConvert.SerializeObject(results), loggedInUser, currentContext, reqType: type);
            }
            catch (Exception ex)
            {
                results.ErrorCode = "0";
                results.ErrorMessage = "Oops! Something went wrong, please try again.";
                results.ExecutionContext = currentContext;
                Common.ErrorLog(Type.Error, "LoginLogOut : End", request, "", loggedInUser, currentContext, ex, reqType: type);

            }
            return results;
        }
        #endregion
        
        #region Audit Methods
        public ServiceResult<VEDScore> SaveAsessmentDetails_Web_Audit(List<AssesstmentDetails> assesmentData, string executionContext, string loggedInUser, RequestType type = RequestType.Mobile, AssessmentType assesssmentType = AssessmentType.AreaLevel)
        {
            string currentContext = string.Empty;
            string request = "assesmentData : " + JsonConvert.SerializeObject(assesmentData);

            if (string.IsNullOrEmpty(executionContext))
            {
                currentContext = executionContextP;
            }
            else
            {
                currentContext = executionContext;
            }
            Common.ErrorLog(Type.Information, "SaveAsessmentDetails : Start", request, "", loggedInUser, currentContext, reqType: type);
            ServiceResult<VEDScore> results = new ServiceResult<VEDScore>();
            //Calculation  wala Part to be taken here;
            int identity = InsertVEDAuditDetails(assesmentData.FirstOrDefault().VEDScheduleID.ToString(), loggedInUser);

            try
            {
                if (assesmentData.Count() > 0)
                {
                    DataTable dt = new DataTable();
                    dt.Columns.AddRange(new DataColumn[10]
                        {
                            new DataColumn("VEDScheduleID"),          //[VEDScheduleID] [int] NOT NULL,
                            new DataColumn("FacilityAreaID"),         //[FacilityAreaID] [int] NOT NULL,
                            new DataColumn("FacilityDetailsID"),      //[FacilityDetailsID] [int] NOT NULL,
                            new DataColumn("CriticalityID"),          //[CriticalityID] [int] NOT NULL,
                            new DataColumn("Condition"),              //[Condition] [varchar](20) NOT NULL,
                            new DataColumn("AssessmentDoneBy"),       //[AssessmentDoneBy] [varchar](200) NOT NULL,
                            new DataColumn("AssessmentType"),         //[AssessmentDate] [datetime] NOT NULL,
                            new DataColumn("Comments"),
                            new DataColumn("AuditorCondition"),
                            new DataColumn("AuditorComments"),
                            
                            //[Comments] [varchar](max) NOT NULL,
                        }
                        );
                    foreach (AssesstmentDetails item in assesmentData)
                    {
                        dt.Rows.Add(identity, item.FacilityAreaID, item.FacilityDetailsID, item.CriticalityID, item.Condition, item.AssessmentDoneBy, (Int32)assesssmentType, item.Comments, item.AuditorCondition, item.AuditorComment);
                    }
                    using (SqlConnection conn = new SqlConnection(connectionString))
                    {
                        conn.Open();
                        SqlCommand cmd = new SqlCommand();
                        cmd.Connection = conn;
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandText = "usp_Audit_SaveAssesstmentDetails";
                        cmd.Parameters.AddWithValue("@Data", dt);
                        cmd.Parameters.AddWithValue("@VEDScheduleID", assesmentData.FirstOrDefault().VEDScheduleID.ToString());
                        int rowAffected = cmd.ExecuteNonQuery();
                        if (rowAffected > 0)
                        {
                            results.ErrorCode = "1";
                            results.ErrorMessage = "Success";
                            results.ExecutionContext = currentContext;

                        }
                        else
                        {


                        }
                    }
                }
                else
                {
                    results.ErrorCode = "0";
                    results.ErrorMessage = "No data available";
                    results.ExecutionContext = currentContext;
                }
                Common.ErrorLog(Type.Information, "SaveAsessmentDetails : End", request, JsonConvert.SerializeObject(results), loggedInUser, currentContext, reqType: type);

            }
            catch (Exception ex)
            {
                results.ErrorCode = "0";
                results.ErrorMessage = "Oops! Something went wrong, please try again.";
                results.ExecutionContext = currentContext;
                Common.ErrorLog(Type.Error, "SaveAsessmentDetails : End", request, "", loggedInUser, currentContext, ex, reqType: type);

            }





            //else
            //{
            //    results.ErrorCode = "0";
            //    results.ErrorMessage = "Some error occurred while processing the request, requesting you to please again later.";
            //    results.ExecutionContext = currentContext;
            //}



            return results;
        }
        public int InsertVEDAuditDetails(string VEDID, string userName)
        {

            int identity = 0;
            DateTime _date = DateTime.Now;
            var _dateString = _date.ToString("yyyy/MM/dd");
            //bool isSuccess = true;
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "usp_Audit_InsertVEDdetails";
                cmd.Parameters.AddWithValue("@Auditior", userName);
                cmd.Parameters.AddWithValue("@VEDScheduleID", VEDID);
                cmd.Parameters.AddWithValue("@CreatedBy", userName);
                cmd.Parameters.AddWithValue("@AuditingDate", _dateString);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables.Count > 0)
                {

                    identity = Convert.ToInt32(ds.Tables[0].Rows[0]["Identity"]);
                }
                //int rowAffected = cmd.exe();
                //if (rowAffected > 0)
                //{
                //    isSuccess = true;

                //}
                //else
                //{
                //    isSuccess = false;

                //}
            }

            return identity;
        }
        public ServiceResult<FinalAssessmentData> GetAssessmentDetailsForView_Audit(string VEDScheduleID, string executionContext, string loggedInUser, RequestType type = RequestType.Mobile)
        {
            ServiceResult<FinalAssessmentData> results = new ServiceResult<FinalAssessmentData>();
            List<AssesstmentDetails> assessmentDetails = new List<AssesstmentDetails>();
            List<VEDFinalData> schedules = new List<VEDFinalData>();
            //AssesstmentDetails assessmentDetail = new AssesstmentDetails();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "usp_Audit_GetAssessmentDetailsofAuditorForView";
                cmd.Parameters.AddWithValue("@AuditID", VEDScheduleID);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                if (ds.Tables.Count > 0)
                {
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                        {
                            AssesstmentDetails assessmentDetail = new AssesstmentDetails();
                            assessmentDetail.FacilityArea = ds.Tables[0].Rows[i]["FacilityArea"].ToString();
                            assessmentDetail.FacilityAreaID = Convert.ToInt32(ds.Tables[0].Rows[i]["FacilityAreaID"]);
                            assessmentDetail.Criticality = ds.Tables[0].Rows[i]["Criticality"].ToString();
                            assessmentDetail.CriticalityID = Convert.ToInt32(ds.Tables[0].Rows[i]["CriticalityID"]);
                            assessmentDetail.Condition = ds.Tables[0].Rows[i]["Condition"].ToString();
                            assessmentDetail.Comments = ds.Tables[0].Rows[i]["Comments"].ToString();
                            assessmentDetail.FacilityDetails = ds.Tables[0].Rows[i]["FacilityDetails"].ToString();
                            assessmentDetail.FacilityDetailsID = Convert.ToInt32(ds.Tables[0].Rows[i]["FacilityDetailsID"]);
                            assessmentDetail.IsImageAvailable = Convert.ToBoolean(ds.Tables[0].Rows[i]["IsImageAvailable"]);
                            assessmentDetail.VEDScheduleID = Convert.ToInt32(ds.Tables[0].Rows[i]["VEDScheduleID"]);
                            assessmentDetail.AuditorCondition = ds.Tables[0].Rows[i]["AuditorCondition"].ToString();
                            assessmentDetail.AuditorComment = ds.Tables[0].Rows[i]["AuditComments"].ToString();
                            // assessmentDetail.ImageURL = ds.Tables[0].Rows[i]["ImagesURL"].ToString();
                            assessmentDetails.Add(assessmentDetail);
                        }
                    }

                    if (ds.Tables[1].Rows.Count > 0)
                    {
                        for (int i = 0; i < ds.Tables[1].Rows.Count; i++)
                        {
                            VEDFinalData schedule = new VEDFinalData();
                            schedule.ScheduledOn = Convert.ToString(ds.Tables[1].Rows[i]["ScheduledOn"]);
                            schedule.ScheduledBy = Convert.ToString(ds.Tables[1].Rows[i]["ScheduledBy"]);
                            schedule.ActualAssesstmentDate = ds.Tables[1].Rows[i]["ActualAssesstmentDate"] != null ? Convert.ToString(ds.Tables[1].Rows[i]["ActualAssesstmentDate"]) : "";
                            schedule.AuditingDate = ds.Tables[1].Rows[i]["AuditingDate"] != null ? Convert.ToString(ds.Tables[1].Rows[i]["AuditingDate"]) : "";
                            schedule.Center = Convert.ToString(ds.Tables[1].Rows[i]["Center"]);
                            schedule.Zone = Convert.ToString(ds.Tables[1].Rows[i]["Zone"]);
                            //schedule.Address = Convert.ToString(ds.Tables[1].Rows[i]["Address"]);
                            schedule.City = Convert.ToString(ds.Tables[1].Rows[i]["City"]);
                            //schedule.OfficeCategory = Convert.ToString(ds.Tables[1].Rows[i]["OfficeCategory"]);
                            schedule.OfficeType = Convert.ToString(ds.Tables[1].Rows[i]["OfficeType"]);
                            //schedule.CarpetArea = ds.Tables[1].Rows[i]["CarpetArea"].ToString();
                            schedule.Vital = Convert.ToDouble(ds.Tables[1].Rows[i]["VitalCount"]);
                            schedule.Essential = Convert.ToDouble(ds.Tables[1].Rows[i]["EssentialCount"]);
                            schedule.Desirable = Convert.ToDouble(ds.Tables[1].Rows[i]["DesirableCount"]);
                            schedule.VitalNotApplicable = Convert.ToDouble(ds.Tables[1].Rows[i]["VitalNotApplicable"]);
                            schedule.EssentialNotApplicable = Convert.ToDouble(ds.Tables[1].Rows[i]["EssentialNotApplicable"]);
                            schedule.DesirableNotApplicable = Convert.ToDouble(ds.Tables[1].Rows[i]["DesirableNotApplicable"]);
                            schedule.TotalVEDByType = Convert.ToDouble(ds.Tables[1].Rows[i]["TotalVEDByType"]);
                            schedule.VEDSCORE = Convert.ToDouble(ds.Tables[1].Rows[i]["VEDScore"]);
                            schedule.MAXVEDSCORE = Convert.ToDouble(ds.Tables[1].Rows[i]["MAXVEDScore"]);
                            schedule.VEDSCOREPER = (schedule.VEDSCORE / schedule.MAXVEDSCORE) * 100;
                            schedules.Add(schedule);
                        }
                    }

                    FinalAssessmentData data = new FinalAssessmentData();

                    data.AssesstmentDetails = assessmentDetails;
                    data.VEDFinalData = schedules;

                    results.Data = data;
                }
                else
                {

                }
            }
            return results;
        }
        public ServiceResult<Generic> GetZoneData(String spName)
        {

            ServiceResult<Generic> result = new ServiceResult<Generic>();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = spName;


                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                Generic gen = new Generic();

                if (ds.Tables.Count > 0)
                {
                    gen.ResultData = JsonConvert.SerializeObject(ds);
                }
                result.Data = gen;

            }
            return result;

        } 
          public ServiceResult<Generic> GetOfficeType(String spName)
        {

            ServiceResult<Generic> result = new ServiceResult<Generic>();
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = conn;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = spName;


                SqlDataAdapter da = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                da.Fill(ds);
                Generic gen = new Generic();

                if (ds.Tables.Count > 0)
                {
                    gen.ResultData = JsonConvert.SerializeObject(ds);
                }
                result.Data = gen;

            }
            return result;

        } 
        #endregion

    }





}
