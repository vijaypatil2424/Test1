﻿using System;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.Workflow;
using RCPCampus_VED.BusinessLayer;
using RCPCampus_VED.DTO;

namespace RCPCampus_VED.ER.OfficeTypeMaster
{
    /// <summary>
    /// List Item Events
    /// </summary>
    public class OfficeTypeMaster : SPItemEventReceiver
    {
        /// <summary>
        /// An item was added.
        /// </summary>
        public override void ItemAdded(SPItemEventProperties properties)
        {
            base.ItemAdded(properties);
            InsertUpdateItem(properties);
        }

        /// <summary>
        /// An item was updated.
        /// </summary>
        public override void ItemUpdated(SPItemEventProperties properties)
        {
            base.ItemUpdated(properties);
            InsertUpdateItem(properties);
        }
        private void InsertUpdateItem(SPItemEventProperties properties)
        {

            Business BL = new Business();
            string executionContext = "";
            string loginName = string.Empty;
            executionContext = Guid.NewGuid().ToString();
            SPListItem item = properties.ListItem;
            loginName = item.Web.CurrentUser.LoginName.Split('\\')[1].ToString();
            string[] arr = new string[4];
            arr[0] = "ID=" + item["ID"].ToString();
            arr[1] = "Title=" + item["Title"];
            arr[2] = "type=OFFICETYPE";//+ user.LoginName;
            arr[3] = "UserId=" + loginName;
            ServiceResult result = BL.GenericInsertUpdateMethod("usp_InsertUpdateMasterByType", executionContext, loginName, RequestType.Portal, arr);
            // DataSet ds = JsonConvert.DeserializeObject<DataSet>(result.re);
            if (result.ErrorCode == "1")
            {
                //Success log
            }
            else
            {
                ///Error Log
            }

        }


    }
}