﻿using System;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.Workflow;
using RCPCampus_VED.BusinessLayer;
using RCPCampus_VED.DTO;
using Newtonsoft.Json;

namespace RCPCampus_VED.ER.RCPERAssessmentScoringMaster
{
    /// <summary>
    /// List Item Events
    /// </summary>
    public class RCPERAssessmentScoringMaster : SPItemEventReceiver
    {
        public override void ItemAdding(SPItemEventProperties properties)
        {
            base.ItemAdding(properties);
            //string Criticality = properties.AfterProperties["Criticality"].ToString();
            if (string.IsNullOrEmpty(properties.AfterProperties["Facility"].ToString()))
            {
                properties.Status = SPEventReceiverStatus.CancelWithError;
                properties.ErrorMessage = "Please select Facility type.";
            }
            else if (string.IsNullOrEmpty(properties.AfterProperties["Criticality"].ToString()))
            {
                properties.Status = SPEventReceiverStatus.CancelWithError;
                properties.ErrorMessage = "Please select Criticality.";

            }
            else if (string.IsNullOrEmpty(properties.AfterProperties["Facility Check Points"].ToString()))
            {
                properties.Status = SPEventReceiverStatus.CancelWithError;
                properties.ErrorMessage = "Please Enter Facility Check Points";
            }
            else if (string.IsNullOrEmpty(properties.AfterProperties["Good"].ToString()))
            {
                properties.Status = SPEventReceiverStatus.CancelWithError;
                properties.ErrorMessage = "Please Enter Score for Good.";
            }
            else if (string.IsNullOrEmpty(properties.AfterProperties["Poor"].ToString()))
            {
                properties.Status = SPEventReceiverStatus.CancelWithError;
                properties.ErrorMessage = "Please Enter Score for Poor.";

            }
            else if (string.IsNullOrEmpty(properties.AfterProperties["Not Working"].ToString()))
            {
                properties.Status = SPEventReceiverStatus.CancelWithError;
                properties.ErrorMessage = "Please Enter Score for Not Working.";
            }
            else if (string.IsNullOrEmpty(properties.AfterProperties["Not Available"].ToString()))
            {
                properties.Status = SPEventReceiverStatus.CancelWithError;
                properties.ErrorMessage = "Please Enter Score for Not Available.";
            }

        }

        /// <summary>
        /// An item is being updated.
        /// </summary>
        public override void ItemUpdating(SPItemEventProperties properties)
        {
            base.ItemUpdating(properties);
            //string Criticality = properties.AfterProperties["Criticality"].ToString();
            if (string.IsNullOrEmpty(properties.AfterProperties["Facility"].ToString()))
            {
                properties.Status = SPEventReceiverStatus.CancelWithError;
                properties.ErrorMessage = "Please select Facility type.";
            }
            else if (string.IsNullOrEmpty(properties.AfterProperties["Criticality"].ToString()))
            {
                properties.Status = SPEventReceiverStatus.CancelWithError;
                properties.ErrorMessage = "Please select Criticality.";

            }
            else if (string.IsNullOrEmpty(properties.AfterProperties["Facility Check Points"].ToString()))
            {
                properties.Status = SPEventReceiverStatus.CancelWithError;
                properties.ErrorMessage = "Please Enter Facility Check Points";
            }
            else if (string.IsNullOrEmpty(properties.AfterProperties["Good"].ToString()))
            {
                properties.Status = SPEventReceiverStatus.CancelWithError;
                properties.ErrorMessage = "Please Enter Score for Good.";
            }
            else if (string.IsNullOrEmpty(properties.AfterProperties["Poor"].ToString()))
            {
                properties.Status = SPEventReceiverStatus.CancelWithError;
                properties.ErrorMessage = "Please Enter Score for Poor.";

            }
            else if (string.IsNullOrEmpty(properties.AfterProperties["Not Working"].ToString()))
            {
                properties.Status = SPEventReceiverStatus.CancelWithError;
                properties.ErrorMessage = "Please Enter Score for Not Working.";
            }
            else if (string.IsNullOrEmpty(properties.AfterProperties["Not Available"].ToString()))
            {
                properties.Status = SPEventReceiverStatus.CancelWithError;
                properties.ErrorMessage = "Please Enter Score for Not Available.";
            }
        }

        /// <summary>
        /// An item was added.
        /// </summary>
        public override void ItemAdded(SPItemEventProperties properties)
        {
            base.ItemAdded(properties);
            InsertUpdateItem(properties);
        }

        /// <summary>
        /// An item was updated.
        /// </summary>
        public override void ItemUpdated(SPItemEventProperties properties)
        {
            base.ItemUpdated(properties);
            InsertUpdateItem(properties);

        }

        private void InsertUpdateItem(SPItemEventProperties properties)
        {
            Business BL = new Business();
            string executionContext = "";
            string loginName = string.Empty;
            executionContext = Guid.NewGuid().ToString();
            SPListItem item = properties.ListItem;
            loginName = item.Web.CurrentUser.LoginName.Split('\\')[1].ToString();
            string[] arr = null;
            try
            {

                SPFieldLookupValue Facility = new SPFieldLookupValue(item["Facility"].ToString());
                int FacilityID = Facility.LookupId;

                SPFieldLookupValue Criticality = new SPFieldLookupValue(item["Criticality"].ToString());
                int CriticalityID = Criticality.LookupId;


                arr = new string[9];
                arr[0] = "ID=" + item["ID"].ToString();
                arr[1] = "OfficeTypeID=" + FacilityID;
                arr[2] = "CriticalityID=" + CriticalityID;
                arr[3] = "FacilityCheckPoints=" + item["Facility_x0020_Check_x0020_Point"].ToString();
                arr[4] = "Good=" + item["Good"].ToString();
                arr[5] = "Poor=" + item["Poor"].ToString();
                arr[6] = "NotWorking=" + item["Not_x0020_Working"].ToString();
                arr[7] = "NotAvailable=" + item["Not_x0020_Available"].ToString();
                arr[8] = "ModifiedBy=" + loginName;
                ServiceResult result = BL.GenericInsertUpdateMethod("usp_InsertUpdateScoringMaster", executionContext, loginName, RequestType.Portal, arr);
                // DataSet ds = JsonConvert.DeserializeObject<DataSet>(result.re);
                if (result.ErrorCode == "1")
                {
                    Common.ErrorLog(Type.Information, "ERAssessmentScoringMaster : InsertUpdateItem", JsonConvert.SerializeObject(arr), "Success", loginName, result.ExecutionContext, null, RequestType.Portal);
                }
                else
                {
                    Common.ErrorLog(Type.Error, "ERAssessmentScoringMaster : InsertUpdateItem", JsonConvert.SerializeObject(arr), "Failure", loginName, result.ExecutionContext, null, RequestType.Portal);
                }
            }
            catch (Exception ex)
            {

                Common.ErrorLog(Type.Error, "ERAssessmentScoringMaster : InsertUpdateItem", JsonConvert.SerializeObject(arr), "Success", loginName, executionContext, ex, RequestType.Portal);
            }
        }

    }
}