﻿using System;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.Workflow;
using Newtonsoft.Json;
using RCPCampus_VED.DTO;
using RCPCampus_VED.BusinessLayer;

namespace RCPCampus_VED.ER.RCPERCriticalityMaster
{
    /// <summary>
    /// List Item Events
    /// </summary>
    public class RCPERCriticalityMaster : SPItemEventReceiver
    {
        /// <summary>
        /// An item is being added.
        /// </summary>
        public override void ItemAdding(SPItemEventProperties properties)
        {
            base.ItemAdding(properties);

        }

        /// <summary>
        /// An item is being updated.
        /// </summary>
        public override void ItemUpdating(SPItemEventProperties properties)
        {
            base.ItemUpdating(properties);
        }

        /// <summary>
        /// An item was added.
        /// </summary>
        public override void ItemAdded(SPItemEventProperties properties)
        {
            base.ItemAdded(properties);
            InsertUpdateItem(properties);
        }

        /// <summary>
        /// An item was updated.
        /// </summary>
        public override void ItemUpdated(SPItemEventProperties properties)
        {
            base.ItemUpdated(properties);
            InsertUpdateItem(properties);
        }

        private void InsertUpdateItem(SPItemEventProperties properties)
        {
            Business BL = new Business();
            string executionContext = "";
            string loginName = string.Empty;
            executionContext = Guid.NewGuid().ToString();
            SPListItem item = properties.ListItem;
            loginName = item.Web.CurrentUser.LoginName.Split('\\')[1].ToString();
            string[] arr = null;
            try
            {

                arr = new string[5];
                arr[0] = "ID=" + item["ID"].ToString();
                arr[1] = "Title=" + item["Title"].ToString();
                arr[2] = "type=CRITICALITY";//+ user.LoginName;
                arr[3] = "UserId=" + loginName;
                arr[4] = "Initials=" + item["Initials"].ToString();
                ServiceResult result = BL.GenericInsertUpdateMethod("usp_InsertUpdateMasterByType", executionContext, loginName, RequestType.Portal, arr);
                // DataSet ds = JsonConvert.DeserializeObject<DataSet>(result.re);
                if (result.ErrorCode == "1")
                {
                    Common.ErrorLog(Type.Information, "EventReceiver1 : InsertUpdateItem", JsonConvert.SerializeObject(arr), "Success", loginName, result.ExecutionContext, null, RequestType.Portal);
                }
                else
                {
                    Common.ErrorLog(Type.Error, "EventReceiver1 : InsertUpdateItem", JsonConvert.SerializeObject(arr), "Success", loginName, result.ExecutionContext, null, RequestType.Portal);
                }
            }
            catch (Exception ex)
            {

                Common.ErrorLog(Type.Error, "EventReceiver1 : InsertUpdateItem", JsonConvert.SerializeObject(arr), "failure", loginName, executionContext, ex, RequestType.Portal);
            }

        }

    }
}