﻿using System;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.Workflow;
using RCPCampus_VED.BusinessLayer;
using RCPCampus_VED.DTO;
using Newtonsoft.Json;

namespace RCPCampus_VED.ER.RCPERFacilityDetails
{
    /// <summary>
    /// List Item Events
    /// </summary>
    public class RCPERFacilityDetails : SPItemEventReceiver
    {
        /// <summary>
        /// An item is being added.
        /// </summary>
        public override void ItemAdding(SPItemEventProperties properties)
        {
            base.ItemAdding(properties);
            //SPListItem item = properties.ListItem;
            //string after = properties.AfterProperties["StateHead"].ToString();

            //string facilityValue = properties.AfterProperties["Facility Area"].ToString();
            //string OfficeTypeValue = properties.AfterProperties["Office Type"].ToString();
            string comments = properties.AfterProperties["Comments"].ToString();
            //string Criticality = properties.AfterProperties["Criticality"].ToString();
            if (string.IsNullOrEmpty(properties.AfterProperties["Facility_x0020_Area"].ToString()))
            {
                properties.Status = SPEventReceiverStatus.CancelWithError;
                properties.ErrorMessage = "Please Select Facility Area";
            }
            else if (string.IsNullOrEmpty(properties.AfterProperties["Office_x0020_Type"].ToString()))
            {
                properties.Status = SPEventReceiverStatus.CancelWithError;
                properties.ErrorMessage = "Please Select Office Type";

            }
            else if (string.IsNullOrEmpty(comments) || comments.Contains("None"))
            {
                properties.Status = SPEventReceiverStatus.CancelWithError;
                properties.ErrorMessage = "Please Enter Comments";
            }
            else if (string.IsNullOrEmpty(properties.AfterProperties["Criticality"].ToString()))
            {
                properties.Status = SPEventReceiverStatus.CancelWithError;
                properties.ErrorMessage = "Please Select Criticality Type";
            }
        }

        /// <summary>
        /// An item is being updated.
        /// </summary>
        public override void ItemUpdating(SPItemEventProperties properties)
        {
            base.ItemUpdating(properties);
            //SPListItem item = properties.ListItem;
            //string after = properties.AfterProperties["StateHead"].ToString();


            //string facilityValue = properties.AfterProperties["Facility Area"].ToString();
            //string OfficeTypeValue = properties.AfterProperties["Office Type"].ToString();
            string comments = properties.AfterProperties["Comments"].ToString();
            //string Criticality = properties.AfterProperties["Criticality"].ToString();
            if (string.IsNullOrEmpty(properties.AfterProperties["Facility_x0020_Area"].ToString()))
            {
                properties.Status = SPEventReceiverStatus.CancelWithError;
                properties.ErrorMessage = "Please Select Facility Area";
            }
            else if (string.IsNullOrEmpty(properties.AfterProperties["Office_x0020_Type"].ToString()))
            {
                properties.Status = SPEventReceiverStatus.CancelWithError;
                properties.ErrorMessage = "Please Select Office Type";

            }
            else if (string.IsNullOrEmpty(comments) || comments.Contains("None"))
            {
                properties.Status = SPEventReceiverStatus.CancelWithError;
                properties.ErrorMessage = "Please Enter Comments";
            }
            else if (string.IsNullOrEmpty(properties.AfterProperties["Criticality"].ToString()))
            {
                properties.Status = SPEventReceiverStatus.CancelWithError;
                properties.ErrorMessage = "Please Select Criticality Type";
            }
        }

        /// <summary>
        /// An item was added.
        /// </summary>
        public override void ItemAdded(SPItemEventProperties properties)
        {
            base.ItemAdded(properties);
            InsertUpdateItem(properties);
        }

        /// <summary>
        /// An item was updated.
        /// </summary>
        public override void ItemUpdated(SPItemEventProperties properties)
        {
            base.ItemUpdated(properties);
            InsertUpdateItem(properties);
        }
        private void InsertUpdateItem(SPItemEventProperties properties)
        {

            Business BL = new Business();
            string executionContext = "";
            string loginName = string.Empty;
            executionContext = Guid.NewGuid().ToString();
            SPListItem item = properties.ListItem;
            loginName = item.Web.CurrentUser.LoginName.Split('\\')[1].ToString();
            string[] arr = null;
            try
            {
                //string facilityValue = item["Facility_x0020_Area"].ToString();
                //string OfficeTypeValue = item["Office_x0020_Type"].ToString();
                string comments = item["Comments"].ToString();
                //string Criticality = item["Criticality"].ToString();
                if (item["Facility_x0020_Area"] == null)
                {
                    properties.Status = SPEventReceiverStatus.CancelWithError;
                    properties.ErrorMessage = "Please Select Facility Area";
                }
                else if (item["Office_x0020_Type"] == null)
                {
                    properties.Status = SPEventReceiverStatus.CancelWithError;
                    properties.ErrorMessage = "Please Select Office Type";

                }
                else if (string.IsNullOrEmpty(comments) || comments.Contains("None"))
                {
                    properties.Status = SPEventReceiverStatus.CancelWithError;
                    properties.ErrorMessage = "Please Enter Comments";
                }
                else if (item["Criticality"] == null)
                {
                    properties.Status = SPEventReceiverStatus.CancelWithError;
                    properties.ErrorMessage = "Please Select Criticality Type";
                }
                else
                {


                    var Comments = item.Fields.GetFieldByInternalName("Comments");
                    var Address = item[Comments.Id];
                    var AddressText = Comments.GetFieldValueAsText(Address);



                    SPFieldLookupValue facility = new SPFieldLookupValue(item["Facility_x0020_Area"].ToString());
                    int facilityID = facility.LookupId;

                    SPFieldLookupValue OfficeType = new SPFieldLookupValue(item["Office_x0020_Type"].ToString());
                    int OfficeTypeID = OfficeType.LookupId;

                    SPFieldLookupValue criticality = new SPFieldLookupValue(item["Criticality"].ToString());
                    int criticalityID = criticality.LookupId;

                    arr = new string[7];
                    arr[0] = "ID=" + item["ID"].ToString();
                    arr[1] = "FacilityAreaID=" + facilityID;
                    arr[2] = "Title=" + item["Title"].ToString();
                    arr[3] = "OfficeTypeID=" + OfficeTypeID;
                    arr[4] = "Comments=" + AddressText;
                    arr[5] = "CreatedBy=" + loginName;
                    arr[6] = "CriticalityID=" + criticalityID;
                    ServiceResult result = BL.GenericInsertUpdateMethod("usp_InsertUpdateFacilityDetails", executionContext, loginName, RequestType.Portal, arr);
                    // DataSet ds = JsonConvert.DeserializeObject<DataSet>(result.re);
                    if (result.ErrorCode == "1")
                    {
                        Common.ErrorLog(Type.Information, "ERFacilityDetails : InsertUpdateItem", JsonConvert.SerializeObject(arr), "Success", loginName, result.ExecutionContext, null, RequestType.Portal);
                    }
                    else
                    {
                        Common.ErrorLog(Type.Error, "ERFacilityDetails : InsertUpdateItem", JsonConvert.SerializeObject(arr), "failure", loginName, result.ExecutionContext, null, RequestType.Portal);
                    }
                }
            }
            catch (Exception ex)
            {

                Common.ErrorLog(Type.Error, "ERFacilityDetails : InsertUpdateItem", JsonConvert.SerializeObject(arr), "failure", loginName, executionContext, ex, RequestType.Portal);
            }

        }
    }
}