﻿using System;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Microsoft.SharePoint.Workflow;
using RCPCampus_VED.BusinessLayer;
using RCPCampus_VED.DTO;
using Newtonsoft.Json;

namespace RCPCampus_VED.ER.RCPERZoneMaster
{
    /// <summary>
    /// List Item Events
    /// </summary>
    public class RCPERZoneMaster : SPItemEventReceiver
    {
        /// <summary>
        /// An item was added.
        /// </summary>
        public override void ItemAdded(SPItemEventProperties properties)
        {
            base.ItemAdded(properties);
            InsertUpdateItem(properties);
        }




        /// <summary>
        /// An item was updated.
        /// </summary>
        public override void ItemUpdated(SPItemEventProperties properties)
        {
            base.ItemUpdated(properties);
            InsertUpdateItem(properties);
        }
        private void InsertUpdateItem(SPItemEventProperties properties)
        {
            Business BL = new Business();
            string[] arr = null;
            string executionContext = "";
            string loginName = string.Empty;
            executionContext = Guid.NewGuid().ToString();
            SPListItem item = properties.ListItem;
            loginName = item.Web.CurrentUser.LoginName.Split('\\')[1].ToString();

            try
            {
                string userName = Convert.ToString(item["ZonalHead"]);
                string title = item["Title"].ToString();
                if (string.IsNullOrEmpty(userName))
                {
                    properties.Status = SPEventReceiverStatus.CancelWithError;
                    properties.ErrorMessage = "Please provide Zone Head ID";
                }
                else if (string.IsNullOrEmpty(title))
                {
                    properties.Status = SPEventReceiverStatus.CancelWithError;
                    properties.ErrorMessage = "Please provide Zone Name.";
                }
                else
                {

                    SPFieldUser userField = (SPFieldUser)item.Fields.GetField("ZonalHead");
                    SPFieldUserValue userFieldValue = (SPFieldUserValue)userField.GetFieldValue(item["ZonalHead"].ToString());
                    SPUser user = userFieldValue.User;

                    arr = new string[5];
                    arr[0] = "ID=" + item["ID"].ToString();
                    arr[1] = "Title=" + item["Title"];
                    arr[2] = "ZonalHeadID=" + user.LoginName.ToString().Split('\\')[1].ToString();
                    arr[3] = "type=ZONE";//+ user.LoginName;
                    arr[4] = "UserId=" + loginName;
                    ServiceResult result = BL.GenericInsertUpdateMethod("usp_InsertUpdateMasterByType", executionContext, loginName, RequestType.Portal, arr);
                    // DataSet ds = JsonConvert.DeserializeObject<DataSet>(result.re);
                    if (result.ErrorCode == "1")
                    {
                        Common.ErrorLog(Type.Information, "ERZoneMaster : InsertUpdateItem", JsonConvert.SerializeObject(arr), "Success", loginName, result.ExecutionContext, null, RequestType.Portal);
                    }
                    else
                    {
                        Common.ErrorLog(Type.Error, "ERZoneMaster : InsertUpdateItem", JsonConvert.SerializeObject(arr), "failure", loginName, result.ExecutionContext, null, RequestType.Portal);
                    }
                }
            }
            catch (Exception ex)
            {

                Common.ErrorLog(Type.Error, "ERZoneMaster : InsertUpdateItem", JsonConvert.SerializeObject(arr), "failure", loginName, executionContext, ex, RequestType.Portal);
            }

        }

        /// <summary>
        /// An item is being added
        /// </summary>
        public override void ItemAdding(SPItemEventProperties properties)
        {
            base.ItemAdding(properties);
            SPListItem item = properties.ListItem;
            //  SPListItem item = properties.ListItem;
            //SPFieldUser userField = (SPFieldUser)item.Fields.GetField("ZonalHead");
            //string userFieldValue = userField.GetFieldValueAsText(item["ZonalHead"].ToString());
            //   SPUser user = userFieldValue.User;
            // string before = properties.BeforeProperties["ZonalHead"].ToString();
            string after = properties.AfterProperties["ZonalHead"].ToString();
            //  string loginName = item.Web.CurrentUser.LoginName.Split('\\')[1].ToString();
            //string userName = Convert.ToString(item["ZonalHead"]);
            //string title = item["Title"].ToString();
            if (string.IsNullOrEmpty(after))
            {
                properties.Status = SPEventReceiverStatus.CancelWithError;
                properties.ErrorMessage = "Please provide Zone Head ID";
                //properties.Cancel = true;
            }
            //else if (string.IsNullOrEmpty(title))
            //{
            //    properties.Status = SPEventReceiverStatus.CancelWithError;
            //    properties.ErrorMessage = "Please provide Zone Name.";
            //    properties.Cancel = true;
            //}
        }

        /// <summary>
        /// An item is being updated
        /// </summary>
        public override void ItemUpdating(SPItemEventProperties properties)
        {
            base.ItemUpdating(properties);
            SPListItem item = properties.ListItem;
            //SPFieldUser userField = (SPFieldUser)item.Fields.GetField("ZonalHead");
            //string userFieldValue = userField.GetFieldValueAsText(item["ZonalHead"].ToString());
            //   SPUser user = userFieldValue.User;
            // string before = properties.BeforeProperties["ZonalHead"].ToString();
            string after = properties.AfterProperties["ZonalHead"].ToString();
            //  string loginName = item.Web.CurrentUser.LoginName.Split('\\')[1].ToString();
            //string userName = Convert.ToString(item["ZonalHead"]);
            //string title = item["Title"].ToString();
            if (string.IsNullOrEmpty(after))
            {
                properties.Status = SPEventReceiverStatus.CancelWithError;
                properties.ErrorMessage = "Please provide Zone Head ID";
                //properties.Cancel = true;
            }
            //else if (string.IsNullOrEmpty(title))
            //{
            //    properties.Status = SPEventReceiverStatus.CancelWithError;
            //    properties.ErrorMessage = "Please provide Zone Name.";
            //    properties.Cancel = true;
            //}
        }


    }
}