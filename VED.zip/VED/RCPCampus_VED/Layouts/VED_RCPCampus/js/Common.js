﻿function GetParameterValues(param) {
    var url = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < url.length; i++) {
        var urlparam = url[i].split('=');
        if (urlparam[0] == param) {
            return urlparam[1];
        }
    }
}


function GetImages(VEDID, facilityAreaID) {
    var URL = _spPageContextInfo.siteAbsoluteUrl + "/_LAYOUTS/15/VED_WebService/VED_WebService.asmx/GetImagesBasedOnVEDID"
    $.ajax({
        type: "POST",
        url: URL,
        data: "{ VEDID: '" + VEDID + "', FacilityDetailsID: '" + facilityAreaID + "', executionContext: '', loggedInUser: '', type: '" + 1 + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        async: false,
        success: function (r) {
            var imageHTML = "";
            $('#divForImages').html(imageHTML);
            //for (i = 0; i < r.d.Data.length; i++) {
            //    imageHTML += "<img style='height: 100px; width: 200px;' src='data:image/" + r.d.Data[i].ImageExtension + ";base64, " + r.d.Data[i].ImageContent + "'/>";
            //}
            imageHTML += "<div id='myCarousel' class='carousel slide' data-ride='carousel'>                                               "
            imageHTML += "    <ol class='carousel-indicators'>                                                                            "
            var isActiveDot = true;
            for (i = 0; i < r.d.Data.length; i++) {

                if (isActiveDot) {
                    imageHTML += "        <li data-target='#myCarousel' data-slide-to='" + i + "' class='active'></li>                                    "
                    isActiveDot = false;
                }
                else {
                    imageHTML += "        <li data-target='#myCarousel' data-slide-to='" + i + "' ></li>                                    "
                }



            }
            imageHTML += "    </ol>                                                                                                       "
            imageHTML += "                                                                                                                "
            imageHTML += "    <!-- Wrapper for slides -->                                                                                 "
            imageHTML += "    <div class='carousel-inner'>                                                                                "
            var isActiveSlide = true;
            for (i = 0; i < r.d.Data.length; i++) {

                if (isActiveSlide) {
                    imageHTML += "        <div class='item active'>   "
                    imageHTML += "<img class='height470'  src='data:image/" + r.d.Data[i].ImageExtension + ";base64, " + r.d.Data[i].ImageContent + "'/>"
                    imageHTML += "    </div> "
                    isActiveSlide = false;
                }
                else {
                    imageHTML += "        <div class='item '>   "
                    imageHTML += "<img  class='height470' src='data:image/" + r.d.Data[i].ImageExtension + ";base64, " + r.d.Data[i].ImageContent + "'/>"
                    imageHTML += "    </div> "
                }

            }
            imageHTML += "                                                                                                                "
            imageHTML += "    <!-- Left and right controls -->                                                                            "
            imageHTML += "    <a class='left carousel-control' href='#myCarousel' data-slide='prev'>                                      "
            imageHTML += "        <span class='glyphicon glyphicon-chevron-left'></span>                                                  "
            imageHTML += "        <span class='sr-only'>Previous</span>                                                                   "
            imageHTML += "    </a>                                                                                                        "
            imageHTML += "    <a class='right carousel-control' href='#myCarousel' data-slide='next'>                                     "
            imageHTML += "        <span class='glyphicon glyphicon-chevron-right'></span>                                                 "
            imageHTML += "        <span class='sr-only'>Next</span>                                                                       "
            imageHTML += "    </a>                                                                                                        "
            imageHTML += "</div>                                                                                                          "
            //alert(imageHTML);
            //divForImages
            $('#divForImages').html(imageHTML);

            $('#myModal').modal('show');
            $('.carousel').carousel({
                interval: 2000
            })

            //$('#photo-id1').attr("src", "data:image/" + r.d.Data[0].ImageExtension + ";base64," + r.d.Data[0].ImageContent + "")

            //$('#photo-id').attr("src", "data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAAAUAAAAFCAYAAACNbyblAAAAHElEQVQI12P4//8/w38GIAXDIBKE0DH")


            //<img src="data:image/png;base64, iVBORw0KGgoAAAANSUhEUgAAAAUA
            //AAAFCAYAAACNbyblAAAAHElEQVQI12P4//8/w38GIAXDIBKE0DH

            // $('#photo-id').attr("src", "data:image/png;base64, aVZCT1J3MEtHZ29BQUFBTlNVaEVVZ0FBQUFVQUFBQUZDQVlBQUFDTmJ5YmxBQUFBSEVsRVFWUUkxMlA0")

            //  "data: image / png; base64, aVZCT1J3MEtHZ29BQUFBTlNVaEVVZ0FBQUFVQUFBQUZDQVlBQUFDTmJ5YmxBQUFBSEVsRVFWUUkxMlA0""

            // "data:image/jpeg;base64,{{data.UserPhoto}}"
        },
        error: function (r) {
            alert(r.responseText);
        },
        failure: function (r) {
            alert(r.responseText);
        }
    });


    //function handleHtml(data, status) {
    //    for (var count in data.d) {
    //        alert(data.d[count].Author);
    //        alert(data.d[count].BookName);
    //    }
    //}

    //function ajaxFailed(xmlRequest) {
    //    alert(xmlRequest.status + ' \n\r ' + 
    //          xmlRequest.statusText + '\n\r' + 
    //          xmlRequest.responseText);
    //}
    // return false;

}

function GetParameterValues(param) {
    var url = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
    for (var i = 0; i < url.length; i++) {
        var urlparam = url[i].split('=');
        if (urlparam[0] == param) {
            return urlparam[1];
        }
    }
}
$(document).ready(function () {
    $(".datepickerClass").datepicker({
        dateFormat: "dd-M-yy"
        //TODO:Undo for it live
        , minDate: 0
        //  , maxDate: GetMaxDate()
    });
    $('.datepickerClass').keyup(function () {
        $(this).val('');
        alert('Please select date from Calendar');
    });

    $('.lnlViewImages').each(function () {
        // alert('Hello');
        $(this).click(function () {
            var VEDID = $(this).attr('data-VEDID');
            var facilityID = $(this).attr('data-FacilityID');
            // alert("VEDID " + VEDID + " facilityID" + facilityID);
            GetImages(VEDID, facilityID)
            return false;
        });
    });

    function GetMinDate() {

        var currentDate = new Date()
        var currentDay = currentDate.getUTCDate();
        var currentMonthLastDay = new Date(currentDate.getUTCFullYear(), currentDate.getMonth() + 1, 0);
        if (currentDay >= 25 && currentDay <= currentMonthLastDay.getUTCDate()) {
            return new Date(currentDate.getUTCFullYear(), currentDate.getUTCMonth() + 1, currentDay)
        }
        else {
            return new Date(currentDate.getUTCFullYear(), currentDate.getUTCMonth(), currentDay)
        }
    }

    function GetMaxDate() {

        //var currentDate = new Date();
        var currentDate = new Date();
        var currentDay = currentDate.getUTCDate();
        var currentMonthLastDay = new Date(currentDate.getUTCFullYear(), currentDate.getUTCMonth() + 1, 0);
        if (currentDay >= 25 && currentDay <= currentMonthLastDay.getUTCDate()) {
            return new Date(currentDate.getUTCFullYear(), currentDate.getUTCMonth() + 2, 0)
        }
        else {
            return new Date(currentDate.getUTCFullYear(), currentDate.getUTCMonth() + 1, 0)
        }
    }
});
