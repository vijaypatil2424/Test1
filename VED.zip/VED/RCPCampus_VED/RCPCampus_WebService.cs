﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Services;
using System.Web.Script.Services;
using System.Web;
using Newtonsoft.Json;
using RCPCampus_VED.BusinessLayer;
using RCPCampus_VED.DTO;

namespace RCPCampus_VED
{
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [ScriptService()]
   public class RCPCampus_WebService: WebService
   {

       Business business = new Business();
       #region VED Schedule
       [WebMethod]
       [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
       public void GetAllCentersByUserID(string userName, string executionContext = "", string loggedInUser = "")
       {
           HttpContext context = HttpContext.Current;
           context.Response.Clear();
           context.Response.ContentType = "application/json";
           context.Response.Write(JsonConvert.SerializeObject(business.GetAllCentersByUserID(userName, executionContext, loggedInUser, "1")));
       }
       [WebMethod]
       [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
       public void GetCenterDetailsByID(string centerID, string executionContext = "", string loggedInUser = "")
       {
           HttpContext context = HttpContext.Current;
           context.Response.Clear();
           context.Response.ContentType = "application/json";
           context.Response.Write(JsonConvert.SerializeObject(business.GetCenterDetailsByID(centerID, executionContext, loggedInUser)));
       }

       [WebMethod]
       [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
       public void GetAllScheduleForCurrentMonth(string userName, string executionContext = "", string loggedInUser = "")
       {
           HttpContext context = HttpContext.Current;
           context.Response.Clear();
           context.Response.ContentType = "application/json";
           context.Response.Write(JsonConvert.SerializeObject(business.GetAllScheduleForCurrentMonth(userName, executionContext, loggedInUser, "1")));
       }

       [WebMethod]
       [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
       public void AddVEDSchedule(string vedID, string officeID, string scheduledOn, string comments, string executionContext = "", string loggedInUser = "")
       {
           HttpContext context = HttpContext.Current;
           context.Response.Clear();
           context.Response.ContentType = "application/json";
           context.Response.Write(JsonConvert.SerializeObject(business.AddVEDSchedule(vedID, officeID, scheduledOn, comments, executionContext, loggedInUser)));
       }

       [WebMethod]
       [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
       public void GetScheduledVEDDetailsByID(string VEDID, string executionContext = "", string loggedInUser = "")
       {
           HttpContext context = HttpContext.Current;
           context.Response.Clear();
           context.Response.ContentType = "application/json";
           context.Response.Write(JsonConvert.SerializeObject(business.GetScheduledVEDDetailsByID(VEDID, executionContext, loggedInUser)));
       }

       [WebMethod]
       [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
       public void GetScheduleHistoryOfCenter(string centerID, string count, string executionContext = "", string loggedInUser = "")
       {
           HttpContext context = HttpContext.Current;
           context.Response.Clear();
           context.Response.ContentType = "application/json";
           context.Response.Write(JsonConvert.SerializeObject(business.GetScheduleHistoryOfCenter(centerID, count, executionContext, loggedInUser)));
       }

       [WebMethod]
       [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
       public void GetManagerLevelScheduleData(string userID, string typeOfLevel, string executionContext = "", string loggedInUser = "")
       {
           HttpContext context = HttpContext.Current;
           context.Response.Clear();
           context.Response.ContentType = "application/json";
           context.Response.Write(JsonConvert.SerializeObject(business.GetManagerLevelScheduleData(userID, typeOfLevel, executionContext, loggedInUser, "1")));
       }
       #endregion

       #region AssessmentDetails
       [WebMethod]
       [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
       public void GetFaciltyAreaDetailsMasters(string centerTypeID, string VEDScheduleID, string executionContext = "", string loggedInUser = "")
       {
           HttpContext context = HttpContext.Current;
           context.Response.Clear();
           context.Response.ContentType = "application/json";
           context.Response.Write(JsonConvert.SerializeObject(business.GetFaciltyAreaDetailsMasters(centerTypeID, VEDScheduleID, executionContext, loggedInUser)));

       }

       [WebMethod]
       [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
       public void SaveAsessmentDetails(List<AssesstmentDetails> assesmentData, string executionContext = "", string loggedInUser = "")
       {
           HttpContext context = HttpContext.Current;
           context.Response.Clear();
           context.Response.ContentType = "application/json";
           context.Response.Write(JsonConvert.SerializeObject(business.SaveAsessmentDetails(assesmentData, executionContext, loggedInUser)));
       }

       [WebMethod]
       [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
       public void UploadAssessmentImages(List<Image> imagesData, string executionContext, string loggedInUser)
       {
           HttpContext context = HttpContext.Current;
           context.Response.Clear();
           context.Response.ContentType = "application/json";
           context.Response.Write(JsonConvert.SerializeObject(business.UploadAssessmentImages(imagesData, executionContext, loggedInUser)));
       }


       [WebMethod]
       [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
       public void GetAssessmentDetails(string VEDScheduleID, string executionContext, string loggedInUser)
       {
           HttpContext context = HttpContext.Current;
           context.Response.Clear();
           context.Response.ContentType = "application/json";
           context.Response.Write(JsonConvert.SerializeObject(business.GetAssessmentDetails(VEDScheduleID, executionContext, loggedInUser)));
       }

       [WebMethod]
       [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
       public ServiceResult<List<Image>> GetImagesBasedOnVEDID(string VEDID, string FacilityDetailsID, string executionContext, string loggedInUser, RequestType type = RequestType.Mobile)
       {
           //HttpContext context = HttpContext.Current;
           //context.Response.Clear();
           //context.Response.ContentType = "application/json";
           return business.GetImagesBasedOnVEDID(VEDID, FacilityDetailsID, executionContext, loggedInUser);
       }


       [WebMethod]
       [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
       public ServiceResult LoginLogOut(string executionContext, string loggedInUser, string loginType = "LogOut", RequestType type = RequestType.Mobile)
       {
           //HttpContext context = HttpContext.Current;
           //context.Response.Clear();
           //context.Response.ContentType = "application/json";
           return business.LoginLogOut(executionContext, loggedInUser, loginType, type);
       }



       #endregion
   }
    
}
