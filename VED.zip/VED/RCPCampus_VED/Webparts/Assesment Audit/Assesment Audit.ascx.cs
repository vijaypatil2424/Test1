﻿using System;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using RCPCampus_VED.BusinessLayer;
using RCPCampus_VED.DTO;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using Microsoft.SharePoint;
using Newtonsoft.Json;
using System.Configuration;
using Microsoft.SharePoint.Utilities;
using System.Net.Mail;

namespace RCPCampus_VED.Webparts.Assesment_Audit
{
    [ToolboxItemAttribute(false)]
    public partial class Assesment_Audit : WebPart
    {
        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]

        Business BL = null;
        string executionContext = "";

        string loginName = string.Empty;
        public Assesment_Audit()
        {
            BL = new Business();
            executionContext = Guid.NewGuid().ToString();
            loginName = SPContext.Current.Web.CurrentUser.LoginName.Split('\\')[1].ToString();
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            lblError.Text = string.Empty;
            //TODO : To check if Page load is perform , to hide the SAVE button

            try
            {
                string officeTypeID = string.Empty, scheduleID = string.Empty;
                if (!Page.IsPostBack)
                {
                    hdnType.Value = "1";
                    if (HttpContext.Current.Request.QueryString["VEDID"] != null && HttpContext.Current.Request.QueryString["VEDID"].ToString() != string.Empty)
                    {

                        scheduleID = Convert.ToString(HttpContext.Current.Request.QueryString["vedid"]);
                        //string officeType = Convert.ToString(HttpContext.Current.Request.QueryString["Type"]);
                        ServiceResult<VEDSchedule> scheduleDetail = BL.GetScheduledVEDDetailsByID(scheduleID, executionContext, loginName, RequestType.Portal);
                        lblScheduleDate.Text = scheduleDetail.Data.ScheduledOn;
                        officeTypeID = scheduleDetail.Data.OfficeTypeID.ToString();
                        lblActualDate.Text = string.IsNullOrEmpty(scheduleDetail.Data.ActualAssesstmentDate) ? DateTime.Now.ToString("dd-MMM-yyyy") : scheduleDetail.Data.ActualAssesstmentDate;
                        lblCenter.Text = scheduleDetail.Data.Center;
                        executionContext = scheduleDetail.ExecutionContext;
                        ServiceResult<FinalAssessmentData> result = BL.GetAssessmentDetails_Audit(HttpContext.Current.Request.QueryString["vedid"].ToString(), "", "", RequestType.Portal);
                        if (result.Data.AssesstmentDetails.Count > 0)
                        {
                            grdCentersDetails.DataSource = result.Data.VEDFinalData;
                            grdCentersDetails.DataBind();

                            readOnlyDIV.Visible = true;
                            grdAuditAssessment.DataSource = result.Data.AssesstmentDetails;
                            grdAuditAssessment.DataBind();
                            exportToExcel.Visible = false;

                        }
                        else
                        {
                            lblError.Text = "Oops Something went wrong!. No data found.";

                        }
                    }
                    else if (HttpContext.Current.Request.QueryString["AuditID"] != null && HttpContext.Current.Request.QueryString["AuditID"].ToString() != string.Empty)
                    {

                        ServiceResult<FinalAssessmentData> result = BL.GetAssessmentDetailsForView_Audit(HttpContext.Current.Request.QueryString["AuditID"].ToString(), "", "", RequestType.Portal);
                        if (result.Data.AssesstmentDetails.Count > 0)
                        {



                            scheduleID = result.Data.AssesstmentDetails.FirstOrDefault().VEDScheduleID.ToString();
                            ServiceResult<VEDSchedule> scheduleDetail = BL.GetScheduledVEDDetailsByID(scheduleID, executionContext, loginName, RequestType.Portal);
                            lblScheduleDate.Text = scheduleDetail.Data.ScheduledOn;
                            officeTypeID = scheduleDetail.Data.OfficeTypeID.ToString();
                            lblActualDate.Text = string.IsNullOrEmpty(scheduleDetail.Data.ActualAssesstmentDate) ? DateTime.Now.ToString("dd-MMM-yyyy") : scheduleDetail.Data.ActualAssesstmentDate;
                            lblCenter.Text = scheduleDetail.Data.Center;
                            executionContext = scheduleDetail.ExecutionContext;

                            buttonDiv.Visible = false;
                            grdCentersDetails.DataSource = result.Data.VEDFinalData;
                            grdCentersDetails.DataBind();

                            readOnlyDIV.Visible = false;
                            grdViewAudits.DataSource = result.Data.AssesstmentDetails;
                            grdViewAudits.DataBind();

                        }
                        else
                        {
                            lblError.Text = "Oops Something went wrong. No data found.";

                        }
                    }
                    else
                    {
                        lblError.Text = "Oops Something went wrong No ID found. Error Code : " + executionContext;
                        Common.ErrorLog(Type.Information, "Assesment_Audit : Page_Load", "", "No VEDID Found", loginName, executionContext, null, RequestType.Portal);
                    }

                }
            }
            catch (Exception ex)
            {

                Common.ErrorLog(Type.Error, "Assesment_Audit : Page_Load", "", "", loginName, executionContext, ex, RequestType.Portal);
            }
        }
        protected void grdAuditAssessment_RowDataBound(object sender, GridViewRowEventArgs e)
        {

            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                bool isImageAvailable = Convert.ToBoolean(e.Row.Cells[8].Text);

                if (!isImageAvailable)
                {
                    LinkButton lnk = (LinkButton)e.Row.FindControl("lnkViewImage");
                    lnk.Visible = false;
                }
            }
        }

        protected void grdViewAudits_RowDataBound(object sender, GridViewRowEventArgs e)
        {

            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                bool isImageAvailable = Convert.ToBoolean(e.Row.Cells[7].Text);

                if (!isImageAvailable)
                {
                    LinkButton lnk = (LinkButton)e.Row.FindControl("lnkViewImage");
                    lnk.Visible = false;
                }
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            hdnType.Value = "2";
            string request = "VEDID : " + HttpContext.Current.Request.QueryString["VEDID"].ToString();
            ServiceResult<VEDScore> results = null;
            try
            {
                if (HttpContext.Current.Request.QueryString["VEDID"].ToString() != string.Empty)
                {
                    List<AssesstmentDetails> details = new List<AssesstmentDetails>();
                    foreach (GridViewRow row in grdAuditAssessment.Rows)
                    {
                        AssesstmentDetails detail = new AssesstmentDetails();
                        detail.VEDScheduleID = Convert.ToInt32(HttpContext.Current.Request.QueryString["vedid"]); //Need to Get the same from  Query String                  
                        detail.AssessmentDoneBy = loginName;
                        detail.FacilityAreaID = Convert.ToInt32(((Label)row.FindControl("lblFacilityAreaID")).Text);
                        detail.FacilityDetailsID = Convert.ToInt32(((Label)row.FindControl("lblFacilityDetailsID")).Text);
                        detail.Condition = Convert.ToString(((Label)row.FindControl("lblCondition")).Text);
                        detail.Comments = Convert.ToString(((Label)row.FindControl("lblComments")).Text);
                        detail.CriticalityID = Convert.ToInt32(((Label)row.FindControl("lblCriticalityID")).Text);
                        detail.AuditorCondition = ((DropDownList)row.FindControl("ddlCondition")).SelectedValue;
                        detail.AuditorComment = ((TextBox)row.FindControl("txtAuditComments")).Text.Trim();
                        details.Add(detail);
                    }

                    results = BL.SaveAsessmentDetails_Web_Audit(details, executionContext, loginName, RequestType.Portal, AssessmentType.AreaLevel);
                    if (results.ErrorCode == "1")
                    {
                        lblError.Text = "VED Audit details updated successfully.";
                        buttonDiv.Visible = false;
                        viewAudits.Visible = false;
                        readOnlyDIV.Visible = false;
                        vedScoreAssessmentDiv.Visible = false;
                        backDiv.Visible = true;

                    }
                    else
                    {
                        lblError.Text = results.ErrorMessage + " Error Code : " + results.ExecutionContext;
                    }
                }
            }
            catch (Exception ex)
            {
                lblError.Text = "Oops Something went wrong!. Error Code : " + executionContext;
                Common.ErrorLog(Type.Error, "Assesment_Audit : btnSave_Click", request, JsonConvert.SerializeObject(results), loginName, executionContext, ex, RequestType.Portal);
            }
            Page.Session.Clear();
        }

        protected void grdAuditAssessment_DataBound(object sender, EventArgs e)
        {
            for (int i = grdAuditAssessment.Rows.Count - 1; i > 0; i--)
            {
                GridViewRow row1 = grdAuditAssessment.Rows[i];
                GridViewRow previousRow = grdAuditAssessment.Rows[i - 1];
                //for (int j = 0; j < row.Cells.Count; j++)
                //{
                int j = 3;
                if (row1.Cells[3].Text == previousRow.Cells[3].Text)
                {
                    if (previousRow.Cells[j].RowSpan == 0)
                    {
                        if (row1.Cells[j].RowSpan == 0)
                        {
                            previousRow.Cells[j].RowSpan += 2;
                        }
                        else
                        {
                            previousRow.Cells[j].RowSpan = row1.Cells[j].RowSpan + 1;
                        }
                        row1.Cells[j].Visible = false;
                    }
                }
                //}
            }
        }

        protected void grdViewAudits_DataBound(object sender, EventArgs e)
        {
            for (int i = grdViewAudits.Rows.Count - 1; i > 0; i--)
            {
                GridViewRow row1 = grdViewAudits.Rows[i];
                GridViewRow previousRow = grdViewAudits.Rows[i - 1];
                //for (int j = 0; j < row.Cells.Count; j++)
                //{
                int j = 0;
                if (row1.Cells[0].Text == previousRow.Cells[0].Text)
                {
                    if (previousRow.Cells[j].RowSpan == 0)
                    {
                        if (row1.Cells[j].RowSpan == 0)
                        {
                            previousRow.Cells[j].RowSpan += 2;
                        }
                        else
                        {
                            previousRow.Cells[j].RowSpan = row1.Cells[j].RowSpan + 1;
                        }
                        row1.Cells[j].Visible = false;
                    }
                }
                //}
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            //Page.Response.Redirect("/sites/rcs/jcved/pages/Create-schedule.aspx", true);
            Page.Response.Redirect(SPUrlUtility.CombineUrl(SPContext.Current.Web.Url, "Pages/VedAuditScheduleManagement.aspx"), true);
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {

            Page.Response.Redirect(SPUrlUtility.CombineUrl(SPContext.Current.Web.Url, "Pages/VedAuditScheduleManagement.aspx"), true);
        }

        protected void grdViewAudits_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdViewAudits.PageIndex = e.NewPageIndex;

        }

        protected void btnExportToExcel_Click(object sender, EventArgs e)
        {
            string[] arr = null;
            arr = new string[1];
            arr[0] = "AuditID=" + HttpContext.Current.Request.QueryString["AuditID"].ToString();
            ServiceResult<Generic> results = BL.GenericMethod("usp_Audit_GetAssessmentDetailsofAuditorForView", executionContext, loginName, RequestType.Portal, arr);
            DataSet ds = JsonConvert.DeserializeObject<DataSet>(results.Data.ResultData);
            //usp_Report_GetImages
            DataTable dt = ds.Tables[0];
            DataTable dt1 = ds.Tables[1];
            string strHtmlTable = "";

            strHtmlTable = "<Table border='1' bgColor='#ffffff' " +
              "borderColor='#000000' cellSpacing='0' cellPadding='0' " +
              "style='font-size:10.0pt; font-family:Calibri; background:white;'>";
            strHtmlTable += "<tr><th>FacilityArea</th><th>FaciltyDetails</th><th>Criticality</th><th>Condition</th><th>Comments</th><th>Images</th><th>AuditCondition</th><th>AuditComments</th></tr>";
            string siteURL = Convert.ToString(ConfigurationManager.AppSettings["siteURL"]);
            foreach (DataRow row in dt.Rows)
            {
                strHtmlTable += "<tr>";
                for (int i = 0; i < dt.Columns.Count; i++)
                {

                    if (i == 5)
                    {
                        strHtmlTable += "<td>";
                        bool isImageAvailable = Convert.ToBoolean(row[i]);
                        if (isImageAvailable)
                        {
                            strHtmlTable += "<a href=" + SPContext.Current.Web.Url + "/Pages/view-images.aspx?VEDID=" + row[6].ToString() + "&facilityAreaID=" + row[8].ToString() + ">ViewImages</a>";//
                        }
                        else
                        {
                            strHtmlTable += "No Images";
                        }
                        strHtmlTable += "</td>";
                    }
                    else if (i == 3)
                    {
                        strHtmlTable += "<td>";
                        string condition = Convert.ToString(row[i]);
                        if (condition.ToUpper() == "POOR")
                        {
                            strHtmlTable += "<a href=" + SPContext.Current.Web.Url + "/pages/Poor-Assessment.aspx?VEDID=" + row[6].ToString() + ">" + condition + "</a>";//
                        }
                        else
                        {
                            strHtmlTable += row[i].ToString();
                        }
                        strHtmlTable += "</td>";
                    }
                    else if (i == 6 || i == 7 || i == 8 || i == 9 || i == 10)
                    {
                        continue;
                    }
                    else
                    {
                        strHtmlTable += "<td>";
                        strHtmlTable += row[i].ToString();
                        strHtmlTable += "</td>";
                    }
                }
            }

            strHtmlTable += "</tr>";
            //strHtmlTable += "<tr><td><a href='http://sp13devwfe01:19999/_LAYOUTS/15/VEDHandler/image.ashx?ID=14'>ViewImages</a></td></tr>";
            strHtmlTable += "</table>";
            strHtmlTable += "<BR><BR><BR>";
            strHtmlTable += "<Table border='1' bgColor='#ffffff' " +
         "borderColor='#000000' cellSpacing='0' cellPadding='0' " +
         "style='font-size:10.0pt; font-family:Calibri; background:white;'>";

            strHtmlTable += "<tr><th>ScheduledOn</th><th>ScheduledBy</th><th>ActualAssesstmentDate</th><th>Auditing Date</th><th>Auditing By</th><th>Center</th><th>Zone</th>";
            strHtmlTable += "<th>City</th><th>OfficeType</th><th>VitalCount</th><th>EssentialCount</th>";
            strHtmlTable += "<th>DesirableCount</th><th>VitalNotApplicable</th><th>EssentialNotApplicable</th><th>DesirableNotApplicable</th><th>TotalVEDByType</th><th>VEDScore</th>";
            strHtmlTable += "<th>MAXVEDScore</th><th>VEDPerScore</th></tr>";

            foreach (DataRow row in dt1.Rows)
            {//write in new row
                strHtmlTable += "<tr>";
                for (int i = 0; i < dt1.Columns.Count; i++)
                {
                    strHtmlTable += "<td>";
                    strHtmlTable += row[i].ToString();
                    strHtmlTable += "</td>";
                }
            }
            strHtmlTable += "</tr>";
            //strHtmlTable += "<tr><td><a href='http://sp13devwfe01:19999/_LAYOUTS/15/VEDHandler/image.ashx?ID=14'>ViewImages</a></td></tr>";
            strHtmlTable += "</table>";
            string centerName = "JCVEDReport";
            if (dt1.Rows.Count > 0)
            {
                DataRow row1 = dt1.Rows[0];
                centerName = row1["Center"].ToString();
            }
            string fileName = centerName + "_" + DateTime.Now.Day + "_" + DateTime.Now.Month + "_" + DateTime.Now.Year + ".xls";
            this.Page.Response.AppendHeader("content-disposition", "attachment;filename=" + fileName + "");
            this.Page.Response.Charset = "";
            this.Page.Response.Cache.SetCacheability(HttpCacheability.NoCache);
            this.Page.Response.ContentType = "application/vnd.ms-excel";
            this.EnableViewState = false;
            this.Page.Response.Write(strHtmlTable);
            this.Page.Response.End();

        }
    }
}
