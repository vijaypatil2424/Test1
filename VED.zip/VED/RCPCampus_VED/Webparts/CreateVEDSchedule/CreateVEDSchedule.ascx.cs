﻿using System;
using System.ComponentModel;
using System.Web.UI.WebControls.WebParts;
using System.Collections.Generic;
using Microsoft.SharePoint;
using RCPCampus_VED.BusinessLayer;
using RCPCampus_VED.DTO;
using System.Web.UI.WebControls;
using Newtonsoft.Json;
using System.Data;
using System.Web.UI;
using System.Configuration;
using Microsoft.SharePoint.Utilities;
using System.Web.UI.HtmlControls;

namespace RCPCampus_VED.Webparts.CreateVEDSchedule
{
    [ToolboxItemAttribute(false)]
    public partial class CreateVEDSchedule : WebPart
    {
        Business BL = null;
        string executionContext = "";
        string loginName = string.Empty;
        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]
        public CreateVEDSchedule()
        {
            BL = new Business();
            executionContext = Guid.NewGuid().ToString();
            loginName = SPContext.Current.Web.CurrentUser.LoginName.Split('\\')[1].ToString();
        }
       

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
                        if (!Page.IsPostBack)
            {
                try
                {
                    BindOfficeType();

                    //lblError.Text = rdbuttonlist.SelectedItem.Text;
                    divComment.Visible = false;
                    BindCenterDropDown();
                    BindVEDScheduled();
                    BindPreviouScheduledByUserID(loginName);
                    detailsDIV.Visible = false;
                    //Disable the  Save button if , we are between 6 and 24 of the month

                    //TODO:Undo it for Live
                    if (!string.IsNullOrEmpty(ConfigurationManager.AppSettings["isAllowed"].ToString()))
                    {
                        int currentDay = DateTime.Now.Day;
                        if (currentDay >= 6 && currentDay <= 24)
                        {
                            btnSubmit.Enabled = false;
                            txtScheduleDate.Enabled = false;
                            ddlCenters.Enabled = false;
                            lblError.Text = "Assessment scheduling is only allowed between 25th and 5th of respective month";
                        }
                    }
                }
                catch (Exception ex)
                {
                    Common.ErrorLog(Type.Error, "CreateVEDSchedule : Page_Load", "", "", loginName, executionContext, ex, RequestType.Portal);
                }
            }
        }


        private void BindOfficeType()
        {
            ServiceResult<Generic> results = BL.GetOfficeType("usp_GetOfficeType");
            if (results.Data.ResultData != string.Empty)
            {
                DataSet ds = JsonConvert.DeserializeObject<DataSet>(results.Data.ResultData);

                rdbuttonlist.DataSource = ds.Tables[0];
                rdbuttonlist.DataTextField = "Title";
                rdbuttonlist.DataValueField = "ID";
                rdbuttonlist.DataBind();
                // string firstIteam=Convert.ToString(rdbuttonlist.SelectedIndex= 0);

                //rdbuttonlist.Items.FindByText("JC").Selected = true;
                rdbuttonlist.Items.FindByText(ds.Tables[0].Rows[0]["Title"].ToString()).Selected = true;

            }
        }
        private void BindPreviouScheduledByUserID(string loginName)
        {

            try
            {
                string officeType = rdbuttonlist.SelectedItem.Value;
                string[] arr = new string[4];
                arr[0] = "count=100";
                arr[1] = "UserID=" + loginName + "";
                arr[2] = "Type=1";
                arr[3] = "OfficeType=" + officeType + "";
                ServiceResult<Generic> data = BL.GenericMethod("usp_GetTheScheduleHistoryOfCenterByUserID", executionContext, loginName, RequestType.Portal, arr);
                DataSet result = JsonConvert.DeserializeObject<DataSet>(data.Data.ResultData);
                if (result.Tables.Count > 0)
                {
                    grdPreviousSchedules.DataSource = result.Tables[0];
                    result.Tables[0].Columns.Add(new DataColumn("URL"));
                    foreach (DataRow dr in result.Tables[0].Rows)
                    {
                        string VedId = dr["VEDID"].ToString();
                        string uRL = SPUrlUtility.CombineUrl(SPContext.Current.Web.Url, "/pages/Assessment.aspx?VEDID=" + VedId + "");
                        dr["URL"] = uRL;
                    }

                    grdPreviousSchedules.DataBind();
                }
            }
            catch (Exception ex)
            {
                Common.ErrorLog(Type.Error, "CreateVEDSchedule : BindPreviouScheduledByUserID", "", "", loginName, executionContext, ex, RequestType.Portal);
            }

            // var finalData = JsonConvert.DeserializeObject <VEDFinalData>(data.Data.ResultData);

        }
        private void BindVEDScheduled(bool isRebind = false)
        {
            string request = "isRebind : " + isRebind.ToString();
            try
            {
                string officeType = rdbuttonlist.SelectedItem.Value;
                ServiceResult<List<VEDSchedule>> results = BL.GetAllScheduleForCurrentMonth(loginName, executionContext, loginName, officeType, RequestType.Portal);
                grdCentersDetails.DataSource = null;
                grdCentersDetails.DataBind();
                //grdCentersDetails.PageIndex = 0;
                grdCentersDetails.DataSource = results.Data;
                if (isRebind) { grdCentersDetails.PageIndex = 0; }
                grdCentersDetails.DataBind();
                executionContext = results.ExecutionContext;
                //
                //grdCentersDetails.SetPageIndex(0);
            }
            catch (Exception ex)
            {
                Common.ErrorLog(Type.Error, "CreateVEDSchedule : BindVEDScheduled", request, "", loginName, executionContext, ex, RequestType.Portal);
            }
        }

        private void BindCenterDropDown()
        {
            string request = "loginName : " + loginName;
            try
            {
                string officeType = rdbuttonlist.SelectedItem.Value;
                ServiceResult<List<CommonDDL>> results = BL.GetAllCentersByUserID(loginName, executionContext, loginName, officeType, RequestType.Portal);
                if (results.ErrorCode == "1")
                {
                    ddlCenters.DataSource = results.Data;
                    ddlCenters.DataTextField = "Title";
                    ddlCenters.DataValueField = "ID";
                    ddlCenters.DataBind();
                    ddlCenters.Items.Insert(0, new ListItem("Select Center", "0"));
                    executionContext = results.ExecutionContext;
                }
                else
                {
                    ddlCenters.Items.Clear();
                    ddlCenters.DataSource = null;
                    //ddlCenters.DataTextField = "Title";
                    //ddlCenters.DataValueField = "ID";
                    ddlCenters.DataBind();
                    ddlCenters.Items.Insert(0, new ListItem("Select Center", "0"));
                    lblError.Text = results.ErrorMessage + "Error code : " + executionContext;
                }
            }
            catch (Exception ex)
            {
                Common.ErrorLog(Type.Error, "CreateVEDSchedule : BindCenterDropDown", request, "", loginName, executionContext, ex, RequestType.Portal);
            }
        }

        private void ClearControls()
        {
            lblOfficeArea.Text = string.Empty;
            lblOfficeCSPerson.Text = string.Empty;
            lblOfficeAddress.Text = string.Empty;
            lblOfficeType.Text = string.Empty;
            // lblActualDate.Text = string.Empty;
            lblCity.Text = string.Empty;
            lblOfficeArea.Text = string.Empty;
            //lblScheduleDate.Text = string.Empty;
            txtScheduleDate.Text = string.Empty;
            //lblZone.Text = string.Empty;
            txtComments.Text = string.Empty;
            txtComments.Visible = false;

            ddlCenters.Enabled = true;
            ddlCenters.ClearSelection();
            //ddlCenters.SelectedValue = 0;
            ddlCenters.Items.FindByValue("0").Selected = true;
            BindVEDScheduled(true);
            btnSubmit.Text = "Submit";
            detailsDIV.Visible = false;
            divButtons.Visible = false;
            lblError.Text = string.Empty;

        }

        private void GetVEDScheduledData(int VEDId)
        {
            string request = "VEDId : " + VEDId;
            try
            {
                ViewState["currentItem"] = string.Empty;
                ServiceResult<VEDSchedule> data = BL.GetScheduledVEDDetailsByID(VEDId.ToString(), executionContext, loginName, RequestType.Portal);
                executionContext = data.ExecutionContext;
                lblCity.Text = data.Data.City;
                lblOfficeAddress.Text = data.Data.Address;
                //lblOfficeCSPerson.Text = data.Data.OfficeAdmins;
                string officeadmin = data.Data.OfficeAdmins;
                string[] arr = officeadmin.Split(';');
                for (int i = 0; i < arr.Length; i++)
                {

                    HtmlGenericControl li = new HtmlGenericControl("li");
                    li.InnerHtml = Convert.ToString(arr[i]);

                    ulofficecsperson.Controls.Add(li);

                }
                lblOfficeType.Text = data.Data.OfficeType;
                // lblZone.Text = data.Data.Zone;
                lblOfficeArea.Text = data.Data.CarpetArea;
                txtScheduleDate.Text = data.Data.ScheduledOn;
                ddlCenters.ClearSelection();
                ddlCenters.Items.FindByValue(data.Data.OfficeID).Selected = true;
                ddlCenters.Enabled = false;
                ViewState["currentItem"] = VEDId;
                txtComments.Visible = true;
                txtComments.Text = string.Empty;
                lblComments.Visible = true;
                lblError.Text = string.Empty;
                detailsDIV.Visible = true;
                divButtons.Visible = true;
                lblZone.Text = data.Data.Zone;
                lblArea.Text = data.Data.Area;
            }
            catch (Exception ex)
            {
                Common.ErrorLog(Type.Error, "CreateVEDSchedule : GetVEDScheduledData", request, "", loginName, executionContext, ex, RequestType.Portal);
            }

        }

        protected void EditSchedule(object sender, EventArgs e)
        {
            int ID = 0;
            try
            {
                divComment.Visible = true;
                btnSubmit.Text = "Update";
                GridViewRow row = (sender as LinkButton).NamingContainer as GridViewRow;
                ID = Convert.ToInt32(grdCentersDetails.Rows[row.RowIndex].Cells[6].Text);
                GetVEDScheduledData(ID);
            }
            catch (Exception ex)
            {
                Common.ErrorLog(Type.Error, "CreateVEDSchedule : EditSchedule", "ID : " + ID.ToString(), "", loginName, executionContext, ex, RequestType.Portal);
            }
        }

        protected void ddlCenters_SelectedIndexChanged(object sender, EventArgs e)
        {
            ServiceResult<Office> officeDetails = null;
            try
            {
                officeDetails = BL.GetCenterDetailsByID(ddlCenters.SelectedValue, executionContext, loginName, RequestType.Portal);
                if (officeDetails.ErrorCode == "1")
                {
                    if (officeDetails.Data != null)
                    {
                        lblCity.Text = officeDetails.Data.City;
                        lblArea.Text = officeDetails.Data.Area;
                        lblOfficeAddress.Text = officeDetails.Data.Address;
                        //lblOfficeCSPerson.Text = officeDetails.Data.OfficeAdmins;
                        string officeadmin = officeDetails.Data.OfficeAdmins;
                        string[] arr = officeadmin.Split(';');
                        for (int i = 0; i < arr.Length; i++)
                        {

                            HtmlGenericControl li = new HtmlGenericControl("li");
                            li.InnerHtml = Convert.ToString(arr[i]);

                            ulofficecsperson.Controls.Add(li);

                        }
                        //HtmlGenericControl li = new HtmlGenericControl("li");
                        //ulofficecsperson.Controls.Add(li);
                        //liofficecsperson.InnerText = officeDetails.Data.OfficeAdmins;
                        lblOfficeType.Text = officeDetails.Data.OfficeType;
                        //lblZone.Text = officeDetails.Data.Zone;
                        lblOfficeArea.Text = officeDetails.Data.CarpetArea;
                        lblZone.Text = officeDetails.Data.Zone;
                        btnSubmit.Text = "Submit";
                        txtComments.Visible = false;
                        lblError.Text = string.Empty;
                        detailsDIV.Visible = true;
                        divButtons.Visible = true;
                        lblComments.Visible = false;
                    }
                    else
                    {
                        lblError.Text = "No data found for the selected center";

                    }
                }
                else
                {
                    lblError.Text = officeDetails.ErrorMessage + " Error code : " + executionContext;
                }
            }
            catch (Exception ex)
            {
                Common.ErrorLog(Type.Error, "CreateVEDSchedule : ddlCenters_SelectedIndexChanged", "Request : " + ddlCenters.SelectedValue, JsonConvert.SerializeObject(officeDetails), loginName, executionContext, ex, RequestType.Portal);
            }

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            string request = "scheduleDate : " + txtScheduleDate.Text.Trim() + " ddlCenters.SelectedValue : " + ddlCenters.SelectedValue + "View State  : Current Item : " + ViewState["currentItem"] != null ? "NULL" : ViewState["currentItem"].ToString();
            ServiceResult result = null;
            try
            {
                string scheduleDate = txtScheduleDate.Text.Trim();
                if (ddlCenters.SelectedValue == "0")
                {
                    lblError.Text = "Please select the center";
                }
                else if (scheduleDate == string.Empty)
                {
                    lblError.Text = "Please select the date.";
                }
                else if (btnSubmit.Text.ToUpper() == "UPDATE" && txtComments.Text == string.Empty)
                {
                    lblError.Text = "Please provide Comments.";
                }
                else
                {

                    if (btnSubmit.Text.ToUpper() == "SUBMIT") { result = BL.AddVEDSchedule("", ddlCenters.SelectedValue, scheduleDate, "", executionContext, loginName, RequestType.Portal, AssessmentType.AreaLevel); }
                    else
                    {
                        result = BL.AddVEDSchedule(ViewState["currentItem"].ToString(), ddlCenters.SelectedValue, scheduleDate, txtComments.Text, executionContext, loginName, RequestType.Portal);
                    }

                    if (result.ErrorCode == "1")
                    {
                        lblError.Text = result.ErrorMessage;
                        ClearControls();
                        ScriptManager.RegisterStartupScript(this.Page, GetType(), "script", "alert('VED Scheduled created/updated successfully'); ", true);
                        //ScriptManager.RegisterStartupScript(this.Page, GetType(), "script", "alert('Attached File Name is same. Please try Another Name and Upload'); ", true);
                        // ddlCenters.SelectedIndex = 0;
                        //BindVEDScheduled();
                    }
                    else
                    {
                        lblError.Text = result.ErrorMessage + " Error Code : " + result.ExecutionContext;
                    }
                }
            }
            catch (Exception ex)
            {
                Common.ErrorLog(Type.Error, "CreateVEDSchedule : btnSubmit_Click", request, JsonConvert.SerializeObject(result), loginName, executionContext, ex, RequestType.Portal);
            }
        }

        protected void grdCentersDetails_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                DateTime scheduleDate = Convert.ToDateTime(((Label)e.Row.FindControl("lblScheduledOn")).Text);
                DateTime minus3Days = DateTime.Now;
                HyperLink lnkView = (HyperLink)e.Row.FindControl("lnkView");
                double daysDiff = (minus3Days - scheduleDate).TotalDays;
                //if(daysDiff )
                if (daysDiff >= -3 && daysDiff <= 30)
                {
                    if (lnkView != null)
                    {
                        lnkView.Visible = true;
                    }
                }
                else if (daysDiff > 30)
                {
                    if (lnkView != null)
                    {
                        lnkView.Visible = true;
                    }
                }
                else
                {
                    lnkView.Visible = false;
                }


                bool isEditable = Convert.ToBoolean(e.Row.Cells[5].Text);
                string userName = ((Label)e.Row.FindControl("lblScheduledBy")).Text;
                LinkButton lnk = (LinkButton)e.Row.FindControl("lnkEdit");
                if (!isEditable)
                {
                    if (lnk != null)
                    {
                        lnk.Visible = false;
                    }
                }

                if (userName.ToUpper() != loginName.ToUpper())
                {

                    lnkView.Visible = false;
                    lnk.Visible = false;
                }
            }
        }

        protected void grdCentersDetails_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdCentersDetails.PageIndex = e.NewPageIndex;
            BindVEDScheduled();
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            try
            {
                ClearControls();
            }
            catch (Exception ex)
            {
                Common.ErrorLog(Type.Error, "CreateVEDSchedule : btnCancel_Click", "", "", loginName, executionContext, ex, RequestType.Portal);
            }
        }

        protected void grdPreviousSchedules_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdPreviousSchedules.PageIndex = e.NewPageIndex;
            BindPreviouScheduledByUserID(loginName);
        }

        protected void rdbuttonlist_SelectedIndexChanged(object sender, EventArgs e)
        {
            // lblError.Text = rdbuttonlist.SelectedItem.Value;
            btnSubmit.Text = "Submit";
            ClearControls();
            BindCenterDropDown();
            BindVEDScheduled();
            BindPreviouScheduledByUserID(loginName);
            detailsDIV.Visible = false;


        }
    }
}
