﻿using Microsoft.SharePoint;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using RCPCampus_VED.BusinessLayer;
using RCPCampus_VED.DTO;
using Newtonsoft.Json;
using System.Web.UI.HtmlControls;
using System.Data;
namespace RCPCampus_VED.Webparts.EditVEDSchedule
{
    [ToolboxItemAttribute(false)]
    public partial class EditVEDSchedule : WebPart
    {
        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]
        Business BL = null;
        string executionContext = "";
        string loginName = string.Empty;
        public EditVEDSchedule()
        {
            BL = new Business();
            executionContext = Guid.NewGuid().ToString();
            loginName = SPContext.Current.Web.CurrentUser.LoginName.Split('\\')[1].ToString();
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                if (!Page.IsPostBack)
                {
                    BindOfficeType();
                    BindVEDScheduled();
                    detailsDIV.Visible = false;
                }
            }
            catch (Exception ex)
            {
                Common.ErrorLog(Type.Error, "EditVEDSchedule : Page_Load", "", "", loginName, executionContext, ex, RequestType.Portal);
            }
        }
        private void BindOfficeType()
        {
            ServiceResult<Generic> results = BL.GetOfficeType("usp_GetOfficeType");
            if (results.Data.ResultData != string.Empty)
            {
                DataSet ds = JsonConvert.DeserializeObject<DataSet>(results.Data.ResultData);

                rdbuttonlist.DataSource = ds.Tables[0];
                rdbuttonlist.DataTextField = "Title";
                rdbuttonlist.DataValueField = "ID";
                rdbuttonlist.DataBind();
                // string firstIteam=Convert.ToString(rdbuttonlist.SelectedIndex= 0);

                //rdbuttonlist.Items.FindByText("JC").Selected = true;
                rdbuttonlist.Items.FindByText(ds.Tables[0].Rows[0]["Title"].ToString()).Selected = true;

            }
        }
        private void BindVEDScheduled(bool isRebind = false)
        {

            string officeType = rdbuttonlist.SelectedItem.Value;
            string request = "loginName : " + loginName + " typeOFlevel : State ";
            ServiceResult<List<VEDSchedule>> results = null;
            try
            {
                results = BL.GetManagerLevelScheduleData(loginName, "State", executionContext, loginName, officeType, RequestType.Portal);
                grdCentersDetails.DataSource = null;
                grdCentersDetails.DataBind();
                //grdCentersDetails.PageIndex = 0;
                grdCentersDetails.DataSource = results.Data;
                if (isRebind) { grdCentersDetails.PageIndex = 0; }
                grdCentersDetails.DataBind();
                executionContext = results.ExecutionContext;
                //
                //grdCentersDetails.SetPageIndex(0);
            }
            catch (Exception ex)
            {
                Common.ErrorLog(Type.Error, "EditVEDSchedule : BindVEDScheduled", request, JsonConvert.SerializeObject(results), loginName, executionContext, ex, RequestType.Portal);
            }
        }

        private void ClearControls()
        {
            lblOfficeArea.Text = string.Empty;
            //lblOfficeCSPerson.Text = string.Empty;
            lblOfficeAddress.Text = string.Empty;
            lblOfficeType.Text = string.Empty;
            //lblActualDate.Text = string.Empty;
            lblCity.Text = string.Empty;
            lblOfficeArea.Text = string.Empty;
            //lblScheduleDate.Text = string.Empty;
            txtScheduleDate.Text = string.Empty;
            lblZone.Text = string.Empty;
            txtComments.Text = string.Empty;
            txtComments.Visible = false;
            //ddlCenters.Enabled = true;
            //ddlCenters.ClearSelection();
            //ddlCenters.SelectedValue = 0;
            //ddlCenters.Items.FindByValue("0").Selected = true;
            BindVEDScheduled(true);
            detailsDIV.Visible = false;
        }

        private void GetVEDScheduledData(int VEDId)
        {
            ServiceResult<VEDSchedule> data = null;
            try
            {
                ViewState["currentItem"] = string.Empty;
                data = BL.GetScheduledVEDDetailsByID(VEDId.ToString(), executionContext, loginName, RequestType.Portal);
                executionContext = data.ExecutionContext;
                lblCity.Text = data.Data.City;
                lblOfficeAddress.Text = data.Data.Address;
                //lblOfficeCSPerson.Text = data.Data.OfficeAdmins;
                string officeadmin = data.Data.OfficeAdmins;
                string[] arr = officeadmin.Split(';');
                for (int i = 0; i < arr.Length; i++)
                {

                    HtmlGenericControl li = new HtmlGenericControl("li");
                    li.InnerHtml = Convert.ToString(arr[i]);

                    ulofficecsperson.Controls.Add(li);

                }
                lblOfficeType.Text = data.Data.OfficeType;
                lblZone.Text = data.Data.Zone;
                lblOfficeArea.Text = data.Data.CarpetArea;
                txtScheduleDate.Text = data.Data.ScheduledOn;
                txtOffice.Text = data.Data.Center;
                ViewState["currentItem"] = VEDId;
                txtComments.Visible = true;
                txtComments.Text = string.Empty;
                lblError.Text = string.Empty;
                detailsDIV.Visible = true;
            }
            catch (Exception ex)
            {
                Common.ErrorLog(Type.Error, "EditVEDSchedule : GetVEDScheduledData", "VEDId : " + VEDId, JsonConvert.SerializeObject(data), loginName, executionContext, ex, RequestType.Portal);
            }


        }

        protected void EditSchedule(object sender, EventArgs e)
        {
            try
            {
                btnSubmit.Text = "Update";
                btnDiv.Visible = true;
                GridViewRow row = (sender as LinkButton).NamingContainer as GridViewRow;
                int ID = Convert.ToInt32(grdCentersDetails.Rows[row.RowIndex].Cells[5].Text);
                GetVEDScheduledData(ID);
            }
            catch (Exception ex)
            {
                Common.ErrorLog(Type.Error, "EditVEDSchedule : EditSchedule", "ID : " + ID, "", loginName, executionContext, ex, RequestType.Portal);
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            ServiceResult result = null;

            string request = "scheduleDate : " + txtScheduleDate.Text.Trim() + " txtComments : " + txtComments.Text + " ViewState CurrentItem : " + ViewState["currentItem"] != null ? ViewState["currentItem"].ToString() : "";
            try
            {
                string scheduleDate = txtScheduleDate.Text.Trim();
                if (scheduleDate == string.Empty)
                {
                    lblError.Text = "Please select the date.";
                }
                else if (btnSubmit.Text.ToUpper() == "UPDATE" && txtComments.Text == string.Empty)
                {
                    lblError.Text = "Please provide Comments.";
                }
                else
                {
                    result = BL.AddVEDSchedule(ViewState["currentItem"].ToString(), "0", scheduleDate, txtComments.Text, executionContext, loginName, RequestType.Portal);
                    if (result.ErrorCode == "1")
                    {
                        lblError.Text = result.ErrorMessage;
                        ClearControls();
                        btnDiv.Visible = false;
                    }
                    else
                    {
                        lblError.Text = result.ErrorMessage + " Error Code : " + result.ExecutionContext;
                        btnDiv.Visible = true;
                    }
                }
            }
            catch (Exception ex)
            {
                Common.ErrorLog(Type.Error, "EditVEDSchedule : EditSchedule", request, JsonConvert.SerializeObject(result), loginName, executionContext, ex, RequestType.Portal);
            }
        }
        protected void grdCentersDetails_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                bool isEditable = Convert.ToBoolean(e.Row.Cells[4].Text);
                if (!isEditable)
                {
                    LinkButton lnk = (LinkButton)e.Row.FindControl("lnkEdit");
                    if (lnk != null)
                    {
                        lnk.Visible = false;
                    }
                }
            }
        }

        protected void grdCentersDetails_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdCentersDetails.PageIndex = e.NewPageIndex;
            BindVEDScheduled();
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            ClearControls();
        }
        protected void rdbuttonlist_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindVEDScheduled();
        }
    }
}
