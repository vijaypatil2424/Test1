﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Newtonsoft.Json;
using System;
using System.ComponentModel;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using RCPCampus_VED.BusinessLayer;
using RCPCampus_VED.DTO;

namespace RCPCampus_VED.Webparts.ScheduleVEDManagement
{
    [ToolboxItemAttribute(false)]
    public partial class ScheduleVEDManagement : WebPart
    {
        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]
        Business BL = null;
        string executionContext = "";
        string loginName = string.Empty;
        public ScheduleVEDManagement()
        {
            BL = new Business();
            //executionContext = Guid.NewGuid().ToString();
            loginName = SPContext.Current.Web.CurrentUser.LoginName.Split('\\')[1].ToString().ToLower();
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            string request = "loginName = " + loginName;
            if (!Page.IsPostBack)
            {
                try
                {
                    // ClearControl();
                    BindOfficeType();
                    BindState(loginName);
                    BindVEDScheduled();
                    BindPreviousAssessment(loginName, hdnType.Value);
                }
                catch (Exception ex)
                {
                    Common.ErrorLog(Type.Error, "ScheduleVEDManagement : Page_Load", request, "", loginName, executionContext, ex, RequestType.Portal);
                }
            }
        }

        private void BindOfficeType()
        {
            ServiceResult<Generic> results = BL.GetOfficeType("usp_GetOfficeType");
            if (results.Data.ResultData != string.Empty)
            {
                DataSet ds = JsonConvert.DeserializeObject<DataSet>(results.Data.ResultData);
                rdbuttonlist.DataSource = ds.Tables[0];
                rdbuttonlist.DataTextField = "Title";
                rdbuttonlist.DataValueField = "ID";
                rdbuttonlist.DataBind();
                rdbuttonlist.Items.FindByText(ds.Tables[0].Rows[0]["Title"].ToString()).Selected = true;
            }
        }

        private void BindPreviousAssessment(string loginName, string p)
        {
            string request = "loginName : " + loginName + "p : " + p;
            try
            {
                string officeType = rdbuttonlist.SelectedItem.Value;
                string[] arr = new string[4];
                arr[0] = "count=100";
                arr[1] = "UserID=" + loginName + "";
                arr[2] = "Type=" + p;
                arr[3] = "OfficeType=" + officeType;
                ServiceResult<Generic> data = BL.GenericMethod("usp_GetTheScheduleHistoryOfCenterByUserID", executionContext, loginName, RequestType.Portal, arr);

                if (data.Data.ResultData != string.Empty)
                {
                    DataSet result = JsonConvert.DeserializeObject<DataSet>(data.Data.ResultData);
                    if (result.Tables.Count > 0)
                    {
                        grdPreviousSchedules.DataSource = result.Tables[0];
                        result.Tables[0].Columns.Add(new DataColumn("URL"));
                        foreach (DataRow dr in result.Tables[0].Rows)
                        {
                            string VedId = dr["VEDID"].ToString();
                            string uRL = SPUrlUtility.CombineUrl(SPContext.Current.Web.Url, "/pages/Assessment.aspx?VEDID=" + VedId + "");
                            dr["URL"] = uRL;
                        }
                    }
                }
                else
                {
                    grdPreviousSchedules.DataSource = null;
                }
                grdPreviousSchedules.DataBind();
            }
            catch (Exception ex)
            {
                Common.ErrorLog(Type.Error, "CreateVEDSchedule : BindPreviousAssessment", request, "", loginName, executionContext, ex, RequestType.Portal);
            }
        }

        private void BindState(string loginName)
        {
            string request = "loginName=" + loginName;
            try
            {
                string officeType = rdbuttonlist.SelectedItem.Value;
                string[] arr = new string[2];
                arr[0] = "UserID=" + loginName;
                arr[1] = "OfficeType=" + officeType;
                ServiceResult<Generic> results = BL.GenericMethod("usp_Audit_GetStateBasedOnUserID", executionContext, loginName, RequestType.Portal, arr);
                if (results.Data.ResultData != string.Empty)
                {
                    DataSet ds = JsonConvert.DeserializeObject<DataSet>(results.Data.ResultData);

                    hdnType.Value = ds.Tables[0].Rows[0]["Type"].ToString();
                    if (hdnType.Value == "2")//State Head
                    {
                        ddlState.DataSource = ds.Tables[1];
                        ddlState.DataTextField = "Title";
                        ddlState.DataValueField = "ID";


                        //ddlCity.DataSource = ds.Tables[2];
                        //ddlCity.DataTextField = "City";
                        //ddlCity.DataValueField = "City";
                        //ddlCity.DataBind();
                        //ddlCity.Items.Insert(0, new ListItem("Select City", "0")); today's change date 26/03/2018
                        //if (ds.Tables[2].Rows.Count > 0)
                        //{
                        //    ddlArea.DataSource = ds.Tables[2];
                        //    ddlArea.DataTextField = "Area";
                        //    ddlArea.DataValueField = "Area";
                        //    ddlArea.DataBind();
                        //ddlArea.Items.Insert(0, new ListItem("Select Area", "0"));
                        //}
                    }
                    else if (hdnType.Value == "3")//Zone Head
                    {
                        ddlState.DataSource = ds.Tables[1];
                        ddlState.DataTextField = "Title";
                        ddlState.DataValueField = "ID";
                        ddlState.Items.Insert(0, new ListItem("Select State", "0"));
                    }
                    else
                    {
                        ddlState.DataSource = null;
                        ddlCity.DataSource = null;
                        //ddlCity.DataBind();

                    }
                    ddlState.DataBind();
                    ddlState.Items.Insert(0, new ListItem("Select State", "0"));
                    // lblType.Text = hdnType.Value;


                }
            }
            catch (Exception ex)
            {
                Common.ErrorLog(Type.Error, "ScheduleVEDManagement : BindState", request, "", loginName, executionContext, ex, RequestType.Portal);
            }
        }

        protected void hypCreateSchedule_Click(object sender, EventArgs e)
        {

        }

        protected void hypEditSchedules_Click(object sender, EventArgs e)
        {
            // Page.Response.Redirect("/sites/rcs/jcved/pages/Edit-Schedule.aspx", true);
            Page.Response.Redirect(SPUrlUtility.CombineUrl(SPContext.Current.Web.Url, "pages/Edit-Schedule.aspx"), true);
        }

        protected void ddlCity_SelectedIndexChanged(object sender, EventArgs e)
        {
            string request = "City : " + ddlCity.SelectedValue + " Type : " + ddlType.SelectedValue;
            if (ddlState.SelectedValue == "0")
            {
                lblError.Text = "Please select State.";
            }
            else
            {
                try
                {
                    BindCenter(ddlCity.SelectedValue, ddlType.SelectedValue);
                }
                catch (Exception ex)
                {
                    Common.ErrorLog(Type.Error, "ScheduleVEDManagement : ddlCity_SelectedIndexChanged", request, "", loginName, executionContext, ex, RequestType.Portal);
                }
            }
        }

        private void BindCenter(string city, string officeCategoryType)
        {
            string request = "City : " + city + " Type : " + officeCategoryType;
            string officeType = rdbuttonlist.SelectedItem.Value;
            try
            {
                string[] arr = new string[4];
                arr[0] = "City=" + city;
                arr[1] = "officeCategoryID=" + 0;
                arr[2] = "OfficeType=" + officeType;
                arr[3] = "Area=" + ddlArea.SelectedValue;
                ServiceResult<Generic> results = BL.GenericMethod("usp_Audit_GetCenterBasedOnCityID", executionContext, loginName, RequestType.Portal, arr);
                if (results.Data.ResultData != string.Empty)
                {
                    DataSet ds = JsonConvert.DeserializeObject<DataSet>(results.Data.ResultData);
                    if (ds.Tables.Count > 0)
                    {
                        ddlCenters.DataSource = ds.Tables[0];
                        ddlCenters.DataTextField = "Title";
                        ddlCenters.DataValueField = "ID";
                    }
                    else
                    {
                        ddlCenters.DataSource = null;
                    }
                    ddlCenters.DataBind();
                    ddlCenters.Items.Insert(0, new ListItem("Select Center", "0"));
                }
                else
                {
                    ddlCenters.DataSource = null;
                    ddlCenters.DataBind();
                    ddlCenters.Items.Insert(0, new ListItem("Select Center", "0"));
                }

            }
            catch (Exception ex)
            {
                Common.ErrorLog(Type.Error, "ScheduleVEDManagement : BindCenter", request, "", loginName, executionContext, ex, RequestType.Portal);
            }
        }

        protected void ddlCenters_SelectedIndexChanged(object sender, EventArgs e)
        {


            ServiceResult<Office> officeDetails = BL.GetCenterDetailsByID(ddlCenters.SelectedValue, executionContext, loginName, RequestType.Portal);
            if (officeDetails.ErrorCode == "1")
            {
                if (officeDetails.Data != null)
                {
                    detailsDIV.Visible = true;
                    //lblCity.Text = officeDetails.Data.City;
                    lblOfficeAddress.Text = officeDetails.Data.Address;
                    ddlOfficeAdmins.Items.Clear();
                    //ddlOfficeAdmins.DataBind(); 
                    string[] admins = null;
                    if (officeDetails.Data.OfficeAdmins.Contains(";"))
                    {
                        admins = officeDetails.Data.OfficeAdmins.Split(';');
                        for (int i = 0; i < admins.Length; i++)
                        {
                            ddlOfficeAdmins.Items.Insert(i, new ListItem(admins[i].ToString(), admins[i].ToString()));
                        }
                    }
                    else
                    {
                        ddlOfficeAdmins.Items.Insert(0, new ListItem(officeDetails.Data.OfficeAdmins, officeDetails.Data.OfficeAdmins));
                    }
                    lblOfficeType.Text = officeDetails.Data.OfficeType;
                    //lblZone.Text = officeDetails.Data.Zone;
                    lblOfficeArea.Text = officeDetails.Data.CarpetArea;
                    lblZone.Text = officeDetails.Data.Zone;
                    btnSubmit.Text = "Submit";
                    //txtComments.Visible = false;
                    txtCommentsDIV.Visible = false;
                    //lblComments.Visible = false;
                    lblError.Text = string.Empty;
                    detailsDIV.Visible = true;
                    //lblOfficeType.Text = officeDetails.Data.OfficeType;
                }
                else
                {
                    lblError.Text = "No data found for the selected center";

                }
            }
            else
            {
                lblError.Text = officeDetails.ErrorMessage + "Error code : " + executionContext;
            }

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            lblError.Text = string.Empty;
            string request = "UserID : " + ddlOfficeAdmins.SelectedValue + " OfficeID : " + ddlCenters.SelectedValue + " ScheduledOn : " + txtScheduleDate.Text + " Comments : " + txtComments.Text + " AssessmentType : " + hdnType.Value + " DelegatedBy : " + loginName;
            ServiceResult<Generic> result = null;
            int ScheduleDoneFrom = Convert.ToInt32(RequestType.Portal);
            try
            {
                string scheduleDate = txtScheduleDate.Text.Trim();
                if (ddlState.SelectedValue == "0")
                {
                    lblError.Text = "Please select State";
                }
                else if (ddlArea.SelectedValue == "0")
                {
                    lblError.Text = "Please Select Area";
                }
                else if (ddlCity.SelectedValue == "0")
                {
                    lblError.Text = "Please select City";
                }
                //else if (ddlType.SelectedValue == "0")
                //{
                //    lblError.Text = "Please select Office Type";
                //}

                else if (ddlCenters.SelectedValue == "0")
                {
                    lblError.Text = "Please select the center";
                }
                else if (scheduleDate == string.Empty)
                {
                    lblError.Text = "Please select the date.";
                }
                else if (btnSubmit.Text.ToUpper() == "UPDATE" && txtComments.Text == string.Empty)
                {
                    lblError.Text = "Please provide Comments.";
                }
                else
                {
                    string[] arr = new string[8];
                    if (hdnVEDID.Value == string.Empty)
                    {
                        arr[0] = "ID=" + "";
                    }
                    else
                    {
                        arr[0] = "ID=" + hdnVEDID.Value;
                    }
                    arr[1] = "UserID=" + ddlOfficeAdmins.SelectedValue;
                    arr[2] = "OfficeID=" + ddlCenters.SelectedValue;
                    arr[3] = "ScheduledOn=" + txtScheduleDate.Text;
                    arr[4] = "Comments=" + txtComments.Text;
                    arr[5] = "AssessmentType=" + hdnType.Value;
                    arr[6] = "DelegatedBy=" + loginName;
                    arr[7] = "ScheduleDoneFrom=" + ScheduleDoneFrom;
                    DataSet ds = null;

                    result = BL.GenericMethod("usp_Audit_InsertUpdateVEDSchedule", executionContext, loginName, RequestType.Portal, arr);
                    ds = JsonConvert.DeserializeObject<DataSet>(result.Data.ResultData);
                    if (ds.Tables[0].Rows[0]["ErrorCode"].ToString() == "1")
                    {
                        lblError.Text = ds.Tables[0].Rows[0]["ErrorMessage"].ToString();
                        BindVEDScheduled();
                        ClearControl();
                        ScriptManager.RegisterStartupScript(Page, Page.GetType(), "script", "Success();", true);
                    }
                    else
                    {
                        lblError.Text = ds.Tables[0].Rows[0]["ErrorMessage"].ToString() + " Error Code : " + result.ExecutionContext;
                    }
                }
            }
            catch (Exception ex)
            {
                Common.ErrorLog(Type.Error, "CreateVEDSchedule : btnSubmit_Click", request, JsonConvert.SerializeObject(result), loginName, executionContext, ex, RequestType.Portal);
            }
        }
        private void BindVEDScheduled()
        {
            string officeType = rdbuttonlist.SelectedItem.Value;
            string request = "loginName : " + loginName;
            try
            {
                string[] arr = new string[6];
                arr[0] = "ID=" + "";
                arr[1] = "UserID=" + loginName;
                arr[2] = "OfficeID=" + "";
                arr[3] = "Type=GETALL";
                arr[4] = "AssessmentType=" + hdnType.Value;
                arr[5] = "OfficeType=" + officeType;
                DataSet ds = null;
                ServiceResult<Generic> results = BL.GenericMethod("usp_Audit_GetAllVEDSchedule", executionContext, loginName, RequestType.Portal, arr);
                if (results.Data.ResultData != string.Empty)
                {
                    ds = JsonConvert.DeserializeObject<DataSet>(results.Data.ResultData);

                    if (ds.Tables.Count > 0)
                    {
                        grdCentersDetails.DataSource = ds.Tables[0];
                    }
                    else
                    {
                        grdCentersDetails.DataSource = null;
                    }
                    grdCentersDetails.DataBind();
                }

            }
            catch (Exception ex)
            {
                Common.ErrorLog(Type.Error, "ScheduleVEDManagement : BindVEDScheduled", request, "", loginName, executionContext, ex, RequestType.Portal);
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            ClearControl();
            lblError.Text = string.Empty;
        }

        private void ClearControl()
        {
            ddlState.SelectedValue = "0";
            ddlState.Enabled = true;

            ddlArea.Items.Clear();
            ddlArea.Items.Insert(0, new ListItem("Select Area", "0"));
            ddlArea.SelectedValue = "0";
            ddlArea.DataBind();
            ddlArea.Enabled = true;

            ddlCity.Items.Clear();
            ddlCity.Items.Insert(0, new ListItem("Select City", "0"));
            ddlCity.SelectedValue = "0";
            ddlCity.DataBind();
            ddlCity.Enabled = true;

            ddlCenters.Items.Clear();
            ddlCenters.Items.Insert(0, new ListItem("Select Center", "0"));
            ddlCenters.SelectedValue = "0";
            ddlCenters.DataBind();
            ddlCenters.Enabled = true;

            //ddlType.SelectedValue = "0";
            //ddlType.Enabled = true;

            txtScheduleDate.Text = string.Empty;

            detailsDIV.Visible = false;

            btnSubmit.Text = "Submit";

            lblError.Text = string.Empty;



        }

        protected void EditSchedule(object sender, EventArgs e)
        {
            try
            {
                lblError.Text = string.Empty;
                btnSubmit.Text = "Update";
                GridViewRow row = (sender as LinkButton).NamingContainer as GridViewRow;
                int ID = Convert.ToInt32(grdCentersDetails.Rows[row.RowIndex].Cells[5].Text);
                GetVEDScheduledData(ID);
                hdnVEDID.Value = ID.ToString();
                detailsDIV.Visible = true;
            }
            catch (Exception ex)
            {
                Common.ErrorLog(Type.Error, "ScheduleVEDManagement : EditSchedule", "", "", loginName, executionContext, ex, RequestType.Portal);
            }
        }
        private void GetVEDScheduledData(int VEDId)
        {
            string request = "VEDId : " + VEDId; //GETBYID
            try
            {
                string[] arr = new string[4];
                arr[0] = "ID=" + VEDId;
                arr[1] = "UserID=" + loginName;
                arr[2] = "OfficeID=" + "";
                arr[3] = "Type=GETBYID";

                DataSet ds = null;
                ServiceResult<Generic> results = BL.GenericMethod("usp_Audit_GetAllVEDSchedule", executionContext, loginName, RequestType.Portal, arr);
                ds = JsonConvert.DeserializeObject<DataSet>(results.Data.ResultData);


                if (ds.Tables[0].Rows.Count > 0)
                {
                    // BindState(loginName);
                    ddlState.SelectedValue = ds.Tables[0].Rows[0]["State"].ToString();
                    ddlState.Enabled = false;
                    BindArea(ddlState.SelectedValue);
                    ddlArea.SelectedValue = ds.Tables[0].Rows[0]["Area"].ToString();
                    ddlArea.Enabled = false;
                    BindCity(ddlArea.SelectedValue);
                    ddlCity.SelectedValue = ds.Tables[0].Rows[0]["City"].ToString();
                    ddlCity.Enabled = false;

                    //ddlType.SelectedValue = ds.Tables[0].Rows[0]["OfficeCategoryID"].ToString();
                    //ddlType.Enabled = false;

                    BindCenter(ddlCity.SelectedValue, ddlType.SelectedValue);
                    ddlCenters.SelectedValue = ds.Tables[0].Rows[0]["OfficeID"].ToString();
                    ddlCenters.Enabled = false;

                    lblZone.Text = ds.Tables[0].Rows[0]["Zone"].ToString();
                    lblOfficeArea.Text = ds.Tables[0].Rows[0]["CarpetArea"].ToString();
                    string[] admins = null;
                    ddlOfficeAdmins.Items.Clear();
                    if (ds.Tables[0].Rows[0]["OfficeAdmins"].ToString().Contains(";"))
                    {
                        admins = ds.Tables[0].Rows[0]["OfficeAdmins"].ToString().Split(';');
                        for (int i = 0; i < admins.Length; i++)
                        {
                            ddlOfficeAdmins.Items.Insert(i, new ListItem(admins[i].ToString(), admins[i].ToString()));
                        }
                    }
                    else
                    {
                        ddlOfficeAdmins.Items.Insert(0, new ListItem(ds.Tables[0].Rows[0]["OfficeAdmins"].ToString(), ds.Tables[0].Rows[0]["OfficeAdmins"].ToString()));
                    }
                    ddlOfficeAdmins.SelectedValue = ds.Tables[0].Rows[0]["ScheduledBy"].ToString();
                    txtScheduleDate.Text = ds.Tables[0].Rows[0]["ScheduledOn"].ToString();
                    lblOfficeAddress.Text = ds.Tables[0].Rows[0]["Address"].ToString();
                    lblOfficeType.Text = ds.Tables[0].Rows[0]["OfficeType"].ToString();
                    txtCommentsDIV.Visible = true;
                    //lblComments.Visible = true;

                }


            }
            catch (Exception ex)
            {
                Common.ErrorLog(Type.Error, "CreateVEDSchedule : GetVEDScheduledData", request, "", loginName, executionContext, ex, RequestType.Portal);
            }

        }
        protected void grdCentersDetails_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdCentersDetails.PageIndex = e.NewPageIndex;
            BindVEDScheduled();
        }

        protected void btnBeginAssessment_Click1(object sender, EventArgs e)
        {
            lblError.Text = string.Empty;
            string request = "UserID : " + ddlOfficeAdmins.SelectedValue + " OfficeID : " + ddlCenters.SelectedValue + " ScheduledOn : " + txtScheduleDate.Text + " AssessmentType : " + hdnType.Value;
            ServiceResult<Generic> result = null;
            try
            {

                string scheduleDate = txtScheduleDate.Text.Trim();
                if (ddlState.SelectedValue == "0")
                {
                    lblError.Text = "Please select State";
                }
                //else if (ddlType.SelectedValue == "0")
                //{
                //    lblError.Text = "Please select Office Type";
                //}
                else if (ddlCity.SelectedValue == "0")
                {
                    lblError.Text = "Please select City";
                }
                else if (ddlCenters.SelectedValue == "0")
                {
                    lblError.Text = "Please select the center";
                }
                else if (scheduleDate == string.Empty)
                {
                    lblError.Text = "Please select the date.";
                }
                else
                {
                    string officeType = rdbuttonlist.SelectedItem.Value;
                    int ScheduleDoneFrom = Convert.ToInt32(RequestType.Portal);
                    string[] arr = new string[5];
                    arr[0] = "UserID=" + loginName;
                    arr[1] = "OfficeID=" + ddlCenters.SelectedValue;
                    arr[2] = "ScheduledOn=" + txtScheduleDate.Text;
                    arr[3] = "AssessmentType=" + hdnType.Value;
                    arr[4] = "ScheduleDoneFrom=" + ScheduleDoneFrom;
                    DataSet ds = null;
                    result = BL.GenericMethod("usp_Audit_InsertVEDScheduleForStateAndZonal", executionContext, loginName, RequestType.Portal, arr);
                    ds = JsonConvert.DeserializeObject<DataSet>(result.Data.ResultData);

                    if (ds.Tables[0].Rows[0]["ErrorCode"].ToString() == "1")
                    {
                        lblError.Text = result.ErrorMessage;
                        string VEDID = ds.Tables[1].Rows[0]["VEDID"].ToString();
                        Page.Response.Redirect(SPContext.Current.Web.Url + "/pages/Assessment.aspx?VEDID=" + VEDID + "&Type=3", true);
                        //Page.Response.Redirect(SPContext.Current.Web.Url + "/pages/Assessment.aspx?VEDID=" + VEDID + "&Type="+officeType+"", true);
                    }
                }
            }
            catch (Exception ex)
            {
                Common.ErrorLog(Type.Error, "CreateVEDSchedule : btnBeginAssessment_Click1", request, JsonConvert.SerializeObject(result), loginName, executionContext, ex, RequestType.Portal);
            }
        }

        protected void ddlState_SelectedIndexChanged(object sender, EventArgs e)
        {
            string request = "State : " + ddlState.SelectedValue;
            if (ddlState.SelectedValue != "0")
            {
                //BindCity(ddlState.SelectedValue);//today's change date 26/03/2018
                BindArea(ddlState.SelectedValue);
            }
            else
            {
                lblError.Text = "Please select State";
            }

        }

        private void BindArea(string state)
        {

            try
            {
                string officeType = rdbuttonlist.SelectedItem.Value;
                string[] arr = new string[2];
                arr[0] = "StateID=" + state;
                arr[1] = "OfficeType=" + officeType;
                DataSet ds = null;
                ServiceResult<Generic> results = BL.GenericMethod("usp_Audit_GetAreaBasedOnStateID", executionContext, loginName, RequestType.Portal, arr);
                ds = JsonConvert.DeserializeObject<DataSet>(results.Data.ResultData);
                if (results.Data.ResultData != string.Empty)
                {
                    if (ds.Tables.Count > 0)
                    {
                        ddlArea.DataSource = ds.Tables[0];
                        ddlArea.DataTextField = "Area";
                        ddlArea.DataValueField = "Area";

                    }
                }
                else
                {
                    ddlArea.DataSource = null;
                }
                ddlArea.DataBind();
                ddlArea.Items.Insert(0, new ListItem("Select Area", "0"));
            }
            catch (Exception ex)
            {
                Common.ErrorLog(Type.Error, "ScheduleVEDManagement : BindArea", "", "", loginName, executionContext, ex, RequestType.Portal);
            }

        }


        private void BindCity(string Area)
        {

            try
            {
                string officeType = rdbuttonlist.SelectedItem.Value;
                string[] arr = new string[2];
                arr[0] = "AreaName=" + Area;
                arr[1] = "OfficeType=" + officeType;
                DataSet ds = null;
                ServiceResult<Generic> results = BL.GenericMethod("usp_Audit_GetCityBasedOnStateID", executionContext, loginName, RequestType.Portal, arr);
                ds = JsonConvert.DeserializeObject<DataSet>(results.Data.ResultData);
                if (results.Data.ResultData != string.Empty)
                {
                    if (ds.Tables.Count > 0)
                    {
                        ddlCity.DataSource = ds.Tables[0];
                        ddlCity.DataTextField = "City";
                        ddlCity.DataValueField = "City";
                    }
                }
                else
                {
                    ddlCity.DataSource = null;
                }
                ddlCity.DataBind();
                ddlCity.Items.Insert(0, new ListItem("Select City", "0"));
            }
            catch (Exception ex)
            {
                Common.ErrorLog(Type.Error, "ScheduleVEDManagement : BindCity", "", "", loginName, executionContext, ex, RequestType.Portal);
            }

        }

        protected void grdPreviousSchedules_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdPreviousSchedules.PageIndex = e.NewPageIndex;
            BindPreviousAssessment(loginName, hdnType.Value);
        }

        protected void ddlType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlCity.SelectedValue != "0")
            {
                BindCenter(ddlCity.SelectedValue, ddlType.SelectedValue);
            }
        }

        protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
        {
            string request = "State : " + ddlState.SelectedValue;
            if (ddlArea.SelectedValue != "0")
            {
                //BindCity(ddlState.SelectedValue);//today's change date 26/03/2018
                BindCity(ddlArea.SelectedValue);
            }
            else
            {
                lblError.Text = "Please select Area";
            }
        }


        protected void rdbuttonlist_SelectedIndexChanged(object sender, EventArgs e)
        {
            BindState(loginName);
            BindVEDScheduled();
            ClearControl();
            BindPreviousAssessment(loginName, hdnType.Value);
            //lblError.Text = rdbuttonlist.SelectedItem.Text;
        }
    }
}
