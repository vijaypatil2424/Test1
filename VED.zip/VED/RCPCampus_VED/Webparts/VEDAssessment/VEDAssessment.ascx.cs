﻿using System;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using RCPCampus_VED.BusinessLayer;
using RCPCampus_VED.DTO;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using Microsoft.SharePoint;
using Newtonsoft.Json;
using System.Configuration;
using Microsoft.SharePoint.Utilities;
using System.Net.Mail;

namespace RCPCampus_VED.Webparts.VEDAssessment
{
    [ToolboxItemAttribute(false)]
    public partial class VEDAssessment : WebPart
    {
        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]
        Business BL = null;
        string executionContext = "";
        string loginName = string.Empty;
        public VEDAssessment()
        {
            BL = new Business();
            executionContext = Guid.NewGuid().ToString();
            loginName = SPContext.Current.Web.CurrentUser.LoginName.Split('\\')[1].ToString();
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            lblError.Text = string.Empty;
            //TODO : To check if Page load is perform , to hide the SAVE button
            try
            {
                string officeTypeID = string.Empty;
                if (HttpContext.Current.Request.QueryString["vedid"] != null)
                {
                    if (HttpContext.Current.Request.QueryString["vedid"].ToString() != string.Empty)
                    {

                        if (!Page.IsPostBack)
                        {
                            hdnType.Value = "1";
                            string scheduleID = Convert.ToString(HttpContext.Current.Request.QueryString["vedid"]);
                            // string officeType = Convert.ToString(HttpContext.Current.Request.QueryString["Type"]);
                            ServiceResult<VEDSchedule> scheduleDetail = BL.GetScheduledVEDDetailsByID(scheduleID, executionContext, loginName, RequestType.Portal);
                            lblScheduleDate.Text = scheduleDetail.Data.ScheduledOn;
                            officeTypeID = scheduleDetail.Data.OfficeTypeID.ToString();
                            lblActualDate.Text = string.IsNullOrEmpty(scheduleDetail.Data.ActualAssesstmentDate) ? DateTime.Now.ToString("dd-MMM-yyyy") : scheduleDetail.Data.ActualAssesstmentDate;
                            lblCenter.Text = scheduleDetail.Data.Center;
                            executionContext = scheduleDetail.ExecutionContext;
                            ServiceResult<FinalAssessmentData> result = BL.GetAssessmentDetails(HttpContext.Current.Request.QueryString["vedid"].ToString(), "", "", RequestType.Portal);
                            if (result.Data.AssesstmentDetails.Count > 0)
                            {
                                assessmentDiv.Visible = false;
                                //  grdAssessment.Visible = false;
                                grdCentersDetails.DataSource = result.Data.VEDFinalData;
                                grdCentersDetails.DataBind();

                                readOnlyDIV.Visible = true;
                                grdAssessmentReadOnly.DataSource = result.Data.AssesstmentDetails;
                                grdAssessmentReadOnly.DataBind();

                                buttonDiv.Visible = false;

                                btnExportToExcel.Visible = true;
                            }
                            else
                            {
                                readOnlyDIV.Visible = false;
                                btnExportToExcel.Visible = false;
                                lblActualDate.Text = DateTime.Now.ToString("dd-MMM-yyyy");
                                FacilityAreaDetailsMaster(officeTypeID, scheduleID);

                            }

                        }
                        //AddAttachment(postedFile, dt, Convert.ToString(lblRowID.Text.Trim()));
                    }
                    else
                    {
                        Common.ErrorLog(Type.Information, "VEDAssessment : Page_Load", "", "No VEDID Found", loginName, executionContext, null, RequestType.Portal);
                    }
                }
            }
            catch (Exception ex)
            {
                lblError.Text = "Oops Something went wrong. Error Code : " + executionContext;
                Common.ErrorLog(Type.Error, "VEDAssessment : Page_Load", "", "", loginName, executionContext, ex, RequestType.Portal);
            }
        }

        private void FacilityAreaDetailsMaster(string centerTypeID, string VEDScheduleID)
        {
            ServiceResult<Facility> result = null;
            string request = "centerTypeID : " + centerTypeID + " VEDScheduleID : " + VEDScheduleID;
            try
            {
                result = BL.GetFaciltyAreaDetailsMasters(centerTypeID, VEDScheduleID, "", loginName, RequestType.Portal);
                grdAssessment.DataSource = result.Data.FacilityMaster;
                grdAssessment.DataBind();
                grdCentersDetails.DataSource = result.Data.VEDSchedules;
                grdCentersDetails.DataBind();
                ViewState["VEDSchedules"] = result.Data.VEDSchedules.ToList();
                executionContext = result.ExecutionContext;
            }
            catch (Exception ex)
            {
                lblError.Text = "Oops Something went wrong. Error Code : " + executionContext;
                Common.ErrorLog(Type.Error, "VEDAssessment : FacilityAreaDetailsMaster", request, JsonConvert.SerializeObject(result), loginName, executionContext, ex, RequestType.Portal);
            }

        }

        //protected void grdAssessment_DataBound(object sender, EventArgs e)
        //{


        //    GridViewRow row = new GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Normal);
        //    TableHeaderCell cell = new TableHeaderCell();
        //    cell.Text = "";
        //    cell.ColumnSpan = 2;
        //    row.Controls.Add(cell);

        //    cell = new TableHeaderCell();
        //    cell.ColumnSpan = 2;
        //    cell.Text = "Facility";
        //    row.Controls.Add(cell);

        //    cell = new TableHeaderCell();
        //    cell.ColumnSpan = 1;
        //    cell.Text = "Points";
        //    row.Controls.Add(cell);

        //    cell = new TableHeaderCell();
        //    cell.ColumnSpan = 2;
        //    cell.Text = "";
        //    row.Controls.Add(cell);
        //    grdAssessment.HeaderRow.Parent.Controls.AddAt(0, row);
        //}

        //protected void grdAssessment_RowDataBound(object sender, GridViewRowEventArgs e)
        //{
        //    if (e.Row.RowType == DataControlRowType.DataRow)
        //    {
        //        //string critricalityType = e.Row.Cells[2].Text;
        //        //DropDownList ddl = (DropDownList)e.Row.FindControl("ddlCondition");
        //        //List<ScoringMaster> scMasters = (List<ScoringMaster>)ViewState["ScoringMaster"];
        //        //ScoringMaster scMaster = scMasters.Where(t => t.Criticality == critricalityType).FirstOrDefault();
        //        //List<CommonDDL> ddlColl = new List<CommonDDL>();




        //        //CommonDDL obj = new CommonDDL();
        //    }
        ////}

        private bool ValidImage(string imageName)
        {
            bool isValid = true;

            switch (imageName.ToLower())
            {
                case "png":
                case "jpeg":
                case "jpg":
                    break;
                default:
                    isValid = false;
                    break;
            }


            return isValid;
        }

        protected void btnUploadFile_Click(object sender, EventArgs e)
        {
            GridViewRow row = (sender as Button).NamingContainer as GridViewRow;
            FileUpload flInsertFile = ((FileUpload)row.FindControl("flInsertFile"));
            Label errormsg = ((Label)row.FindControl("errormsg"));
            string lblPoint = ((Label)row.FindControl("lblPoint")).Text;
            GridView grdAttachments = ((GridView)row.FindControl("grdAttachments"));
            Label lblRowID = (Label)row.FindControl("lblRowID");
            int pageID = (Convert.ToInt32(row.RowIndex));
            lblPageId.Text = Convert.ToString(pageID);
            try
            {

                string Result = string.Empty;
                errormsg.Text = string.Empty;
                if (flInsertFile.HasFile)
                {
                    DataTable dt = (DataTable)Page.Session[AttachmentVar.Attachment + lblRowID.Text.Trim()];

                    if (dt == null)
                    {
                        if (flInsertFile.PostedFiles.Count <= 3)
                        {
                            dt = createAttachmentTable();
                        }
                        else
                        {
                            errormsg.Text = "Only three files are allowed to upload";
                            goto end;
                        }
                    }
                    if (dt.Rows.Count <= 3)
                    {
                        int fileCount = dt.Rows.Count;
                        foreach (HttpPostedFile postedFile in flInsertFile.PostedFiles)
                        {

                            double fileSize = (postedFile.ContentLength / 1024) / 1000;
                            if (fileSize > 3)
                            {
                                errormsg.Text = "Error file uploading file : " + postedFile.FileName + "Maximum file size allowed is 3 M.B";
                                goto end;
                            }
                            else if (!ValidImage(postedFile.FileName.Split('.')[1]))
                            {
                                errormsg.Text = "Invalid file format : " + postedFile.FileName + " Allowed file format are jpeg.jpg or png";
                                goto end;
                            }
                            else
                            {
                                string FileName = new FileInfo(postedFile.FileName).Name;
                                bool exists = dt.Select().ToList().Exists(dtrow => Convert.ToString(dtrow["FileName"]) == Convert.ToString(FileName));
                                if (exists)
                                {
                                    ScriptManager.RegisterStartupScript(this.Page, GetType(), "script", "alert('Attached File Name is same. Please try Another Name and Upload'); ", true);

                                }
                                else
                                {
                                    if (fileCount >= 3)
                                    {
                                        errormsg.Text = "Only three files are allowed to upload";
                                        goto end;
                                    }
                                    else
                                    {
                                        dt = AddAttachment(postedFile, dt, Convert.ToString(lblRowID.Text.Trim()));
                                        fileCount += 1;
                                    }
                                }
                            }

                        }

                        Page.Session[AttachmentVar.Attachment + lblRowID.Text.Trim()] = dt;

                        if (dt != null)
                        {
                            FillAttachmentGrid(grdAttachments, dt);
                            if (grdAssessment != null)
                            {
                                grdAssessment.HeaderRow.TableSection = TableRowSection.TableHeader;
                            }
                        }
                        else
                        {
                            grdAttachments.DataSource = createAttachmentTable();
                            grdAttachments.DataBind();
                            errormsg.Text = Result;
                        }

                    }
                    else
                    {
                        errormsg.Text = "Only three files are allowed to upload";
                        goto end;
                    }
                end:
                    return;
                }
                else
                {
                    errormsg.Text = "Select the File.";
                }
            }
            catch (Exception ex)
            {
                string ErrorLog = ex.Message + "\n\n" + ex.StackTrace + "btnUploadFile_Click";
                Common.ErrorLog(Type.Error, "VEDAssessment : btnUploadFile_Click", "", "", loginName, executionContext, ex, RequestType.Portal);
                //  sbErrorMessage.AppendLine(ErrorLog);
            }
        }

        private DataTable createAttachmentTable()
        {
            DataTable dtableAttachmentArray = null;

            dtableAttachmentArray = BOInsertColumn(AttachmentVar.FileName, null, dtableAttachmentArray); //  Adding FileName column manually, because its a custom column
            dtableAttachmentArray = BOInsertColumn(AttachmentVar.FileGUID, null, dtableAttachmentArray);  //  Adding FileGUID column manually, because its a custom column
            dtableAttachmentArray = BOInsertColumn(AttachmentVar.FilePath, null, dtableAttachmentArray);   //  Adding FilePath column manually, because its a custom column
            dtableAttachmentArray = BOInsertColumn(AttachmentVar.FileDelete, null, dtableAttachmentArray); //  Adding FileContents column manually, because its a custom column
            dtableAttachmentArray = BOInsertColumn(AttachmentVar.ID, null, dtableAttachmentArray); //  Adding FileContents column manually, because its a custom column
            dtableAttachmentArray = BOInsertColumn(AttachmentVar.RowIndex, null, dtableAttachmentArray); //  Adding FileContents column manually, because its a custom column
            dtableAttachmentArray = BOInsertColumn(AttachmentVar.OperationalStatus, null, dtableAttachmentArray); //  Adding FileContents column manually, because its a custom column

            return dtableAttachmentArray;
        }

        private DataTable addAttachment(DataTable dtableAttachmentArray)
        {
            string pageUniqueDt = Convert.ToString(ViewState["pageUniqueDt"]);

            if (dtableAttachmentArray == null)
            {
                dtableAttachmentArray = createAttachmentTable();
            }

            if (!string.IsNullOrEmpty(Convert.ToString(Page.Session[AttachmentVar.FileName + pageUniqueDt])))
            {
                DataRow drAttachments = dtableAttachmentArray.NewRow();
                drAttachments[AttachmentVar.FileName] = Convert.ToString(Page.Session[AttachmentVar.FileName + pageUniqueDt]);
                drAttachments[AttachmentVar.FilePath] = Convert.ToString(Page.Session[AttachmentVar.FilePath + pageUniqueDt]);
                drAttachments[AttachmentVar.FileGUID] = Convert.ToString(Page.Session[AttachmentVar.FileGUID + pageUniqueDt]);

                dtableAttachmentArray.Rows.Add(drAttachments);
            }
            /// --- Removing Page.Session --- ///
            Page.Session[AttachmentVar.FileName + pageUniqueDt] = string.Empty;
            Page.Session[AttachmentVar.FileGUID + pageUniqueDt] = string.Empty;
            Page.Session[AttachmentVar.FilePath + pageUniqueDt] = string.Empty;

            return dtableAttachmentArray;
        }

        public DataTable AddAttachment(HttpPostedFile flInsertFile, DataTable dt, string QueryStringRowIndex)
        {
            try
            {
                //SPUtility.ValidateFormDigest();
                //SPSecurity.RunWithElevatedPrivileges(delegate()
                //{
                Stream strmStream = flInsertFile.InputStream;
                Int32 intFileLength = (Int32)strmStream.Length;
                byte[] file = new byte[intFileLength + 1];
                strmStream.Read(file, 0, intFileLength);
                strmStream.Close();
                string FileName = new FileInfo(flInsertFile.FileName).Name;
                string GetTempFolder = Path.GetTempPath();
                string FilePath = GetTempFolder + DateTime.Now.ToString("yy_MM_dd_HH_mm_ss_fff_") + FileName;
                string Index = string.Empty;
                if (!System.IO.File.Exists(FilePath))
                {
                    File.WriteAllBytes(FilePath, file);
                }

                //foreach (DataRow drw in dt.Rows) 
                //{
                //    if (!string.IsNullOrEmpty(Convert.ToString(drw[AttachmentVar.Index]))) 
                //    {
                //        Index = Convert.ToString(drw[AttachmentVar.Index]);
                //        break;
                //    }
                //}
                DataRow dr = null;
                dr = dt.NewRow();
                dr[AttachmentVar.ID] = Convert.ToString(Guid.NewGuid());
                dr[AttachmentVar.OperationalStatus] = "New";
                dr[AttachmentVar.FileName] = FileName;
                dr[AttachmentVar.FilePath] = FilePath;
                dr[AttachmentVar.RowIndex] = QueryStringRowIndex;
                // dr[AttachmentVar.Index] = Index;
                //  dr["DeleteStatus"] = "0";
                dt.Rows.Add(dr);
                // reslt = string.Empty;

                try
                {
                    if (!System.IO.File.Exists(FilePath))
                    {
                        File.Delete(FilePath);
                    }
                }
                catch (Exception ex)
                {
                    Common.ErrorLog(Type.Error, "VEDAssessment : AddAttachment_1", "", "", loginName, executionContext, ex, RequestType.Portal);
                }

                //  });

            }

            catch (Exception ex)
            {
                Common.ErrorLog(Type.Error, "VEDAssessment : AddAttachment_2", "", "", loginName, executionContext, ex, RequestType.Portal);
                return dt = null;

            }
            return dt;

        }

        private static void FillAttachmentGrid(GridView grdAttachments, DataTable dtableAttachmentArray)
        {
            if (dtableAttachmentArray.Rows.Count > 0)
            {
                DataTable AttachmentPPTable = dtableAttachmentArray;

                var GetPPDt = AttachmentPPTable.AsEnumerable()
                            .Where(r => r.Field<string>(AttachmentVar.OperationalStatus) != Convert.ToString("TempDelete")
                                && r.Field<string>(AttachmentVar.OperationalStatus) != Convert.ToString("TempDelete|")
                                && r.Field<string>(AttachmentVar.OperationalStatus) != Convert.ToString("Delete")
                                && !string.IsNullOrEmpty(r.Field<string>(AttachmentVar.OperationalStatus)));

                if (GetPPDt.Any())
                {
                    AttachmentPPTable = GetPPDt.CopyToDataTable();
                    grdAttachments.DataSource = AttachmentPPTable;
                    grdAttachments.DataBind();
                }
                else
                {
                    grdAttachments.DataSource = null;
                    grdAttachments.DataBind();
                }
            }
            else
            {
                grdAttachments.DataSource = null;
                grdAttachments.DataBind();
            }
        }

        public DataTable BOInsertColumn(string columnName, string columnValue, DataTable dtableData)
        {
            /*  Create new DataTable if dtableData is null  */
            if (dtableData == null)
            {
                dtableData = new DataTable();
                //dtableData.Rows.Add(dtableData.NewRow());   /*  Because First Row is Empty row for all DataTables - will be deleted while 'InsertData'   */
            }

            if (dtableData.Rows.Count < 1)
            {
                //dtableData.Rows.Add(dtableData.NewRow());
                //goto addRow; 
            }

            /*  Check if column already exist   */
            if (!dtableData.Columns.Contains(columnName))
            { dtableData.Columns.Add(new DataColumn(columnName)); }

            /*  Set the columnValue to all Rows if columnValue is not NULL  */
            if (columnValue != null)
            {
                try
                {
                    foreach (DataRow drData in dtableData.Rows)
                    {
                        drData[columnName] = columnValue;
                    }
                }
                catch (Exception)
                { dtableData = null; }
            }

            return dtableData;
        }

        protected void lbdeleteFile_Click(object sender, EventArgs e)
        {
            try
            {
                GridViewRow row = (sender as LinkButton).NamingContainer as GridViewRow;


                int rindex = (((GridViewRow)(((LinkButton)(sender)).Parent.Parent.Parent.Parent.BindingContainer))).RowIndex;
                Label lblFilePath = (Label)row.FindControl("lblFilePath") as Label;
                //Label lblID = (Label)row.FindControl("lblID") as Label;
                Label lblRowIndex = (Label)row.FindControl("lblRowIndex") as Label;
                // GridView grdAttachments = ((GridView)grdAssessment.Rows[(Convert.ToInt32(lblRowIndex.Text.Trim())) - 1].FindControl("grdAttachments"));
                GridView grdAttachments = ((GridView)grdAssessment.Rows[rindex].FindControl("grdAttachments"));
                //Label lblRowID = (Label)grdAssessment.Rows[(Convert.ToInt32(lblRowIndex.Text.Trim()))].FindControl("lblRowID");
                Label lblRowID = lblRowIndex; //(Label)grdAssessment.Rows[(Convert.ToInt32(lblRowIndex.Text.Trim())) - 1].FindControl("lblRowID");

                DataTable dtAttachment = (DataTable)Page.Session[AttachmentVar.Attachment + lblRowID.Text.Trim()];
                // DataTable dtAttachment = (DataTable)Page.Session[AttachmentVar.Attachment + lblRowIndex.Text.Trim()];
                int pageID = (Convert.ToInt32(lblRowID.Text));
                lblPageId.Text = Convert.ToString(pageID);
                #region Delete the file

                if (dtAttachment != null)
                {
                    if (grdAssessment != null)
                    {
                        grdAssessment.HeaderRow.TableSection = TableRowSection.TableHeader;
                    }

                    for (int i = 1; i <= dtAttachment.Rows.Count; i++)
                    {
                        if (i == (Convert.ToInt32(row.RowIndex) + 1))
                        {
                            #region Get File Information From Datatable
                            string[] AFilePath = Convert.ToString(dtAttachment.Rows[i - 1][AttachmentVar.FilePath]).Split('|');
                            string[] AOperationalStatus = Convert.ToString(dtAttachment.Rows[i - 1][AttachmentVar.OperationalStatus]).Split('|');
                            #endregion

                            string FilePath = string.Empty, OperationalStatus = string.Empty;
                            for (int j = 0; j < AOperationalStatus.Length - 1; j++)
                            {
                                #region Change the File Operational Status Based on the File Type
                                if (AFilePath[j].Equals(lblFilePath.Text))
                                {
                                    if (AOperationalStatus[j].Equals("New"))
                                    {
                                        OperationalStatus += "Delete" + "|";
                                    }
                                    else if (AOperationalStatus[j].Equals("Update"))
                                    {
                                        OperationalStatus += "TempDelete" + "|";
                                    }
                                    else
                                    {
                                        OperationalStatus += AOperationalStatus[j] + "|";
                                    }
                                }
                                else
                                {
                                    OperationalStatus += AOperationalStatus[j] + "|";
                                }
                                #endregion
                            }

                            if (AOperationalStatus[0].Equals("Update"))
                            {
                                OperationalStatus += "TempDelete" + "|";
                                dtAttachment.Rows[i - 1][AttachmentVar.OperationalStatus] = OperationalStatus;
                            }
                            else
                            {
                                if (grdAttachments.Rows.Count == 1) // This is to delete attach if there are more than 1
                                {
                                    if (Convert.ToString(dtAttachment.Rows[dtAttachment.Rows.Count - 1][AttachmentVar.OperationalStatus]).Equals("Update") || Convert.ToString(dtAttachment.Rows[dtAttachment.Rows.Count - 1][AttachmentVar.OperationalStatus]).Equals("New"))
                                    {
                                        dtAttachment.Rows[dtAttachment.Rows.Count - 1][AttachmentVar.OperationalStatus] = "TempDelete" + "|";
                                    }
                                }
                                else
                                {
                                    dtAttachment.Rows[i - 1][AttachmentVar.OperationalStatus] = OperationalStatus;
                                    dtAttachment.Rows[i - 1].Delete();
                                }
                            }

                            //if (row.RowIndex == 0)
                            //{
                            //    //dtAttachment.Rows[dtAttachment.Rows.Count][AttachmentVar.OperationalStatus] = OperationalStatus;
                            //}


                            //dtAttachment.Rows[i - 1].Delete();
                            break;
                        }
                    }
                }
                #endregion

                Page.Session[AttachmentVar.Attachment + lblRowID.Text.Trim()] = dtAttachment;

                FillAttachmentGrid(grdAttachments, dtAttachment);
            }
            catch (Exception ex)
            {
                string ErrorLog = ex.Message + "\n\n" + ex.StackTrace + "lbdeleteFile_Click";
                Common.ErrorLog(Type.Error, "VEDAssessment : lbdeleteFile_Click", "", "", loginName, executionContext, ex, RequestType.Portal);
                //  sbErrorMessage.AppendLine(ErrorLog);
            }

        }

        protected void grdAttachments_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            #region Attachment Logic

            //if (!string.IsNullOrEmpty(Convert.ToString(drCheckPoints[0]["FileName"])))
            //{
            //    GridView grdAttachments = ((GridView)e.Row.FindControl("grdAttachments"));
            //    processGridAttachment(Convert.ToInt32(lblRowIID.Text.Trim()), drCheckPoints[0], grdAttachments);
            //}

            #endregion
        }

        protected void grdAssessmentReadOnly_RowDataBound(object sender, GridViewRowEventArgs e)
        {

            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                bool isImageAvailable = Convert.ToBoolean(e.Row.Cells[5].Text);

                if (!isImageAvailable)
                {
                    LinkButton lnk = (LinkButton)e.Row.FindControl("lnkViewImage");
                    lnk.Visible = false;
                }
            }



        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            hdnType.Value = "2";
            string request = "VEDID : " + HttpContext.Current.Request.QueryString["vedid"].ToString();

            string body = string.Empty;
            //Getting Mail details
            DataSet ds = Common.GettingMailDetails(HttpContext.Current.Request.QueryString["vedid"].ToString(), loginName, executionContext, RequestType.Portal);

            ServiceResult<VEDScore> results = null;
            try
            {
                if (HttpContext.Current.Request.QueryString["vedid"].ToString() != string.Empty)
                {
                    List<AssesstmentDetails> details = new List<AssesstmentDetails>();
                    List<MailData> mailDetails = new List<MailData>();
                    List<DTO.Image> images = new List<DTO.Image>();

                    foreach (GridViewRow row in grdAssessment.Rows)
                    {
                        AssesstmentDetails detail = new AssesstmentDetails();

                        detail.VEDScheduleID = Convert.ToInt32(HttpContext.Current.Request.QueryString["vedid"]); //Need to Get the same from  Query String
                        // detail.AssessmentDate = Convert.ToDateTime(DateTime.Now.ToString("MM/dd/yyyy h:mm"));
                        detail.AssessmentDoneBy = loginName;
                        detail.FacilityAreaID = Convert.ToInt32(((Label)row.FindControl("lblFacilityAreaID")).Text);
                        detail.FacilityDetailsID = Convert.ToInt32(((Label)row.FindControl("lblFacilityDetailsID")).Text);
                        detail.Condition = ((DropDownList)row.FindControl("ddlCondition")).SelectedValue;
                        detail.Comments = ((TextBox)row.FindControl("txtComments")).Text;
                        detail.CriticalityID = Convert.ToInt32(((Label)row.FindControl("lblCriticalityID")).Text);
                        detail.Criticality = ((Label)row.FindControl("lblCriticality")).Text;
                        //  detail.AssessmentType = AssessmentType.AreaLevel;
                        details.Add(detail);
                        if ((detail.Criticality.ToUpper() == "VITAL" || detail.Criticality.ToUpper() == "ESSENTIAL") && detail.Condition.ToUpper() == "POOR")
                        {
                            MailData mailDetail = new MailData();
                            mailDetail.Zone = ds.Tables[0].Rows[0]["Zone"].ToString();
                            mailDetail.State = ds.Tables[0].Rows[0]["State"].ToString();
                            mailDetail.City = ds.Tables[0].Rows[0]["city"].ToString();
                            mailDetail.Center = ds.Tables[0].Rows[0]["CEnter"].ToString();
                            mailDetail.ScheduleBy = ds.Tables[0].Rows[0]["Created By"].ToString();
                            mailDetail.FacilityArea = ((Label)row.FindControl("lblFacilityArea")).Text;
                            mailDetail.FacilityDetails = ((Label)row.FindControl("lblFacilityDetails")).Text;
                            mailDetail.ID = ((Label)row.FindControl("lblRowID")).Text;
                            mailDetail.AssessmentCondition = "Poor";
                            mailDetail.StateHeadID = ds.Tables[0].Rows[0]["StateHeadID"].ToString();
                            mailDetail.Comments = detail.Comments;
                            mailDetail.VEDScheduleID = detail.VEDScheduleID;
                            mailDetails.Add(mailDetail);
                        }

                        //Saving the Images
                        Label lblRowID = (Label)row.FindControl("lblRowID");
                        Label lblCheckPointId = (Label)row.FindControl("lblIndex");
                        // int CheckPointID = Convert.ToInt32(lblCheckPointId.Text);
                        DataTable dtRowAttach = (DataTable)Page.Session[AttachmentVar.Attachment + lblRowID.Text.Trim()];


                        GridView grdAttachments = ((GridView)(row.FindControl("grdAttachments")));
                        if (dtRowAttach != null)
                        {
                            foreach (DataRow dr in dtRowAttach.Rows)
                            {
                                if (Convert.ToString(dr[AttachmentVar.OperationalStatus]).Equals("New"))
                                {
                                    DTO.Image image = new DTO.Image();
                                    string fileName = dr[AttachmentVar.FileName].ToString();
                                    string strFilepath = dr[AttachmentVar.FilePath].ToString();
                                    StreamReader sr = new StreamReader(strFilepath);
                                    Stream fStream = sr.BaseStream;
                                    byte[] contents;
                                    contents = new byte[fStream.Length];
                                    fStream.Read(contents, 0, (int)fStream.Length);
                                    fStream.Close();
                                    //listItem.Attachments.Add(fileName, contents);
                                    image.ImageName = fileName;
                                    image.ImageContent = Convert.ToBase64String(contents); //Encoding.ASCII.GetString(contents); //Encoding.UTF8.GetString(B);
                                    image.FacilityDetailsID = detail.FacilityDetailsID;
                                    image.VEDScheduleID = detail.VEDScheduleID;
                                    image.AssessmentDoneBy = loginName;
                                    images.Add(image);
                                }
                            }

                        }
                    }
                    if (Page.Request.QueryString["Type"] != null)
                    {
                        string assessmentType = Page.Request.QueryString["Type"].ToString();
                        if (assessmentType == "2")
                        {
                            results = BL.SaveAsessmentDetails_Web(details, executionContext, loginName, RequestType.Portal, AssessmentType.StateLevel);


                        }
                        else if (assessmentType == "3")
                        {
                            results = BL.SaveAsessmentDetails_Web(details, executionContext, loginName, RequestType.Portal, AssessmentType.ZoneLevel);

                        }
                        else
                        {
                            results = BL.SaveAsessmentDetails_Web(details, executionContext, loginName, RequestType.Portal, AssessmentType.AreaLevel);

                        }
                    }
                    else
                    {
                        results = BL.SaveAsessmentDetails_Web(details, executionContext, loginName, RequestType.Portal, AssessmentType.AreaLevel);
                    }
                    executionContext = results.ExecutionContext;
                    if (results.ErrorCode == "1")
                    {
                        ServiceResult imageResults = BL.UploadAssessmentImages_Web(images, executionContext, loginName, RequestType.Portal);
                        executionContext = imageResults.ExecutionContext;
                        //TODO : Uncomment before going Live
                        Common.SendPoorMail(mailDetails, loginName, executionContext, RequestType.Portal);
                    }

                    if (results.ErrorCode == "1")
                    {
                        //grdAssessment.Visible = false;
                        assessmentDiv.Visible = false;
                        vedScoreDiv.Visible = true;
                        vedScoreAssessmentDiv.Visible = false;
                        backDiv.Visible = true;
                        buttonDiv.Visible = false;
                        double totalCount = results.Data.Desirable + results.Data.Essential + results.Data.Vital;
                        lblDesirableCount.Text = results.Data.Desirable.ToString() + "(" + ((results.Data.Desirable / totalCount) * 100).ToString("#.##") + "%)";
                        lblEssentialCount.Text = results.Data.Essential.ToString() + "(" + ((results.Data.Essential / totalCount) * 100).ToString("#.##") + "%)";
                        lblVitalCount.Text = results.Data.Vital.ToString() + "(" + ((results.Data.Vital / totalCount) * 100).ToString("#.##") + "%)";
                        lblTotalCount.Text = totalCount.ToString();
                        lblVEDScore.Text = results.Data.VEDSCORE.ToString();
                        lblMaxVEDScore.Text = results.Data.MAXVEDSCORE.ToString();
                        lblPerVED.Text = ((results.Data.VEDSCORE / results.Data.MAXVEDSCORE) * 100).ToString("#.##") + "%";
                    }
                    else
                    {
                        Common.ErrorLog(Type.Information, "VEDAssessment : btnSave_Click", request, JsonConvert.SerializeObject(results), loginName, executionContext, null, RequestType.Portal);
                    }
                }
            }
            catch (Exception ex)
            {
                lblError.Text = "Oops Something went wrong. Error Code : " + executionContext;
                Common.ErrorLog(Type.Information, "VEDAssessment : btnSave_Click", request, JsonConvert.SerializeObject(results), loginName, executionContext, null, RequestType.Portal);

            }
            Page.Session.Clear();

        }



        //protected void btnDemoUpload_Click(object sender, EventArgs e)
        //{
        //    string connectionString = "Data Source=SP13DEVDB01;Initial Catalog=VEDDB;User Id=veduser;Password =pass@123";


        //    if (fileDemo.HasFile)
        //    {
        //        byte[] theImage = new byte[fileDemo.PostedFile.ContentLength];
        //        HttpPostedFile image = fileDemo.PostedFile;
        //        image.InputStream.Read(theImage, 0, (int)fileDemo.PostedFile.ContentLength);
        //        int length = theImage.Length;
        //        string type = fileDemo.PostedFile.ContentType;
        //        int size = fileDemo.PostedFile.ContentLength;
        //        string fileName = fileDemo.FileName.ToString();


        //        using (SqlConnection conn = new SqlConnection(connectionString))
        //        {
        //            conn.Open();
        //            SqlCommand cmd = new SqlCommand();
        //            cmd.Connection = conn;
        //            cmd.CommandType = CommandType.StoredProcedure;
        //            cmd.CommandText = "usp_InsertUpdateAssessmentImages_1";

        //            SqlParameter[] param = new SqlParameter[4];
        //            param[0] = new SqlParameter("@VEDScheduleID", SqlDbType.Int);
        //            param[0].Value = 1;
        //            param[1] = new SqlParameter("@FacilityDetailID", SqlDbType.Int);
        //            param[1].Value = 1;
        //            param[2] = new SqlParameter("@Image", SqlDbType.Image);
        //            param[2].Value = theImage;
        //            param[3] = new SqlParameter("@ImageName", SqlDbType.VarChar, 500);
        //            param[3].Value = fileName;
        //            cmd.Parameters.AddRange(param);
        //            int rowsAffected = cmd.ExecuteNonQuery();
        //        }


        //    }

        //}

        protected void grdAssessment_DataBound(object sender, EventArgs e)
        {
            //GridViewRow row = new GridViewRow(0, 0, DataControlRowType.Header, DataControlRowState.Normal);
            //TableHeaderCell cell = new TableHeaderCell();
            //cell.Text = "";
            //cell.ColumnSpan = 2;
            //row.Controls.Add(cell);

            //cell = new TableHeaderCell();
            //cell.ColumnSpan = 2;
            //cell.Text = "Facility";
            //row.Controls.Add(cell);

            //cell = new TableHeaderCell();
            //cell.ColumnSpan = 1;
            //cell.Text = "Points";
            //row.Controls.Add(cell);

            //cell = new TableHeaderCell();
            //cell.ColumnSpan = 2;
            //cell.Text = "";
            //row.Controls.Add(cell);
            //grdAssessment.HeaderRow.Parent.Controls.AddAt(0, row);
            for (int i = grdAssessment.Rows.Count - 1; i > 0; i--)
            {
                GridViewRow row1 = grdAssessment.Rows[i];
                GridViewRow previousRow = grdAssessment.Rows[i - 1];
                //for (int j = 0; j < row.Cells.Count; j++)
                //{
                int j = 1;
                if (row1.Cells[1].Text == previousRow.Cells[1].Text)
                {
                    if (previousRow.Cells[j].RowSpan == 0)
                    {
                        if (row1.Cells[j].RowSpan == 0)
                        {
                            previousRow.Cells[j].RowSpan += 2;
                        }
                        else
                        {
                            previousRow.Cells[j].RowSpan = row1.Cells[j].RowSpan + 1;
                        }
                        row1.Cells[j].Visible = false;
                    }
                }
                //}
            }
        }

        protected void grdAssessmentReadOnly_DataBound(object sender, EventArgs e)
        {
            for (int i = grdAssessmentReadOnly.Rows.Count - 1; i > 0; i--)
            {
                GridViewRow row1 = grdAssessmentReadOnly.Rows[i];
                GridViewRow previousRow = grdAssessmentReadOnly.Rows[i - 1];
                //for (int j = 0; j < row.Cells.Count; j++)
                //{
                int j = 0;
                if (row1.Cells[0].Text == previousRow.Cells[0].Text)
                {
                    if (previousRow.Cells[j].RowSpan == 0)
                    {
                        if (row1.Cells[j].RowSpan == 0)
                        {
                            previousRow.Cells[j].RowSpan += 2;
                        }
                        else
                        {
                            previousRow.Cells[j].RowSpan = row1.Cells[j].RowSpan + 1;
                        }
                        row1.Cells[j].Visible = false;
                    }
                }
                //}
            }
        }

        protected void btnCancel_Click(object sender, EventArgs e)
        {
            //Page.Response.Redirect("/sites/rcs/jcved/pages/Create-schedule.aspx", true);
            Page.Response.Redirect(SPUrlUtility.CombineUrl(SPContext.Current.Web.Url, "pages/Create-schedule.aspx"), true);
        }

        protected void btnBack_Click(object sender, EventArgs e)
        {

            if (Page.Request.QueryString["utype"] != null)
            {
                Page.Response.Redirect(SPUrlUtility.CombineUrl(SPContext.Current.Web.Url, "pages/Create-schedule.aspx"), true);
            }
            else if (Page.Request.QueryString["Type"] != null)
            {
                Page.Response.Redirect(SPUrlUtility.CombineUrl(SPContext.Current.Web.Url, "pages/VED-Schedule-Management.aspx"), true);
            }
            else
            {
                Page.Response.Redirect(SPUrlUtility.CombineUrl(SPContext.Current.Web.Url, "pages/home.aspx"), true);
            }
        }

        protected void grdCentersDetails_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdCentersDetails.PageIndex = e.NewPageIndex;
            List<VEDFinalData> finalData = (List<VEDFinalData>)ViewState["VEDSchedules"];
            grdCentersDetails.DataSource = finalData.ToList();
            grdCentersDetails.DataBind();

        }

        protected void btnExportToExcel_Click(object sender, EventArgs e)
        {
            string[] arr = null;
            arr = new string[1];
            arr[0] = "VEDScheduledID=" + HttpContext.Current.Request.QueryString["vedid"].ToString();
            ServiceResult<Generic> results = BL.GenericMethod("usp_GetAssessmentDetailsByVEDSchedulesID", executionContext, loginName, RequestType.Portal, arr);
            DataSet ds = JsonConvert.DeserializeObject<DataSet>(results.Data.ResultData);
            //usp_Report_GetImages
            DataTable dt = ds.Tables[0];
            DataTable dt1 = ds.Tables[1];
            //dt.Columns.Remove("FacilityID");
            //dt.Columns.Remove("IsImageAvailable");
            //dt.Columns.Remove("VEDScheduleID");
            string strHtmlTable = "";

            //////HttpContext.Current.Response.Write("<Table border='1' bgColor='#ffffff' " +
            //////  "borderColor='#000000' cellSpacing='0' cellPadding='0' " +
            //////  "style='font-size:10.0pt; font-family:Calibri; background:white;'> <TR>");


            strHtmlTable = "<Table border='1' bgColor='#ffffff' " +
              "borderColor='#000000' cellSpacing='0' cellPadding='0' " +
              "style='font-size:10.0pt; font-family:Calibri; background:white;'>";
            strHtmlTable += "<tr><th>FacilityArea</th><th>FaciltyDetails</th><th>Criticality</th><th>Condition</th><th>Comments</th><th>Images</th></tr>";
            string siteURL = Convert.ToString(ConfigurationManager.AppSettings["siteURL"]);
            foreach (DataRow row in dt.Rows)
            {
                strHtmlTable += "<tr>";
                for (int i = 0; i < dt.Columns.Count; i++)
                {

                    if (i == 5)
                    {
                        strHtmlTable += "<td>";
                        bool isImageAvailable = Convert.ToBoolean(row[i]);
                        if (isImageAvailable)
                        {
                            strHtmlTable += "<a href=" + SPContext.Current.Web.Url + "/Pages/view-images.aspx?VEDID=" + row[7].ToString() + "&facilityAreaID=" + row[6].ToString() + ">ViewImages</a>";//
                        }
                        else
                        {
                            strHtmlTable += "No Images";
                        }
                        strHtmlTable += "</td>";

                    }
                    else if (i == 3)
                    {

                        //?VEDID=27
                        strHtmlTable += "<td>";
                        string condition = Convert.ToString(row[i]);
                        if (condition.ToUpper() == "POOR")
                        {
                            strHtmlTable += "<a href=" + SPContext.Current.Web.Url + "/pages/Poor-Assessment.aspx?VEDID=" + row[7].ToString() + ">" + row[i].ToString() + "</a>";//
                        }
                        else
                        {
                            strHtmlTable += row[i].ToString();
                        }
                        strHtmlTable += "</td>";


                    }
                    else if (i == 6 || i == 7)
                    {
                        continue;
                    }
                    else
                    {
                        strHtmlTable += "<td>";
                        strHtmlTable += row[i].ToString();
                        strHtmlTable += "</td>";
                    }

                }
            }

            strHtmlTable += "</tr>";
            //strHtmlTable += "<tr><td><a href='http://sp13devwfe01:19999/_LAYOUTS/15/VEDHandler/image.ashx?ID=14'>ViewImages</a></td></tr>";
            strHtmlTable += "</table>";
            strHtmlTable += "<BR><BR><BR>";
            strHtmlTable += "<Table border='1' bgColor='#ffffff' " +
         "borderColor='#000000' cellSpacing='0' cellPadding='0' " +
         "style='font-size:10.0pt; font-family:Calibri; background:white;'>";


            strHtmlTable += "<tr><th>ScheduledOn</th><th>ScheduledBy</th><th>ActualAssesstmentDate</th><th>Center</th><th>Zone</th>";
            strHtmlTable += "<th>City</th><th>OfficeType</th><th>VitalCount</th><th>EssentialCount</th>";
            strHtmlTable += "<th>DesirableCount</th><th>VitalNotApplicable</th><th>EssentialNotApplicable</th><th>DesirableNotApplicable</th><th>TotalVEDByType</th><th>VEDScore</th>";
            strHtmlTable += "<th>MAXVEDScore</th><th>VEDPerScore</th><th>VEDScheduledFrom</th><th>AssessmentDoneFrom</th></tr>";

            foreach (DataRow row in dt1.Rows)
            {//write in new row
                strHtmlTable += "<tr>";
                for (int i = 0; i < dt1.Columns.Count; i++)
                {
                    strHtmlTable += "<td>";
                    strHtmlTable += row[i].ToString();
                    strHtmlTable += "</td>";
                }
            }
            strHtmlTable += "</tr>";
            //strHtmlTable += "<tr><td><a href='http://sp13devwfe01:19999/_LAYOUTS/15/VEDHandler/image.ashx?ID=14'>ViewImages</a></td></tr>";
            strHtmlTable += "</table>";
            string centerName = "JCVEDReport";
            if (dt1.Rows.Count > 0)
            {
                DataRow row1 = dt1.Rows[0];
                centerName = row1["Center"].ToString();
            }
            string fileName = centerName + "_" + DateTime.Now.Day + "_" + DateTime.Now.Month + "_" + DateTime.Now.Year + ".xls";
            this.Page.Response.AppendHeader("content-disposition", "attachment;filename=" + fileName + "");
            this.Page.Response.Charset = "";
            this.Page.Response.Cache.SetCacheability(HttpCacheability.NoCache);
            this.Page.Response.ContentType = "application/vnd.ms-excel";
            this.EnableViewState = false;
            this.Page.Response.Write(strHtmlTable);
            this.Page.Response.End();


            //////string[] arr = null;
            //////arr = new string[1];
            //////arr[0] = "VEDScheduledID=" + HttpContext.Current.Request.QueryString["vedid"].ToString();
            //////ServiceResult<Generic> results = BL.GenericMethod("usp_GetAssessmentDetailsByVEDSchedulesID", executionContext, loginName, RequestType.Portal, arr);
            //////DataSet ds = JsonConvert.DeserializeObject<DataSet>(results.Data.ResultData);
            ////////usp_Report_GetImages
            //////DataTable dt = ds.Tables[0];
            //////DataTable dt1 = ds.Tables[1];
            //////dt.Columns.Remove("FacilityID");
            //////dt.Columns.Remove("IsImageAvailable");
            //////dt.Columns.Remove("VEDScheduleID");
            //////HttpContext.Current.Response.Clear();
            //////HttpContext.Current.Response.ClearContent();
            //////HttpContext.Current.Response.ClearHeaders();
            //////HttpContext.Current.Response.Buffer = true;
            //////HttpContext.Current.Response.ContentType = "application/ms-excel";
            //////HttpContext.Current.Response.Write(@"<!DOCTYPE HTML PUBLIC ""-//W3C//DTD HTML 4.0 Transitional//EN"">");
            //////HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment;filename=Reports.xls");

            //////HttpContext.Current.Response.Charset = "utf-8";
            //////HttpContext.Current.Response.ContentEncoding = System.Text.Encoding.GetEncoding("windows-1250");
            ////////sets font
            //////HttpContext.Current.Response.Write("<font style='font-size:10.0pt; font-family:Calibri;'>");
            //////HttpContext.Current.Response.Write("<BR><BR><BR>");
            ////////sets the table border, cell spacing, border color, font of the text, background, foreground, font height
            //////HttpContext.Current.Response.Write("<Table border='1' bgColor='#ffffff' " +
            //////  "borderColor='#000000' cellSpacing='0' cellPadding='0' " +
            //////  "style='font-size:10.0pt; font-family:Calibri; background:white;'> <TR>");
            ////////am getting my grid's column headers
            ////////  int columnscount = GridView_Result.Columns.Count;

            //////foreach (DataColumn dc in dt.Columns)
            //////{
            //////    //Page.Response.Write(tab + dc.ColumnName);
            //////    //tab = "\t";

            //////    HttpContext.Current.Response.Write("<Td>");
            //////    //Get column headers  and make it as bold in excel columns
            //////    HttpContext.Current.Response.Write("<B>");
            //////    HttpContext.Current.Response.Write(dc.ColumnName);
            //////    HttpContext.Current.Response.Write("</B>");
            //////    HttpContext.Current.Response.Write("</Td>");
            //////}


            ////////for (int j = 0; j < columnscount; j++)
            ////////{      //write in new column
            ////////    HttpContext.Current.Response.Write("<Td>");
            ////////    //Get column headers  and make it as bold in excel columns
            ////////    HttpContext.Current.Response.Write("<B>");
            ////////    HttpContext.Current.Response.Write(GridView_Result.Columns[j].HeaderText.ToString());
            ////////    HttpContext.Current.Response.Write("</B>");
            ////////    HttpContext.Current.Response.Write("</Td>");
            ////////}
            //////HttpContext.Current.Response.Write("</TR>");
            //////foreach (DataRow row in dt.Rows)
            //////{//write in new row
            //////    HttpContext.Current.Response.Write("<TR>");
            //////    for (int i = 0; i < dt.Columns.Count; i++)
            //////    {
            //////        HttpContext.Current.Response.Write("<Td>");
            //////        if (i == 5)
            //////        {
            //////            HttpContext.Current.Response.Write(GetHyperlink(row[i].ToString()));
            //////        }
            //////        else
            //////        {
            //////            HttpContext.Current.Response.Write(row[i].ToString());
            //////        }



            //////        HttpContext.Current.Response.Write("</Td>");
            //////    }

            //////    HttpContext.Current.Response.Write("</TR>");
            //////}
            //////HttpContext.Current.Response.Write("</Table>");


            //////HttpContext.Current.Response.Write("<BR><BR><BR>");
            ////////sets the table border, cell spacing, border color, font of the text, background, foreground, font height
            //////HttpContext.Current.Response.Write("<Table border='1' bgColor='#ffffff' " +
            //////  "borderColor='#000000' cellSpacing='0' cellPadding='0' " +
            //////  "style='font-size:10.0pt; font-family:Calibri; background:white;'> <TR>");

            //////foreach (DataColumn dc in dt1.Columns)
            //////{
            //////    //Page.Response.Write(tab + dc.ColumnName);
            //////    //tab = "\t";

            //////    HttpContext.Current.Response.Write("<Td>");
            //////    //Get column headers  and make it as bold in excel columns
            //////    HttpContext.Current.Response.Write("<B>");
            //////    HttpContext.Current.Response.Write(dc.ColumnName);
            //////    HttpContext.Current.Response.Write("</B>");
            //////    HttpContext.Current.Response.Write("</Td>");
            //////}


            ////////for (int j = 0; j < columnscount; j++)
            ////////{      //write in new column
            ////////    HttpContext.Current.Response.Write("<Td>");
            ////////    //Get column headers  and make it as bold in excel columns
            ////////    HttpContext.Current.Response.Write("<B>");
            ////////    HttpContext.Current.Response.Write(GridView_Result.Columns[j].HeaderText.ToString());
            ////////    HttpContext.Current.Response.Write("</B>");
            ////////    HttpContext.Current.Response.Write("</Td>");
            ////////}
            //////HttpContext.Current.Response.Write("</TR>");
            //////foreach (DataRow row in dt1.Rows)
            //////{//write in new row
            //////    HttpContext.Current.Response.Write("<TR>");
            //////    for (int i = 0; i < dt1.Columns.Count; i++)
            //////    {
            //////        HttpContext.Current.Response.Write("<Td>");
            //////        HttpContext.Current.Response.Write(row[i].ToString());
            //////        HttpContext.Current.Response.Write("</Td>");
            //////    }

            //////    HttpContext.Current.Response.Write("</TR>");
            //////}
            //////HttpContext.Current.Response.Write("</Table>");




            //////HttpContext.Current.Response.Write("</font>");
            //////HttpContext.Current.Response.Flush();
            //////HttpContext.Current.Response.End();
        }

        private string GetHyperlink(string p)
        {
            string returnAnch = string.Empty;
            returnAnch = "<table   class='ReportTable'   id='tblVEDReport' runat='server' visible='false'>";
            returnAnch += "<tr><th>Links</th></tr>";
            returnAnch += "<tr>";

            if (!string.IsNullOrEmpty(p))
            {
                string[] arr = p.Split(',');

                for (int i = 0; i < arr.Length; i++)
                {
                    returnAnch += "<td><a href='" + arr[i].Trim() + "'>ViewImages</a></td>";

                }
                returnAnch += "</tr>";
                returnAnch += "</table>";

            }
            return returnAnch;
        }
        //protected void btnUpload_Click(object sender, EventArgs e)
        //{
        //    string connectionString = "Data Source=SP13DEVDB01;Initial Catalog=VEDDB;User Id=veduser;Password =pass@123";


        //    if (fileUpload.HasFile)
        //    {
        //        byte[] theImage = new byte[fileUpload.PostedFile.ContentLength];
        //        HttpPostedFile image = fileUpload.PostedFile;
        //        image.InputStream.Read(theImage, 0, (int)fileUpload.PostedFile.ContentLength);
        //        int length = theImage.Length;
        //        string type = fileUpload.PostedFile.ContentType;
        //        int size = fileUpload.PostedFile.ContentLength;
        //        string fileName = fileUpload.FileName.ToString();


        //        using (SqlConnection conn = new SqlConnection(connectionString))
        //        {
        //            conn.Open();
        //            SqlCommand cmd = new SqlCommand();
        //            cmd.Connection = conn;
        //            cmd.CommandType = CommandType.StoredProcedure;
        //            cmd.CommandText = "usp_InsertUpdateAssessmentImages";

        //            SqlParameter[] param = new SqlParameter[8];
        //            param[0] = new SqlParameter("@VEDScheduleID", SqlDbType.Int);
        //            param[0].Value = 1;
        //            param[1] = new SqlParameter("@FacilityDetailID", SqlDbType.Int);
        //            param[1].Value = 1;
        //            param[2] = new SqlParameter("@Image", SqlDbType.Image);
        //            param[2].Value = theImage;
        //            param[3] = new SqlParameter("@CreatedBy", SqlDbType.VarChar, 200);
        //            param[3].Value = "sachin7.jain";
        //            param[4] = new SqlParameter("@Type", SqlDbType.VarChar);
        //            param[4].Value = "Add";
        //            param[5] = new SqlParameter("@ImageType", SqlDbType.NVarChar, 100);
        //            param[5].Value = type;
        //            param[6] = new SqlParameter("@ImageSize", SqlDbType.BigInt);
        //            param[6].Value = length;
        //            param[7] = new SqlParameter("@ImageName", SqlDbType.VarChar, 500);
        //            param[7].Value = fileName;
        //            cmd.Parameters.AddRange(param);
        //            int rowsAffected = cmd.ExecuteNonQuery();
        //        }


        //    }


        //}
        #region FileUploadDemo
        //private void StartUpLoad()
        //{

        //    //get the image file that was posted (binary format)
        //    byte[] theImage = new byte[FileUpload1.PostedFile.ContentLength];
        //    HttpPostedFile Image = FileUpload1.PostedFile;
        //    Image.InputStream.Read(theImage, 0, (int)FileUpload1.PostedFile.ContentLength);
        //    int length = theImage.Length; //get the length of the image
        //    string fileName = FileUpload1.FileName.ToString(); //get the file name of the posted image
        //    string type = FileUpload1.PostedFile.ContentType; //get the type of the posted image
        //    int size = FileUpload1.PostedFile.ContentLength; //get the size in bytes that
        //    if (FileUpload1.PostedFile != null && FileUpload1.PostedFile.FileName != "")
        //    {
        //        //Call the method to execute Insertion of data to the Database
        //        ExecuteInsert(theImage, type, size, fileName, length);
        //        Response.Write("Save Successfully!");
        //    }
        //}

        //public string GetConnectionString()
        //{
        //    //sets the connection string from your web config file "ConnString" is the name of your Connection String
        //    return System.Configuration.ConfigurationManager.ConnectionStrings["MyConsString"].ConnectionString;
        //}

        //private void ExecuteInsert(byte[] Image, string Type, Int64 Size, string Name, int length)
        //{
        //    SqlConnection conn = new SqlConnection(GetConnectionString());
        //    string sql = "INSERT INTO TblImages (Image, ImageType, ImageSize, ImageName) VALUES "

        //                + " (@img,@type,@imgsize,@imgname)";
        //    try
        //    {
        //        conn.Open();
        //        SqlCommand cmd = new SqlCommand(sql, conn);
        //        SqlParameter[] param = new SqlParameter[4];

        //        param[0] = new SqlParameter("@img", SqlDbType.Image, length);
        //        param[1] = new SqlParameter("@type", SqlDbType.NVarChar, 50);
        //        param[2] = new SqlParameter("@imgsize", SqlDbType.BigInt, 9999);
        //        param[3] = new SqlParameter("@imgname", SqlDbType.NVarChar, 50);

        //        param[0].Value = Image;
        //        param[1].Value = Type;
        //        param[2].Value = Size;
        //        param[3].Value = Name;

        //        for (int i = 0; i < param.Length; i++)
        //        {
        //            cmd.Parameters.Add(param[i]);
        //        }

        //        cmd.CommandType = CommandType.Text;
        //        cmd.ExecuteNonQuery();
        //    }
        //    catch (System.Data.SqlClient.SqlException ex)
        //    {
        //        string msg = "Insert Error:";
        //        msg += ex.Message;
        //        throw new Exception(msg);
        //    }
        //    finally
        //    {
        //        conn.Close();
        //    }
        //}

        //protected void Button1_Click(object sender, EventArgs e)
        //{
        //    StartUpLoad();
        //}
        #endregion
   
    }
}
