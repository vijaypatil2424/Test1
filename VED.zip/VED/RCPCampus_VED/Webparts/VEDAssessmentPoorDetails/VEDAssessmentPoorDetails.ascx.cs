﻿using Microsoft.SharePoint;
using Newtonsoft.Json;
using System;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Net.Mail;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using RCPCampus_VED.BusinessLayer;
using RCPCampus_VED.DTO;

namespace RCPCampus_VED.Webparts.VEDAssessmentPoorDetails
{
    [ToolboxItemAttribute(false)]
    public partial class VEDAssessmentPoorDetails : WebPart
    {
        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]
        Business BL = null;
        string executionContext = "";
        string loginName = string.Empty;
        string VEDID = string.Empty;
        public VEDAssessmentPoorDetails()
        {
            BL = new Business();
            executionContext = Guid.NewGuid().ToString();
            loginName = SPContext.Current.Web.CurrentUser.LoginName.Split('\\')[1].ToString();
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            VEDID = Page.Request.QueryString["VEDID"].ToString();
            if (!string.IsNullOrEmpty(VEDID))
            {

                if (!Page.IsPostBack)
                {

                    try
                    {
                        if (!string.IsNullOrEmpty(VEDID))
                        { BindPoorData(VEDID); }
                    }
                    catch (Exception ex)
                    {
                        lblError.Text = "Oops Something went wrong. Error Code : " + executionContext;
                        Common.ErrorLog(Type.Error, "VEDAssessmentPoorDetails : Page_Load", "VEDID : " + VEDID, "", loginName, executionContext, ex, RequestType.Portal);
                    }

                }
            }
        }

        private void BindPoorData(string VEDID)
        {

            try
            {
                ServiceResult<VEDSchedule> scheduleDetail = BL.GetScheduledVEDDetailsByID(VEDID, executionContext, loginName, RequestType.Portal);
                ViewState["VEDSchedule"] = scheduleDetail;
                lblScheduleDate.Text = scheduleDetail.Data.ScheduledOn;
                lblActualDate.Text = scheduleDetail.Data.ActualAssesstmentDate;
                lblCenter.Text = scheduleDetail.Data.Center;
                hdnScheduledBy.Value = scheduleDetail.Data.ScheduledBy;

                string[] arr = new string[1];
                arr[0] = "VEDScheduledID=" + VEDID;
                ServiceResult<Generic> results = BL.GenericMethod("usp_Report_GetAssessmentDetailsByVEDSchedulesIDForPoor", executionContext, loginName, RequestType.Portal, arr);
                DataSet ds = JsonConvert.DeserializeObject<DataSet>(results.Data.ResultData);
                grdAssessmentReadOnly.DataSource = ds.Tables[0];
                grdAssessmentReadOnly.DataBind();
            }
            catch (Exception ex)
            {
                Common.ErrorLog(Type.Error, "VEDAssessmentPoorDetails : BindPoorData", "VEDID : " + VEDID, "", loginName, executionContext, ex, RequestType.Portal);
            }

        }
        protected void btnSendMail_Click(object sender, EventArgs e)
        {

            //try
            //{
            //    GridViewRow row = (sender as Button).NamingContainer as GridViewRow;
            //    string comments = ((TextBox)row.FindControl("txtComments")).Text;
            //    int ID = Convert.ToInt32(grdAssessmentReadOnly.Rows[row.RowIndex].Cells[8].Text);
            //    hdnFacilityArea.Value = Convert.ToString(grdAssessmentReadOnly.Rows[row.RowIndex].Cells[0].Text);
            //    hdnFacilityDetails.Value = Convert.ToString(grdAssessmentReadOnly.Rows[row.RowIndex].Cells[1].Text);
            //    hdnComments.Value = Convert.ToString(grdAssessmentReadOnly.Rows[row.RowIndex].Cells[4].Text);
            //    hdnActualComments.Value = comments;
            //    string emailID = Convert.ToString(grdAssessmentReadOnly.Rows[row.RowIndex].Cells[9].Text);
            //    MailShooting(comments, ID, emailID);
            //    ScriptManager.RegisterStartupScript(Page, Page.GetType(), "script", "alert('Mail sent successfully');", true);
            //}
            //catch (Exception ex)
            //{
            //    Common.ErrorLog(Type.Error, "VEDAssessmentPoorDetails : btnSendMail_Click", "VEDID : " + VEDID, "", loginName, executionContext, ex, RequestType.Portal);
            //}
        }
        private void MailShooting(string comments, int ID, string emailID)
        {

            //try
            //{
            //    //<add key="smtpServer" value="emailsmtp.ril.com" />
            //    //<add key="smtpUser1" value="IT.PMCoE@zmail.ril.com" />
            //    //<add key="smtpUser2" value="it.academy@zmail.ril.com" />

            //    string mailFrom = ConfigurationManager.AppSettings["fromEmail"].ToString();
            //    string smtpServer = ConfigurationManager.AppSettings["smtpServer"].ToString();
            //    string mailSubject = ConfigurationManager.AppSettings["mailSubject"].ToString();
            //    string helpdesk = ConfigurationManager.AppSettings["helpdesk"].ToString();


            //    if (!string.IsNullOrEmpty(mailFrom))
            //    {
            //        MailAddress emailFrom = new MailAddress(mailFrom, SPContext.Current.Web.AllUsers["i:0#.w|in\\" + hdnScheduledBy.Value + ""].Name);
            //        //  emailFrom.DisplayName = 
            //        string body = string.Empty;
            //        string[] arr = new string[1];
            //        arr[0] = "VEDScheduleID=" + VEDID;
            //        ServiceResult<Generic> results = BL.GenericMethod("usp_Report_GetMailDetails", executionContext, loginName, RequestType.Portal, arr);
            //        DataSet ds = JsonConvert.DeserializeObject<DataSet>(results.Data.ResultData);
            //        if (ds.Tables.Count > 0)
            //        {

            //            body = "<span>Kindly create corporate service Help Desk complaint as per following details : </span></br>"
            //                + "<span>Zone : " + ds.Tables[0].Rows[0]["Zone"].ToString() + " </span></br>"
            //                + "<span>State : " + ds.Tables[0].Rows[0]["State"].ToString() + " </span></br>"
            //                + "<span>City : " + ds.Tables[0].Rows[0]["city"].ToString() + " </span></br>"
            //                + "<span>Jio Centre No. : " + ds.Tables[0].Rows[0]["CEnter"].ToString() + " </span></br>"
            //                + "<span>Assessment condition : Poor </span></br>"
            //                  + "<span>Facility Area  : " + hdnFacilityArea.Value + " </span></br>"
            //              + "<span>Facility Details  : " + hdnFacilityDetails.Value + " </span></br>"
            //              + "<span>Assessment comments : " + hdnComments.Value + " </span></br>"
            //               + "<span>Created by : " + ds.Tables[0].Rows[0]["Created On"].ToString() + " </span></br>"
            //               + "<span>Comments : " + hdnActualComments.Value + " </span></br>"
            //               + "</br></br>"
            //               + "<span>Best regards,</span></br>"
            //               + "Jio VED Team</br>";

            //        }
            //        string CCEmail = string.Empty;
            //        if (!string.IsNullOrEmpty(Convert.ToString(ds.Tables[0].Rows[0]["StateHeadID"])))
            //        {
            //            CCEmail = SPContext.Current.Web.AllUsers["i:0#.w|in\\" + ds.Tables[0].Rows[0]["StateHeadID"].ToString() + ""].Email;
            //        }
            //        emailID = SPContext.Current.Web.AllUsers["i:0#.w|in\\" + emailID + ""].Email;
            //        //  emailID += "," + helpdesk;
            //        MailMessage mail = new MailMessage();
            //        mail.IsBodyHtml = true;
            //        mail.From = emailFrom;
            //        mail.To.Add(emailID);
            //        mail.To.Add(helpdesk);
            //        if (!string.IsNullOrEmpty(CCEmail))
            //        {
            //            mail.CC.Add(CCEmail);
            //        }
            //        mail.Subject = mailSubject;
            //        mail.Body = body;
            //        SmtpClient smtp = new SmtpClient(smtpServer);
            //        smtp.UseDefaultCredentials = true;
            //        smtp.Send(mail);
            //        UpdateAssessmentTable(comments, ID, emailID);
            //    }
            //}
            //catch (Exception ex)
            //{

            //    lblError.Text = "Oops Something went wrong. Error Code : " + executionContext;
            //    Common.ErrorLog(Type.Error, "VEDAssessmentPoorDetails : Page_Load", "VEDID : " + VEDID, "", loginName, executionContext, ex, RequestType.Portal);
            //}

        }
        private void UpdateAssessmentTable(string comments, int ID, string mailSentTO)
        {
            string request = "comments=" + comments + " ID=" + ID + "mailSentTO=" + mailSentTO;
            DataSet ds = null;
            try
            {
                string[] arr = new string[5];
                arr[0] = "MailComments=" + comments;
                // arr[1] = "MailSentDate=" + DateTime.Now;
                arr[1] = "MailSentToEmailID=" + mailSentTO;
                arr[2] = "IsMailSent=" + 1;
                arr[3] = "ID=" + ID;
                arr[4] = "UserID=" + loginName;
                ServiceResult<Generic> results = BL.GenericMethod("usp_Report_UpdateMailDetailsBasedOnID", executionContext, loginName, RequestType.Portal, arr);
                ds = JsonConvert.DeserializeObject<DataSet>(results.Data.ResultData);
                BindPoorData(Page.Request.QueryString["VEDID"].ToString());
            }
            catch (Exception ex)
            {

                lblError.Text = "Oops Something went wrong. Error Code : " + executionContext;
                Common.ErrorLog(Type.Error, "VEDAssessmentPoorDetails : UpdateAssessmentTable", request, "", JsonConvert.SerializeObject(ds), executionContext, ex, RequestType.Portal);
            }
        }
        protected void grdAssessmentReadOnly_DataBound(object sender, EventArgs e)
        {
            for (int i = grdAssessmentReadOnly.Rows.Count - 1; i > 0; i--)
            {
                GridViewRow row1 = grdAssessmentReadOnly.Rows[i];
                GridViewRow previousRow = grdAssessmentReadOnly.Rows[i - 1];
                //for (int j = 0; j < row.Cells.Count; j++)
                //{
                int j = 0;
                if (row1.Cells[0].Text == previousRow.Cells[0].Text)
                {
                    if (previousRow.Cells[j].RowSpan == 0)
                    {
                        if (row1.Cells[j].RowSpan == 0)
                        {
                            previousRow.Cells[j].RowSpan += 2;
                        }
                        else
                        {
                            previousRow.Cells[j].RowSpan = row1.Cells[j].RowSpan + 1;
                        }
                        row1.Cells[j].Visible = false;
                    }
                }
                //}
            }
        }

    }
}
