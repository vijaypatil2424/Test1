﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Utilities;
using Newtonsoft.Json;
using System;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using RCPCampus_VED.BusinessLayer;
using RCPCampus_VED.DTO;

namespace RCPCampus_VED.Webparts.VedAuditScheduleManagement
{
    [ToolboxItemAttribute(false)]
    public partial class VedAuditScheduleManagement : WebPart
    {
        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]
        Business BL = null;
        string executionContext = "";
        string loginName = string.Empty;
        bool isMember;
        public VedAuditScheduleManagement()
        {
            BL = new Business();
            //executionContext = Guid.NewGuid().ToString();
            loginName = SPContext.Current.Web.CurrentUser.LoginName.Split('\\')[1].ToString().ToLower();
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            string request = "loginName = " + loginName;
            //string request="loginName="+
            if (!Page.IsPostBack)
            {
                divzone.Visible = false;
                try
                {//GroupName VEDGroupName
                    ClearControl();
                    BindOfficeType();
                    CheckMember();
                    // BindVEDScheduled();
                    BindPreviousAssessment(loginName, hdnType.Value);
                    divAssessment.Visible = false;
                }
                catch (Exception ex)
                {

                    Common.ErrorLog(Type.Error, "VedAuditScheduleManagement : Page_Load", request, "", loginName, executionContext, ex, RequestType.Portal);
                }
            }
        }

        private void CheckMember()
        {
            SPWeb web = SPContext.Current.Web;
            // string groupName = "RCS Owners";
            string groupName = Convert.ToString(ConfigurationManager.AppSettings["GroupName"]);
            SPGroup spGroup = web.Groups[groupName];
            isMember = web.IsCurrentUserMemberOfGroup(spGroup.ID);
            if (isMember == true)
            {
                divzone.Visible = true;
                BindZone();
            }
            else
            {
                BindState(loginName);
            }
        }
        private void BindOfficeType()
        {
            ServiceResult<Generic> results = BL.GetOfficeType("usp_GetOfficeType");
            if (results.Data.ResultData != string.Empty)
            {
                DataSet ds = JsonConvert.DeserializeObject<DataSet>(results.Data.ResultData);
                rdbuttonlist.DataSource = ds.Tables[0];
                rdbuttonlist.DataTextField = "Title";
                rdbuttonlist.DataValueField = "ID";
                rdbuttonlist.DataBind();
                rdbuttonlist.Items.FindByText(ds.Tables[0].Rows[0]["Title"].ToString()).Selected = true;
            }
        }
        private void BindZone()
        {

            ServiceResult<Generic> results = BL.GetZoneData("usp_Audit_GetZones");
            if (results.Data.ResultData != string.Empty)
            {
                DataSet ds = JsonConvert.DeserializeObject<DataSet>(results.Data.ResultData);
                ddlzone.DataSource = ds.Tables[0];
                ddlzone.DataTextField = "Title";
                ddlzone.DataValueField = "ID";
                ddlzone.DataBind();
                //ddlzone.Items.Insert(0, new ListItem("Select Zone", "0"));
                //ddlState.Items.Insert(0, new ListItem("Select State", "0"));
                //ddlArea.Items.Insert(0, new ListItem("Select Area", "0"));
            }
        }
        private void BindState(string loginName)
        {
            string request = "loginName=" + loginName;
            try
            {
                string[] arr = new string[2];
                arr[0] = "UserID=" + loginName;
                arr[1] = "OfficeType=" + rdbuttonlist.SelectedValue.ToString();
                ServiceResult<Generic> results = BL.GenericMethod("usp_Audit_GetStateBasedOnUserID", executionContext, loginName, RequestType.Portal, arr);
                if (results.Data.ResultData != string.Empty)
                {
                    DataSet ds = JsonConvert.DeserializeObject<DataSet>(results.Data.ResultData);

                    hdnType.Value = ds.Tables[0].Rows[0]["Type"].ToString();
                    if (hdnType.Value == "2")//State Head
                    {
                        ddlState.DataSource = ds.Tables[1];
                        ddlState.DataTextField = "Title";
                        ddlState.DataValueField = "ID";


                        //ddlCity.DataSource = ds.Tables[2];
                        //ddlCity.DataTextField = "City";
                        //ddlCity.DataValueField = "City";
                        //ddlCity.DataBind();
                        //ddlCity.Items.Insert(0, new ListItem("Select City", "0")); today's change date 27/03/2018
                        //if (ds.Tables[2].Rows.Count > 0)
                        //{
                        //    ddlArea.Items.Clear();
                        //    ddlArea.DataSource = ds.Tables[2];
                        //    ddlArea.DataTextField = "Area";
                        //    ddlArea.DataValueField = "Area";
                        //    ddlArea.DataBind();

                        //}
                        //ddlArea.Items.Clear();
                        //ddlArea.Items.Insert(0, new ListItem("Select Area", "0"));

                    }
                    else if (hdnType.Value == "3")//Zone Head
                    {
                        ddlState.DataSource = ds.Tables[1];
                        ddlState.DataTextField = "Title";
                        ddlState.DataValueField = "ID";
                        ddlState.Items.Insert(0, new ListItem("Select State", "0"));
                    }
                    else
                    {
                        ddlState.DataSource = null;
                        ddlArea.DataSource = null;
                        ddlArea.DataBind();

                    }
                    ddlState.DataBind();
                    ddlState.Items.Insert(0, new ListItem("Select State", "0"));
                    hdnType.Value = ds.Tables[0].Rows[0]["Type"].ToString();
                    //lblType.Text = hdnType.Value;
                }
            }
            catch (Exception ex)
            {
                Common.ErrorLog(Type.Error, "VedAuditScheduleManagement : BindState", request, "", loginName, executionContext, ex, RequestType.Portal);
            }
        }

        protected void ddlState_SelectedIndexChanged(object sender, EventArgs e)
        {
            string request = "State : " + ddlState.SelectedValue;
            if (ddlState.SelectedValue != "0")
            {
                BindArea(ddlState.SelectedValue);
            }
            else
            {
                lblError.Text = "Please select State";
            }

        }
        private void BindArea(string state)
        {

            try
            {
                string officeType = rdbuttonlist.SelectedItem.Value;
                string[] arr = new string[2];
                arr[0] = "StateID=" + state;
                arr[1] = "OfficeType=" + officeType;
                DataSet ds = null;
                ServiceResult<Generic> results = BL.GenericMethod("usp_Audit_GetAreaBasedOnStateID", executionContext, loginName, RequestType.Portal, arr);
                ds = JsonConvert.DeserializeObject<DataSet>(results.Data.ResultData);
                if (results.Data.ResultData != string.Empty)
                {
                    if (ds.Tables.Count > 0)
                    {
                        ddlArea.DataSource = ds.Tables[0];
                        ddlArea.DataTextField = "Area";
                        ddlArea.DataValueField = "Area";

                    }
                }
                else
                {
                    ddlArea.DataSource = null;
                }
                ddlArea.DataBind();
                ddlArea.Items.Insert(0, new ListItem("Select Area", "0"));
            }
            catch (Exception ex)
            {
                Common.ErrorLog(Type.Error, "ScheduleVEDManagement : BindArea", "", "", loginName, executionContext, ex, RequestType.Portal);
            }

        }

        private void BindCity(string Area)
        {

            try
            {
                string officeType = rdbuttonlist.SelectedItem.Value;
                string[] arr = new string[2];
                arr[0] = "AreaName=" + Area;
                arr[1] = "OfficeType=" + officeType;
                DataSet ds = null;
                ServiceResult<Generic> results = BL.GenericMethod("usp_Audit_GetCityBasedOnStateID", executionContext, loginName, RequestType.Portal, arr);
                ds = JsonConvert.DeserializeObject<DataSet>(results.Data.ResultData);
                if (results.Data.ResultData != string.Empty)
                {
                    if (ds.Tables.Count > 0)
                    {
                        ddlCity.DataSource = ds.Tables[0];
                        ddlCity.DataTextField = "City";
                        ddlCity.DataValueField = "City";

                    }
                }
                else
                {
                    ddlCity.DataSource = null;
                }
                ddlCity.DataBind();
                ddlCity.Items.Insert(0, new ListItem("Select City", "0"));
            }
            catch (Exception ex)
            {
                Common.ErrorLog(Type.Error, "VedAuditScheduleManagement : BindCity", "", "", loginName, executionContext, ex, RequestType.Portal);
            }

        }

        protected void ddlCity_SelectedIndexChanged(object sender, EventArgs e)
        {
            string request = "City : " + ddlCity.SelectedValue;
            if (ddlCity.SelectedValue == "0")
            {
                lblError.Text = "Please select City.";
            }
            else
            {
                try
                {
                    BindCenter(ddlCity.SelectedValue);
                }
                catch (Exception ex)
                {
                    Common.ErrorLog(Type.Error, "VedAuditScheduleManagement : ddlCity_SelectedIndexChanged", request, "", loginName, executionContext, ex, RequestType.Portal);
                }
            }
        }

        private void BindCenter(string city)
        {
            string request = "City : " + city;
            string officeType = rdbuttonlist.SelectedItem.Value;
            try
            {
                string[] arr = new string[3];
                arr[0] = "City=" + city;
                arr[1] = "OfficeType=" + officeType;
                arr[2] = "Area=" + ddlArea.SelectedValue.ToString();
                // arr[1] = "officeCategoryID=" + officeCategoryType;
                ServiceResult<Generic> results = BL.GenericMethod("usp_Audit_GetCenterBasedOnCityIDForView", executionContext, loginName, RequestType.Portal, arr);
                if (results.Data.ResultData != string.Empty)
                {
                    DataSet ds = JsonConvert.DeserializeObject<DataSet>(results.Data.ResultData);
                    if (ds.Tables.Count > 0)
                    {
                        ddlCenters.DataSource = ds.Tables[0];
                        ddlCenters.DataTextField = "Title";
                        ddlCenters.DataValueField = "ID";
                    }
                    else
                    {
                        ddlCenters.DataSource = null;
                    }
                    ddlCenters.DataBind();
                    ddlCenters.Items.Insert(0, new ListItem("Select Center", "0"));
                }
                else
                {
                    ddlCenters.DataSource = null;
                    ddlCenters.DataBind();
                    ddlCenters.Items.Insert(0, new ListItem("Select Center", "0"));
                }

            }
            catch (Exception ex)
            {
                Common.ErrorLog(Type.Error, "VedAuditScheduleManagement : BindCenter", request, "", loginName, executionContext, ex, RequestType.Portal);
            }
        }

        protected void ddlCenters_SelectedIndexChanged(object sender, EventArgs e)
        {
            string request = "loginName=" + loginName;
            try
            {
                // ddlCenters.DataValueField 
                string p = hdnType.Value;
                string ID = ddlCenters.SelectedItem.Value;
                string[] arr = new string[1];
                arr[0] = "CenterID=" + ID + "";

                ServiceResult<Generic> data = BL.GenericMethod("usp_Audit_GetMaxVEDScheduled", executionContext, loginName, RequestType.Portal, arr);

                if (data.Data.ResultData != string.Empty)
                {
                    DataSet result = JsonConvert.DeserializeObject<DataSet>(data.Data.ResultData);
                    if (result.Tables.Count > 0)
                    {
                        grdMaxVEDScheduled.DataSource = result.Tables[0];
                        result.Tables[0].Columns.Add(new DataColumn("URL"));
                        foreach (DataRow dr in result.Tables[0].Rows)
                        {
                            string VedId = dr["VEDID"].ToString();
                            string uRL = SPUrlUtility.CombineUrl(SPContext.Current.Web.Url, "/pages/Audit-Assesment.aspx?VEDID=" + VedId + "");
                            dr["URL"] = uRL;
                        }
                        divAssessment.Visible = true;

                    }
                }
                else
                {
                    divAssessment.Visible = false;
                    grdMaxVEDScheduled.DataSource = null;
                }
                grdMaxVEDScheduled.DataBind();
            }
            catch (Exception ex)
            {
                Common.ErrorLog(Type.Error, "VedAuditScheduleManagement : ddlCenters_SelectedIndexChanged", request, "", loginName, executionContext, ex, RequestType.Portal);
            }
        }

        //protected void ddlType_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    if (ddlCity.SelectedValue != "0")
        //    {
        //        BindCenter(ddlCity.SelectedValue, ddlType.SelectedValue);
        //    }
        //}
        private void ClearControl()
        {
            ddlzone.Items.Clear();
            ddlzone.Items.Insert(0, new ListItem("Select Zone", "0"));
            ddlzone.SelectedValue = "0";
            ddlzone.DataBind();
            ddlzone.Enabled = true;



            ddlState.Items.Clear();
            ddlState.Items.Insert(0, new ListItem("Select State", "0"));
            ddlState.SelectedValue = "0";
            ddlState.DataBind();
            ddlState.Enabled = true;


            ddlArea.Items.Clear();
            ddlArea.Items.Insert(0, new ListItem("Select Area", "0"));
            ddlArea.SelectedValue = "0";
            ddlArea.DataBind();
            ddlArea.Enabled = true;

            ddlCity.Items.Clear();
            ddlCity.Items.Insert(0, new ListItem("Select City", "0"));
            ddlCity.SelectedValue = "0";
            ddlCity.DataBind();
            ddlCity.Enabled = true;

            ddlCenters.Items.Clear();
            ddlCenters.Items.Insert(0, new ListItem("Select Center", "0"));
            ddlCenters.SelectedValue = "0";
            ddlCenters.DataBind();
            ddlCenters.Enabled = true;

            grdMaxVEDScheduled.DataSource = null;
            grdMaxVEDScheduled.DataBind();

            lblError.Text = string.Empty;


        }
        protected void grdAduditAssesment_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdAduditAssesment.PageIndex = e.NewPageIndex;
            BindPreviousAssessment(loginName, hdnType.Value);
        }

        private void BindPreviousAssessment(string loginName, string p)
        {
            string request = "loginName : " + loginName + "p : " + p;
            try
            {
                string officeType = rdbuttonlist.SelectedItem.Value;
                string[] arr = new string[2];
                //arr[0] = "count=100";
                arr[0] = "UserID=" + loginName + "";
                arr[1] = "OfficeType=" + officeType;
                // arr[2] = "Type=" + p;
                ServiceResult<Generic> data = BL.GenericMethod("usp_Audit_GetDoneAuditsData", executionContext, loginName, RequestType.Portal, arr);

                if (data.Data.ResultData != string.Empty)
                {
                    DataSet result = JsonConvert.DeserializeObject<DataSet>(data.Data.ResultData);
                    if (result.Tables.Count > 0)
                    {
                        grdAduditAssesment.DataSource = result.Tables[0];
                        result.Tables[0].Columns.Add(new DataColumn("URL"));
                        foreach (DataRow dr in result.Tables[0].Rows)
                        {
                            string VedId = dr["AuditID"].ToString();
                            string uRL = SPUrlUtility.CombineUrl(SPContext.Current.Web.Url, "/pages/Audit-Assesment.aspx?AuditID=" + VedId + "");
                            dr["URL"] = uRL;
                        }
                    }
                }
                else
                {
                    grdAduditAssesment.DataSource = null;
                }
                grdAduditAssesment.DataBind();
            }
            catch (Exception ex)
            {
                Common.ErrorLog(Type.Error, "VedAuditScheduleManagement : BindPreviousAssessment", request, "", loginName, executionContext, ex, RequestType.Portal);
            }
        }

        protected void ddlzone_SelectedIndexChanged(object sender, EventArgs e)
        {

            string request = "Zone : " + ddlzone.SelectedValue;
            if (ddlzone.SelectedValue != "0")
            {
                BindStateBasedOnZoneName(ddlzone.SelectedValue);
            }
            else
            {
                lblError.Text = "Please select State";
            }
        }
        private void BindStateBasedOnZoneName(string ZoneID)
        {

            try
            {
                string[] arr = new string[1];
                arr[0] = "ZoneID=" + ZoneID;
                DataSet ds = null;
                ServiceResult<Generic> results = BL.GenericMethod("usp_AuditGetSateBasedOnZoneID", executionContext, loginName, RequestType.Portal, arr);
                ds = JsonConvert.DeserializeObject<DataSet>(results.Data.ResultData);
                if (results.Data.ResultData != string.Empty)
                {
                    if (ds.Tables.Count > 0)
                    {
                        //ddlState
                        ddlState.DataSource = ds.Tables[0];
                        ddlState.DataTextField = "Title";
                        ddlState.DataValueField = "ID";

                    }
                }
                else
                {
                    ddlState.DataSource = null;
                }
                ddlState.DataBind();
                ddlState.Items.Insert(0, new ListItem("Select State", "0"));
            }
            catch (Exception ex)
            {
                Common.ErrorLog(Type.Error, "VedAuditScheduleManagement : BindStateBasedOnZoneName", "", "", loginName, executionContext, ex, RequestType.Portal);
            }

        }

        protected void ddlArea_SelectedIndexChanged(object sender, EventArgs e)
        {
            string request = "State : " + ddlState.SelectedValue;
            if (ddlArea.SelectedValue != "0")
            {
                //BindCity(ddlState.SelectedValue);//today's change date 26/03/2018
                BindCity(ddlArea.SelectedValue);
            }
            else
            {
                lblError.Text = "Please select Area";
            }
        }

        protected void rdbuttonlist_SelectedIndexChanged(object sender, EventArgs e)
        {
            ClearControl();
            CheckMember();
            BindPreviousAssessment(loginName, hdnType.Value);
            //lblError.Text = rdbuttonlist.SelectedItem.Text;
        }
    }
}
