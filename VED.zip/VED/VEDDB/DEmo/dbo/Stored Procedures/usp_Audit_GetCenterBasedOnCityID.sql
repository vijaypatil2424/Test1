﻿CREATE PROCEDURE [dbo].[usp_Audit_GetCenterBasedOnCityID] 



	@City varchar(100),

	@officeCategoryID int



AS



BEGIN



	SELECT 



		ID,



		Title



	FROM	



		OfficeMaster



	WHERE



		UPPER(City) = UPPER(@City)



	AND

			

		OfficeCategoryID = @officeCategoryID

	ORDER BY 

		Title asc



END