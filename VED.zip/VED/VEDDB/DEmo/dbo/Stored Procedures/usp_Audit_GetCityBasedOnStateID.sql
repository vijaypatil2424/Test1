﻿-- =============================================
-- Author:		<Sachin7 Jain>
-- Create date: <05-10-2017>
-- Description:	<To get the City Based on the State ID>
-- =============================================
CREATE PROCEDURE [dbo].[usp_Audit_GetCityBasedOnStateID] 
	@StateID int
AS
BEGIN
	SELECT 
	DISTINCT	
		City
	FROM	
		OfficeMaster
	WHERE
		STATEID = @StateID
END