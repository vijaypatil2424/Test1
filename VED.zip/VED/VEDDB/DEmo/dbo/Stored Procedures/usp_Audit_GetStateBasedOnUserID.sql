﻿
CREATE PROCEDURE [dbo].[usp_Audit_GetStateBasedOnUserID] --'sachin7.jain'
	@UserID varchar(200)
	--usp_Audit_GetStateBasedOnUserID 'sachin7.jain'
AS
BEGIN
	

	IF EXISTS (SELECT ID FROM  ZoneMaster WHERE ZonalHeadID = @UserID)
	BEGIN

	Declare @ZoneID int
	Set @ZoneID = (SELECT Top 1 ID from ZoneMaster Where ZonalHeadID = @UserID)
	SELECT 'ErrorCode' = 1, 'ErrorMessage' = 'Success' , 'Type' = '3'
			SELECT 
			DISTINCT	StateID as ID,
				sm.Title as Title
			FROM	
				OfficeMaster om join StateMaster sm on sm.id = om.StateID
			WHERE
				ZoneID= @ZoneID

	END
	ELSE
	BEGIN
	 IF EXISTS ( SELECT ID FROM StateMaster WHERE StateHeadID=@UserID )
	BEGIN

			SELECT 'ErrorCode' = 1, 'ErrorMessage' = 'Success',  'Type' = '2'
			SELECT 
				ID,
				Title
			FROM	
				StateMaster
			WHERE
				StateHeadID= @UserID

	DECLARE @StateID int
	Set  @StateID = (SELECT TOP 1 ID FROM StateMaster WHERE StateHeadID=@UserID)
	EXEC DBo.usp_Audit_GetCityBasedOnStateID @StateID

	END
	ELSE
	BEGIN
	SELECT 'ErrorCode' =0, 'ErrorMessage' = 'No Records Found'
	END
	END




	
END