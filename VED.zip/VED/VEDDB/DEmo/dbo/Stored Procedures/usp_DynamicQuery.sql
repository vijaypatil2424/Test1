﻿CREATE PROCEDURE [dbo].[usp_DynamicQuery]
	@SQLQuery varchar(Max)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	EXECUTE(@SQLQuery)
END

truncate table [dbo].[VEDSchedules]
truncate table [dbo].[AssessmentDetails]
truncate table [dbo].[AssessmentImages]
truncate table [dbo].[ErrorLog]
truncate table [dbo].[FacilityAreaMaster]
truncate table [dbo].[FacilityDetailsMaster]
truncate table [dbo].[VEDScheduleAudit]
truncate table OfficeMaster