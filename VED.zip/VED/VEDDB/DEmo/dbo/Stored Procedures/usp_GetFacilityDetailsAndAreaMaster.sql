﻿CREATE PROCEDURE [dbo].[usp_GetFacilityDetailsAndAreaMaster] --1,75
--[usp_GetFacilityDetailsAndAreaMaster] 1,75
@OfficeTypeID int , @VEDScheduleID int AS 
BEGIN
   Select
      FAM.ID AS FACILITYAREAID,
      FAM.Title AS FACILITYAREA,
      FDM.Title AS FACILITYDETAILS,
      FDM.ID AS FACILITYDETAILSID,
      CM.ID AS CRITICALITYID,
      CM.Title AS CRITICALITY,
      OTM.ID AS OFFICETYPEID,
      OTM.Title AS OFFICETYPE,
      FDM.Comments 
   FROM
      FacilityDetailsMaster FDM 
      INNER JOIN
         FacilityAreaMaster FAM 
         ON FDM.FacilityAreaID = FAM.ID 
      INNER JOIN
         CriticalityMaster CM 
         ON CM.ID = FDM.CriticalityID 
      INNER JOIN
         OfficeTypeMaster OTM 
         ON OTM.ID = FDM.OfficeTypeID 
   WHERE
      OTM.ID = @OfficeTypeID 
   ORDER BY
      FAM.ID 
      SELECT
         OTM.Title AS OFFICETYPE,
         CM.Title AS CRITICALITY,
         ASM.FacilityCheckPoints,
         ASM.Good,
         ASM.Poor,
         ASM.NotWorking,
         ASM.NotAvailable 
      FROM
         AssessmentScoringMaster ASM 
         JOIN
            OfficeTypeMaster OTM 
            ON ASM.OfficeTypeID = OTM.ID 
         INNER JOIN
            CriticalityMaster CM 
            ON CM.ID = ASM.CriticalityID 
      WHERE
         OfficeTypeID = @OfficeTypeID 
         Declare @officeID int 
      SET
         @officeID = 
         (
            SELECT
               OFFICEID 
            FROM
               VEDSchedules 
            WHERE
               ID = @VEDScheduleID
         )
         --SELECT @officeID
         --SELECT * FROM VEDSchedules
         SELECT
            TOP 5 REPLACE(CONVERT(NVARCHAR, ScheduledOn, 106), ' ', '-') as ScheduledOn,
            ScheduledBy,
            REPLACE(CONVERT(NVARCHAR, ActualAssesstmentDate, 106), ' ', '-') as ActualAssesstmentDate,
            OM.Title as Center,
            zm.Title as Zone,
            OM.Address as Address,
            OM.City,
            OCM.TItle AS OfficeCategory,
            OT.Title AS OfficeType,
            OM.CarpetArea AS CarpetArea,
            ved.VitalCount,
            ved.EssentialCount,
            ved.DesirableCount,
            ved.VitalNotApplicable,
            ved.EssentialNotApplicable,
            ved.DesirableNotApplicable,
            ved.TotalVEDByType,
            ved.VEDScore,
            ved.MAXVEDScore 
         FROM
            vedschedules ved 
            INNER JOIN
               OFFICEMASTER om 
               ON ved.OfficeID = om.ID 
            Inner join
               ZoneMaster zm 
               ON ZM.ID = OM.ZoneID 
            INNER JOIN
               OFFICECategoryMASTER OCM 
               ON OCM.ID = OM.OFFICECATEGORYID 
            Inner JOIn
               OfficeTypeMaster OT 
               ON OT.ID = OM.OFFICETYPEID 
         WHERE
            om.ID = @officeID 
            AND ActualAssesstmentDate is not null 
         ORDER by
            ActualAssesstmentDate DESC 
END