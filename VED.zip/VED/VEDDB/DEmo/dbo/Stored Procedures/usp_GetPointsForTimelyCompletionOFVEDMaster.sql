﻿-- ======================================
-- Author:		<Sachin Jain>
-- Create date: <22-09-2017>
-- Description:	<To get the [PointsForTimelyCompletionOFVEDMaster] data>
-- =============================================
CREATE PROCEDURE [dbo].[usp_GetPointsForTimelyCompletionOFVEDMaster]
	@OfficeTypeID int
AS
BEGIN
	Select 
		 OnTime,  --On time (+/- 3 days from scheduled date)
		 WithAcceptableDelay, --With Acceptable Delay (within 15 Days from scheduled date)
		 WithNotAcceptableDelay, -- With Not Acceptable Delay (Within 15-30 Days from Scheduled date)
		 NotDone, -- Not Done as  per Scheduled date
		 NotScheduled -- Not Scheduled
	from
		 [PointsForTimelyCompletionOFVEDMaster] 
    where 
		 OfficeTypeID = @OfficeTypeID
END