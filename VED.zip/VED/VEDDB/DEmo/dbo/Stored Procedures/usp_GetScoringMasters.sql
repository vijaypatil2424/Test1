﻿-- =============================================
-- Author:		<Sachin Jain>
-- Create date: <21-09-2017>
-- Description:	<To get the Scoring master>
-- =============================================
CREATE PROCEDURE [dbo].[usp_GetScoringMasters] 
@OfficeTypeID int
AS
BEGIN
	SELECT 
			 OTM.Title AS OFFICETYPE
			,CM.Title AS CRITICALITY
			,ASM.FacilityCheckPoints
			,ASM.Good
			,ASM.Poor
			,ASM.NotWorking
			,ASM.NotAvailable
		FROM 
			AssessmentScoringMaster	ASM
		JOIN
			OfficeTypeMaster OTM 
		ON
			ASM.OfficeTypeID = OTM.ID
		INNER JOIN
			CriticalityMaster CM
		ON
			CM.ID = ASM.CriticalityID
		WHERE
			OfficeTypeID = @OfficeTypeID
END