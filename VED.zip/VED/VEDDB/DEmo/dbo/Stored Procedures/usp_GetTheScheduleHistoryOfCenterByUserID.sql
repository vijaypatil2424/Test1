﻿CREATE PROCEDURE [dbo].[usp_GetTheScheduleHistoryOfCenterByUserID] --5,'sachin7.jain'
@count int , @UserID varchar(200) , @Type int = null AS 
BEGIN
   SELECT
      TOP(@count) REPLACE(CONVERT(NVARCHAR, ScheduledOn, 106), ' ', '-') as ScheduledOn,
      ScheduledBy,
      REPLACE(CONVERT(NVARCHAR, ActualAssesstmentDate, 106), ' ', '-') as ActualAssesstmentDate,
      OM.Title as Center,
      zm.Title as Zone,
      OM.Address as Address,
      OM.City,
      OCM.TItle AS OfficeCategory,
      OT.Title AS OfficeType,
      OM.CarpetArea AS CarpetArea,
      ved.VitalCount,
      ved.EssentialCount,
      ved.DesirableCount,
      ved.VitalNotApplicable,
      ved.EssentialNotApplicable,
      ved.DesirableNotApplicable,
      ved.TotalVEDByType,
      ved.VEDScore,
      ved.MAXVEDScore,
      ved.ID as VEDID,
      --=  COnvert(DECIMAL(10,2),((VED.VEDScore / Ved.MAXVEDScore) * 100)), 
      'VEDPercentage' = 
      (
(VED.VEDScore / Ved.MAXVEDScore) * 100 
      )
   FROM
      vedschedules ved 
      INNER JOIN
         OFFICEMASTER om 
         ON ved.OfficeID = om.ID 
      Inner join
         ZoneMaster zm 
         ON ZM.ID = OM.ZoneID 
      INNER JOIN
         OFFICECategoryMASTER OCM 
         ON OCM.ID = OM.OFFICECATEGORYID 
      Inner JOIn
         OfficeTypeMaster OT 
         ON OT.ID = OM.OFFICETYPEID 
   WHERE
      ved.ScheduledBy = @UserID 
      AND ActualAssesstmentDate is not null 		--AND
      --		VED.AssessmentType = @Type
   ORDER by
      ActualAssesstmentDate DESC 
END