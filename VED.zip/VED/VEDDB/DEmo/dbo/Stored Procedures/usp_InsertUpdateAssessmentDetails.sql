﻿-- =============================================
-- Author:		<Sachin Jain>
-- Create date: <13-09-2017>
-- Description:	<To Insert/Update details of VED Assessment>
-- =============================================
CREATE PROCEDURE [dbo].[usp_InsertUpdateAssessmentDetails] 
	 @ID int  = NULL
	,@VEDScheduleID Int = NULL
	,@FacilityAreaID int = NULL
	,@FacilityDetailsID int = NULL
	,@CriticalityID int = NULL
	,@Condition varchar(20) = NULL
	,@Points int = NULL
	,@AssessmentDoneBy varchar(200) = NULL
	,@AssessmentDate datetime = NULL
	,@Comments varchar(max) = NULL
	,@ImageURL varchar(max) = NULL
	,@ImageBytes binary(8000) = NULL
	,@OfficeType int = NULL
	,@AssessmentDoneType varchar(10) = NULL
	,@ModifiedBy varchar(200) = NULL
	,@ModifiedOn datetime= NULL
AS
BEGIN
	

	IF EXISTS  (SELECT 
					ID
				FROM
					AssessmentDetails
				WHERE
					ID= @ID)
	BEGIN
	--Update		
				UPDATE
					AssessmentDetails
				SET
					 VEDScheduleID  =@VEDScheduleID  
					,FacilityAreaID  =@FacilityAreaID  
					,FacilityDetailsID =@FacilityDetailsID  
					,CriticalityID  =@CriticalityID  
					,Condition =@Condition 
					,Points  =@Points  
					,AssessmentDoneBy =@AssessmentDoneBy 
					,AssessmentDate=@AssessmentDate
					,Comments =@Comments 
					,ImageURL =@ImageURL 
					,ImageBytes  =@ImageBytes  
					,OfficeType  =@OfficeType  
					,AssessmentDoneType=@AssessmentDoneType 
					,ModifiedBy =@ModifiedBy 
					,ModifiedOn=GEtDATE()
				WHERE
					VEDScheduleID = @VEDScheduleID



				UPDATE
					VEDSchedules
				SET	
					ActualAssesstmentDate = GETDATE()
					,ModifiedOn =GETDATE()
					,ModifiedBy = @ModifiedBy
				WHERE
					ID= @VEDScheduleID

	END
	ELSE
	BEGIN
	--Insert
				INSERT INTO
					AssessmentDetails
									(
					 VEDScheduleID      
					,FacilityAreaID     
					,FacilityDetailsID   
					,CriticalityID      
					,Condition          
					,Points             
					,AssessmentDoneBy   
					,AssessmentDate     
					,Comments           
					,ImageURL			
					,ImageBytes			
					,OfficeType			
					,AssessmentDoneType  
									)
				VALUES				(
					 @VEDScheduleID  
					,@FacilityAreaID  
					,@FacilityDetailsID 
					,@CriticalityID  
					,@Condition 
					,@Points  
					,@AssessmentDoneBy 
					,@AssessmentDate
					,@Comments 
					,@ImageURL 
					,@ImageBytes  
					,@OfficeType  
					,@AssessmentDoneType
									)

				UPDATE
					VEDSchedules
				SET	
					ActualAssesstmentDate = GETDATE()
					,ModifiedOn =GETDATE()
					,ModifiedBy = @ModifiedBy
				WHERE
					ID= @VEDScheduleID
	END



END