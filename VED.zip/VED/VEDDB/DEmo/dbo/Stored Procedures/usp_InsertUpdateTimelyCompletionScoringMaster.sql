﻿Create PROCEDURE [dbo].[usp_InsertUpdateTimelyCompletionScoringMaster] 
        @ID int  = NULL
       ,@OfficeTypeID int = NULL
       ,@OnTime int = NULL
       ,@WithAcceptableDelay int = NULL
       ,@WithNotAcceptableDelay int = NULL
       ,@NotDone int = NULL
       ,@NotScheduled int = NULL
       ,@ModifiedBy varchar(200)
       
AS
BEGIN
       
       IF NOT EXISTS (SELECT ID FROM PointsForTimelyCompletionOFVEDMaster WHERE ID = @ID)
       BEGIN
       INSERT INTO PointsForTimelyCompletionOFVEDMaster(ID,OfficeTypeID,OnTime,WithAcceptableDelay,WithNotAcceptableDelay,NotDone,NotScheduled,CreatedOn,CreatedBy)
       VALUES(@ID,@OfficeTypeID,@OnTime,@WithAcceptableDelay,@WithNotAcceptableDelay,@NotDone,@NotScheduled,GetDAte(),@ModifiedBy)
       END

       UPDATE
              PointsForTimelyCompletionOFVEDMaster
       SET
              OfficeTypeID = @OfficeTypeID 
              ,OnTime  =@OnTime  
              ,WithAcceptableDelay= @WithAcceptableDelay  
              ,WithNotAcceptableDelay  = @WithNotAcceptableDelay  
              ,NotDone  = @NotDone  
              ,@NotScheduled  = @NotScheduled 
              ,ModifiedBy = @ModifiedBy 
              ,ModifiedOn =GETDATE()
       WHERE
              ID=@ID
END