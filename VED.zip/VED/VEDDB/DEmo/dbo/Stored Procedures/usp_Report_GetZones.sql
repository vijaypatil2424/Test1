﻿CREATE PROCEDURE [dbo].[usp_Report_GetZones] 
	
AS
BEGIN
	Select Distinct ID, Title from ZoneMaster
END