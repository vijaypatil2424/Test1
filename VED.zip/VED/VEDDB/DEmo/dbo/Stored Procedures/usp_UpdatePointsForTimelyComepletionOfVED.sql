﻿-- =============================================
-- Author:		<Sachin Jain>
-- Create date: <13-09-2017>
-- Description:	<To Update points for Timely COmpletion if VED>
-- =============================================
CREATE PROCEDURE [dbo].[usp_UpdatePointsForTimelyComepletionOfVED]
	 @ID int
	,@OfficeTypeID int
	,@OnTime int
	,@WithAcceptableDelay int
	,@WithNotAcceptableDelay  int
	,@NotDone int
	,@NotScheduled int
	,@ModifiedBy datetime

AS
BEGIN
	
	UPDATE 
		PointsForTimelyCompletionOFVEDMaster
	SET	
		 OfficeTypeID = @OfficeTypeID
		,OnTime= @OnTime
		,WithAcceptableDelay  = @WithAcceptableDelay
		,WithNotAcceptableDelay= @WithNotAcceptableDelay
		,NotDone  = @NotDone
		,NotScheduled  = @NotScheduled
		,ModifiedOn =GETDATE()
		,ModifiedBy =@ModifiedBy
	WHERE
		ID =@ID
		
END