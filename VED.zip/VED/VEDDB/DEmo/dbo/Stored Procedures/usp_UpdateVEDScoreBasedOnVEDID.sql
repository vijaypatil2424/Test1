﻿-- =============================================
-- Author:		<Sachin Jain>
-- Create date: <22-09-2017>
-- Description:	<To update VEDScore >
-- =============================================
CREATE PROCEDURE [dbo].[usp_UpdateVEDScoreBasedOnVEDID]
    @VitalCount decimal(5, 0) ,
	@EssentialCount decimal(5, 0) ,
	@DesirableCount decimal(5, 0) ,
	@TotalVEDByType decimal(5, 0) ,
	@VitalNotApplicable decimal(5, 0) ,
	@EssentialNotApplicable decimal(5, 0) ,
	@DesirableNotApplicable decimal(5, 0) ,
	@VEDScore decimal(5, 0) ,
	@MAXVEDScore decimal(5, 0) ,
	@VEDScheduleID int,
	@ModifiedBy varchar(200)
AS
BEGIN
	UPDATE
		VEDSchedules
	SET
		VitalCount=	@VitalCount,
		EssentialCount=	@EssentialCount,
		DesirableCount=	@DesirableCount,
		TotalVEDByType=	@TotalVEDByType,
		VitalNotApplicable=	@VitalNotApplicable,
		EssentialNotApplicable=	@EssentialNotApplicable,
		DesirableNotApplicable=	@DesirableNotApplicable,
		VEDScore =@VEDScore,
		MAXVEDScore	= @MAXVEDScore,
		ModifiedOn =GetDate(),
		MOdifiedBy = @ModifiedBy
		 
	WHERE
		ID = @VEDScheduleID
	END