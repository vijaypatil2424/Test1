﻿CREATE TABLE [dbo].[OfficeMaster] (
    [ID]                     INT            NOT NULL,
    [Title]                  VARCHAR (100)  NOT NULL,
    [ZoneID]                 INT            NULL,
    [StateID]                INT            NULL,
    [City]                   VARCHAR (100)  NULL,
    [OfficeTypeID]           INT            NULL,
    [OfficeCategoryID]       INT            NULL,
    [CarpetArea]             NVARCHAR (100) NULL,
    [Address]                VARCHAR (MAX)  NULL,
    [OfficeAdmins]           NVARCHAR (100) NULL,
    [TypeID]                 INT            NULL,
    [Latitude]               NVARCHAR (50)  NULL,
    [Longitude]              NVARCHAR (50)  NULL,
    [EFacilityHelpDeskEmail] VARCHAR (100)  NULL,
    [CreatedOn]              DATETIME       CONSTRAINT [DF_OfficeMaster_CreatedOn] DEFAULT (getdate()) NULL,
    [CreatedBy]              VARCHAR (200)  NULL,
    [ModifiedOn]             DATETIME       NULL,
    [ModifiedBy]             VARCHAR (200)  NULL,
    [Active]                 BIT            CONSTRAINT [DF_OfficeMaster_Active] DEFAULT ((1)) NULL
);

