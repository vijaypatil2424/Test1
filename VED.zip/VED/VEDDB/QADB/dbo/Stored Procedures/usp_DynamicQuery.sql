﻿CREATE PROCEDURE [dbo].[usp_DynamicQuery]
	@SQLQuery varchar(Max)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	EXECUTE(@SQLQuery)
END