﻿CREATE PROCEDURE [dbo].[usp_GetAllVEDSchedule] --null,null,1,'GETBYOFFICEID'



--[usp_GetAllVEDSchedule] null,null,1,'GETBYOFFICEID'



   @ID INT = NULL   ----VED  Schedule ID



 , @UserID VARCHAR(200) = NULL   ----LoggedIn User ID



 , @OfficeID INT = NULL ---- OFFICE ID



 , @Type VARCHAR(100) AS -- Type of data required



BEGIN



   --To get all the VED scheduled of current month and Year for the loggedinUser



   --[usp_GetAllVEDSchedule] null,'sachin7.jain',null,'GETALL'



   IF Upper(@Type) = 'GETALL' 



   BEGIN



      --Select * from  OfficeMAster



      SELECT



         ved.ID,



         OfficeID,        



		 REPLACE(CONVERT(NVARCHAR,ScheduledOn, 106), ' ', '-') as ScheduledOn,



         ved.ScheduledBy,



         ActualAssesstmentDate,



         OM.Title as Center,



         zm.Title as Zone,



         OM.Address as Address,



         OM.City,



         OCM.TItle AS OfficeCategory,



         OT.ID AS OfficeType,



         OM.CarpetArea AS CarpetArea 



		,'IsEditAllowed' = (Select dbo.ufnToConfirmScheduleEditOrNot(ved.ID))



		,om.Latitude



		,om.Longitude



		,om.OfficeAdmins



      FROM



         vedschedules ved 



         INNER JOIN



            OFFICEMASTER om 



            ON ved.OfficeID = om.ID 



         Inner join



            ZoneMaster zm 



            ON ZM.ID = OM.ZoneID 



         INNER JOIN



            OFFICECategoryMASTER OCM 



            ON OCM.ID = OM.OFFICECATEGORYID 



         Inner JOIn



            OfficeTypeMaster OT 



            ON OT.ID = OM.OFFICETYPEID 



      WHERE



         --scheduledby = @UserId 



		   om.OfficeAdmins like  '%'+@UserId +'%' 



		   AND



		   (CAST(ScheduledOn AS DATE) >= DATEADD(MONTH, -1, GETDATE())  and  CAST(ScheduledOn AS DATE) <=  CAST(eomonth(DATEADD(mm,1,CAST(eomonth(GETDATE()) AS datetime))) AS DATE))



	 	   AND VED.ID NOT IN( SELECT DISTINCT 



										VEDScheduleID 



							         FROM 



										AssessmentDetails)



			--AND



			--	VED.AssessmentType = 1



         --AND DATEPART(MM, ved.ScheduledOn) = DATEPART(MM, GETDATE()) 



         --and DATEPART(YYYY, ved.ScheduledOn) = DATEPART(YYYY, GETDATE())







	 ORDER BY



		CAST(ScheduledOn AS DATE) ASC



   END



   --To Get data for EDIT



   --[usp_GetAllVEDSchedule] 5,null,null,'GETBYID'



   ELSE IF UPPER(@Type) = 'GETBYID' 



   BEGIN



         --Select * from  OfficeMAster



         SELECT



            ved.ID,



            OfficeID,



             REPLACE(CONVERT(NVARCHAR,ScheduledOn, 106), ' ', '-') as ScheduledOn,



            ScheduledBy,



            REPLACE(CONVERT(NVARCHAR,ActualAssesstmentDate, 106), ' ', '-') as ActualAssesstmentDate,



            OM.Title as Center,



            zm.Title as Zone,



            OM.Address as Address,



            OM.City,



            OCM.TItle AS OfficeCategory,



            OT.Title AS OfficeType,



			OT.ID AS OfficeTypeID,



            OM.CarpetArea AS CarpetArea,



			'IsEditAllowed' = (Select dbo.ufnToConfirmScheduleEditOrNot(ved.ID))



			,om.Latitude



		    ,om.Longitude



			,om.OfficeAdmins



			,sm.ID as State



			 				--Count is pending



         FROM



            vedschedules ved 



            INNER JOIN



               OFFICEMASTER om 



               ON ved.OfficeID = om.ID 



            Inner join



               ZoneMaster zm 



               ON ZM.ID = OM.ZoneID 



            INNER JOIN



               OFFICECategoryMASTER OCM 



               ON OCM.ID = OM.OFFICECATEGORYID 



            Inner JOIn



               OfficeTypeMaster OT 



               ON OT.ID = OM.OFFICETYPEID 



			Inner Join StateMaster SM



			on SM.ID = om.StateID



         WHERE



            ved.ID = @ID 



      END



      --To GEt the Data of office based on the Office ID



	  --[usp_GetAllVEDSchedule] null,null,1,'GETBYOFFICEID'



   ELSE IF UPPER(@Type) = 'GETBYOFFICEID' 



   BEGIN


            --Select * from  OfficeMAster



            SELECT



               OM.ID,



               OM.Title as Center,



               zm.Title as Zone,



               OM.Address as Address,



               OM.City,



               OCM.TItle AS OfficeCategory,



               OT.Title AS OfficeType,



               OM.CarpetArea AS CarpetArea 



			   ,om.Latitude



		       ,om.Longitude



			   ,om.OfficeAdmins					--Count is pending



            FROM



               OFFICEMASTER om 



               Inner join



                  ZoneMaster zm 



                  ON ZM.ID = OM.ZoneID 



               INNER JOIN



                  OFFICECategoryMASTER OCM 



                  ON OCM.ID = OM.OFFICECATEGORYID 



               Inner JOIn



                  OfficeTypeMaster OT 



                  ON OT.ID = OM.OFFICETYPEID 



            WHERE



               om.ID = @OfficeID 



         END



		 --[usp_GetAllVEDSchedule] null,'rahul.parambath',null,'GETALLVED'



   ELSE IF UPPER(@Type) = 'GETALLVED' 



   BEGIN



               --Select * from  OfficeMAster



               SELECT



                  Title,



                  ID 



               FROM



                  OfficeMaster 



               WHERE



                  OfficeAdmins like  '%'+@UserID+'%' 



			   ORDER BY



				   Title asc



            END



END



















----Select * from OfficeMasTer where OfficeAdmins like '%ulahannan.poulose%'











--rahul.parambath;ulahannan.poulose