﻿-- =============================================
-- Author:		<Sachin Jain>
-- Create date: <12/09/2017>
-- Description:	<To get the Boolean value, stating whether the Scheduled is allowd to edit or not>
-- =============================================
CREATE FUNCTION [dbo].[ufnToConfirmScheduleEditOrNot]
(
	@vedScheduleID int
)
RETURNS bit
AS
BEGIN
	-- Declare the return variable here
	DECLARE @isEditAllowed bit
	IF (SELECT 
		COUNT(*)
	FROM
		VEDScheduleAudit
	WHERE
		VEDScheduleID = @vedScheduleID) >= 2

		BEGIN
		SET @isEditAllowed = 0
		END
		ELSE
		BEGIN
		SET @isEditAllowed = 1
		END

	RETURN @isEditAllowed

END