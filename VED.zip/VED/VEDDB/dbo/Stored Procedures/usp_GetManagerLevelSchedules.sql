﻿-- =============================================
-- Author:		<Sachin Jain>
-- Create date: <26-09-2017>
-- Description:	<To get the L1 and L2 level Schedule Offices>
-- =============================================
CREATE PROCEDURE [dbo].[usp_GetManagerLevelSchedules] -- 'sachin7.jain','state'
--usp_GetManagerLevelSchedules  'sachin7.jain','state'
 @userID varchar(200)
,@type varchar(50)


AS
BEGIN
	IF UPPER(@type) = 'STATE'
	BEGIN

	    --Select * from  OfficeMAster
      SELECT
         ved.ID,
         OfficeID,        
		 REPLACE(CONVERT(NVARCHAR,ScheduledOn, 106), ' ', '-') as ScheduledOn,
         ScheduledBy,
         ActualAssesstmentDate,
         OM.Title as Center,
         zm.Title as Zone,
         OM.Address as Address,
         OM.City,
         OCM.TItle AS OfficeCategory,
         OT.Title AS OfficeType,
         OM.CarpetArea AS CarpetArea,
		 OM.OfficeAdmins
		 
      FROM
         vedschedules ved 
         INNER JOIN
            OFFICEMASTER om 
            ON ved.OfficeID = om.ID 
         Inner join
            ZoneMaster zm 
            ON ZM.ID = OM.ZoneID 
         INNER JOIN
            OFFICECategoryMASTER OCM 
            ON OCM.ID = OM.OFFICECATEGORYID 
         Inner JOIn
            OfficeTypeMaster OT 
            ON OT.ID = OM.OFFICETYPEID 
	 WHERE OfficeID in (
						SELECT 
							ID 
						FROM 
							 OfficeMaster
						WHERE 
							StateID  in (
										SELECT  
											ID 
										FROM 
											StateMaster
										WHERE 
											StateHeadID = @userID))
			AND
				VED.AssessmentType = 1

	END

	


END