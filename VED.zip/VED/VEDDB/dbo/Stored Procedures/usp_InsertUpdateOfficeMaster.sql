﻿-- =============================================
-- Author:		<Sachin Jain>
-- Create date: <12/9/2017>
-- Description:	<To Insert/Update the OfficeMaster Data>
-- =============================================
CREATE PROCEDURE [dbo].[usp_InsertUpdateOfficeMaster]  
	 @ID int = NULL
	,@Title varchar(100) = NULL
	,@ZoneID int = NULL
	,@StateID int = NULL
	,@City varchar(100) = NULL
	,@OfficeTypeID int = NULL
	,@OfficeCategoryID int = NULL
	,@CarpetArea nvarchar(100)  = NULL
	,@Address varchar(max) = NULL
	,@OfficeAdmins nvarchar(100)  = NULL
	,@TypeID int = NULL
	,@Latitude nvarchar(50) = NULL
	,@Longitude nvarchar(50) = NULL
	,@EFacilityHelpDeskEmail varchar(100) = NULL
	,@CreatedBy varchar(200) = NULL
	,@ModifiedOn datetime = NULL
	,@ModifiedBy varchar(200) = NULL
	,@AreaHeadID varchar(200) = NULL
AS
BEGIN

	IF EXISTS( SELECT 
					ID
				FROM
					OfficeMaster
				WHERE
					ID =@ID)

	BEGIN
	UPDATE 
			OfficeMaster
		SET
			Title            	   =@Title
			,ZoneID				   =@ZoneID
			,StateID				   =@StateID
			,City				   =@City
			,OfficeTypeID		   =@OfficeTypeID
			,OfficeCategoryID	   =@OfficeCategoryID
			,CarpetArea			   =@CarpetArea
			,Address				   =@Address
			,OfficeAdmins		   =@OfficeAdmins
			,TypeID				   =@TypeID
			,Latitude			   =@Latitude
			,Longitude			   =@Longitude
			,EFacilityHelpDeskEmail =@EFacilityHelpDeskEmail
			,ModifiedOn = GETDATE()
			,ModifiedBy = @ModifiedBy
			,AreaHeadID = @AreaHeadID

	END
	ELSE
	BEGIN
		INSERT INTO 
			OfficeMaster
			(
			 ID
			,Title
			,ZoneID
			,StateID
			,City
			,OfficeTypeID
			,OfficeCategoryID
			,CarpetArea
			,Address
			,OfficeAdmins
			,TypeID
			,Latitude
			,Longitude
			,EFacilityHelpDeskEmail
			,CreatedBy
			,AreaHeadID
			)
		VALUES
			(
			 @ID
			,@Title
			,@ZoneID
			,@StateID
			,@City
			,@OfficeTypeID
			,@OfficeCategoryID
			,@CarpetArea
			,@Address
			,@OfficeAdmins
			,@TypeID
			,@Latitude
			,@Longitude
			,@EFacilityHelpDeskEmail
			,@CreatedBy
			,@AreaHeadID
			)
			END
END