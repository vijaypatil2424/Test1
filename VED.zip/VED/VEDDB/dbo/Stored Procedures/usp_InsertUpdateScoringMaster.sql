﻿-- =============================================
-- Author:		<Sachin Jain>
-- Create date: <12-09-2017>
-- Description:	<To Insert Update Scoring Master>
-- =============================================
CREATE PROCEDURE usp_InsertUpdateScoringMaster 
	 @ID int  = NULL
	,@OfficeTypeID int = NULL
	,@CriticalityID int = NULL
	,@FacilityCheckPoints int = NULL
	,@Good int = NULL
	,@Poor int = NULL
	,@NotWorking int = NULL
	,@NotAvailable int = NULL
	,@ModifiedBy varchar(200) = NULL
AS
BEGIN
	
	UPDATE
		AssessmentScoringMaster
	SET
		 OfficeTypeID = @OfficeTypeID 
		,CriticalityID  =@CriticalityID  
		,FacilityCheckPoints= @FacilityCheckPoints  
		,Good  = @Good  
		,Poor  = @Poor  
		,NotWorking  = @NotWorking  
		,NotAvailable  = @NotAvailable 
		,ModifiedBy =@ModifiedBy
	WHERE
		ID=@ID
END