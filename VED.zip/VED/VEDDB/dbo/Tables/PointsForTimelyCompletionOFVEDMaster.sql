﻿CREATE TABLE [dbo].[PointsForTimelyCompletionOFVEDMaster] (
    [ID]                     INT           IDENTITY (1, 1) NOT NULL,
    [OfficeTypeID]           INT           NULL,
    [OnTime]                 INT           NULL,
    [WithAcceptableDelay]    INT           NULL,
    [WithNotAcceptableDelay] INT           NULL,
    [NotDone]                INT           NULL,
    [NotScheduled]           INT           NULL,
    [CreatedOn]              DATETIME      CONSTRAINT [DF_PoinsForTimelyCompletionOFVEDMaster_CreatedOn] DEFAULT (getdate()) NULL,
    [CreatedBy]              VARCHAR (200) NULL,
    [ModifiedOn]             DATETIME      NULL,
    [ModifiedBy]             VARCHAR (200) NULL,
    CONSTRAINT [PK_PoinsForTimelyCompletionOFVEDMaster] PRIMARY KEY CLUSTERED ([ID] ASC)
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'[Not Done as  per Scheduled date]', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'PointsForTimelyCompletionOFVEDMaster', @level2type = N'COLUMN', @level2name = N'NotDone';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'[With Not Acceptable Delay (Within 15-30 Days from Scheduled date)]', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'PointsForTimelyCompletionOFVEDMaster', @level2type = N'COLUMN', @level2name = N'WithNotAcceptableDelay';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'[With Acceptable Delay (within 15 Days from scheduled date)] ', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'PointsForTimelyCompletionOFVEDMaster', @level2type = N'COLUMN', @level2name = N'WithAcceptableDelay';


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'[On time (+/- 3 days from scheduled date)]', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'PointsForTimelyCompletionOFVEDMaster', @level2type = N'COLUMN', @level2name = N'OnTime';

