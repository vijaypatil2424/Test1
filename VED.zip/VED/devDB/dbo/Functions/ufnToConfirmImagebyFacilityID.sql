﻿-- =============================================
-- Author:		<Sachin Jain>
-- Create date: <27/09/2017>
-- Description:	<To get the Boolean value, stating whether the facility details has any images attached to it>
-- =============================================
CREATE FUNCTION [dbo].[ufnToConfirmImagebyFacilityID]
(
	@vedScheduleID int
	,@FacilityID int
)
RETURNS bit
AS
BEGIN
	-- Declare the return variable here
	DECLARE @isImageAvailable bit
	IF (SELECT 
		COUNT(*)
	FROM
		AssessmentImages
	WHERE
		VEDScheduleID = @vedScheduleID And FacilityDetailID = @FacilityID) > 0

		BEGIN
		SET @isImageAvailable = 1
		END
		ELSE
		BEGIN
		SET @isImageAvailable = 0
		END

	RETURN @isImageAvailable

END