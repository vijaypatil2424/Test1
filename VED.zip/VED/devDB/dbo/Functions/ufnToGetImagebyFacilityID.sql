﻿-- =============================================
-- Author:		<Sachin Jain>
-- Create date: <27/09/2017>
-- Description:	<To get the Boolean value, stating whether the facility details has any images attached to it>
-- =============================================
CREATE FUNCTION [dbo].[ufnToGetImagebyFacilityID]
(
	@vedScheduleID int
	,@FacilityID int
)
RETURNS VARCHAR(MAX)
AS
BEGIN
	-- Declare the return variable here
	DECLARE @tmp VARCHAR(MAX)
	SET @tmp = ''
select @tmp = @tmp+ 'http://sp13devwfe01:19999/_LAYOUTS/15/VEDHandler/image.ashx?ID='+CAST(ID as varchar(20) )+ ', ' from AssessmentImages
Where VEDScheduleID=@vedScheduleID and FacilityDetailID=@FacilityID

Return SUBSTRING(@tmp, 0, LEN(@tmp))

END