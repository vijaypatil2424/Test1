﻿



-- =============================================
-- Author:		<Sachin Jain>
-- Create date: <27/09/2017>
-- Description:	<To get the Boolean value, stating whether the facility details has any images attached to it>
-- =============================================
CREATE FUNCTION [dbo].[ufnToGetPointBasedOnScheduleOnDate]
(
	  @OfficeID int ,
      @ScheduleOn datetime = NULL,
	  @type int  = null

)

---Select * from [dbo].[ufnToGetPointBasedOnScheduleOnDate](
RETURNS int
AS
BEGIN

	DECLARE @point int

	--Set @OfficeID = 34
 --   Set @ScheduleOn ='2017-11-01 00:00:00.000'

	---Step Check whether Any Schedule have be created or not 

	IF (Select Count(*) from VEDSchedules
    where  DATEPART(MM, ScheduledOn) = DATEPART(MM, DATEADD(MONTH, -1, @ScheduleOn))
    AND  DATEPART(YYYY, ScheduledOn) = DATEPART(YYYY, DATEADD(MONTH, -1, @ScheduleOn))
    and OfficeID = @OfficeID) > 0
	BEGIN
    Declare  @MaxScheduleOn Datetime
    Declare  @MaxActualAssessmentDate Datetime
	IF (Select Count(*) from VEDSchedules
    where  DATEPART(MM, ScheduledOn) = DATEPART(MM, DATEADD(MONTH, -1, @ScheduleOn))
    AND  DATEPART(YYYY, ScheduledOn) = DATEPART(YYYY, DATEADD(MONTH, -1, @ScheduleOn))
    and OfficeID = @OfficeID and (ActualAssesstmentDate is not null or ActualAssesstmentDate <> ''))  > 0
	BEGIN

	set @MaxScheduleOn =  (SELECT TOP 1 ScheduledOn from VEDSchedules 
	 where  DATEPART(MM, ScheduledOn) = DATEPART(MM, DATEADD(MONTH, -1, @ScheduleOn))
    AND  DATEPART(YYYY, ScheduledOn) = DATEPART(YYYY, DATEADD(MONTH, -1, @ScheduleOn))
    and OfficeID = @OfficeID and (ActualAssesstmentDate is not null or ActualAssesstmentDate <> '')
	order by  ActualAssesstmentDate desc
	)

	set @MaxActualAssessmentDate =  (SELECT TOP 1 ActualAssesstmentDate from VEDSchedules 
	 where  DATEPART(MM, ScheduledOn) = DATEPART(MM, DATEADD(MONTH, -1, @ScheduleOn))
    AND  DATEPART(YYYY, ScheduledOn) = DATEPART(YYYY, DATEADD(MONTH, -1, @ScheduleOn))
    and OfficeID = @OfficeID and (ActualAssesstmentDate is not null or ActualAssesstmentDate <> '')
	order by  ActualAssesstmentDate desc)

	--Print @MaxScheduleOn

	--Print @MaxActualAssessmentDate

	IF DATEDIFF(DD,@MaxScheduleOn, @MaxActualAssessmentDate)  Between -3 and  3
	BEGIN
	set @point = (SELECT OnTime from PointsForTimelyCompletionOFVEDMaster where OfficeTypeID=@type)
	--select * from PointsForTimelyCompletionOFVEDMaster

	--Print 'Scheduled VED and  Assessment not done difference -3 and 3 days'
	END
	ELSE IF DATEDIFF(DD,@MaxScheduleOn, @MaxActualAssessmentDate)  Between 4 and  14
	BEGIN
	set @point = (SELECT WithAcceptableDelay from PointsForTimelyCompletionOFVEDMaster where OfficeTypeID=@type)
	--Print 'Scheduled VED and  Assessment not done difference 4 and 14 days'
	END
	ELSE IF DATEDIFF(DD,@MaxScheduleOn, @MaxActualAssessmentDate)  Between 15 and  30
	BEGIN
	set @point = (SELECT WithNotAcceptableDelay from PointsForTimelyCompletionOFVEDMaster where OfficeTypeID=@type)
	--Print 'Scheduled VED and  Assessment not done difference 15 and 30 days'
	END
	ELSE IF DATEDIFF(DD,@MaxScheduleOn, @MaxActualAssessmentDate)  > 30
	BEGIN
	set @point = (SELECT NotDone from PointsForTimelyCompletionOFVEDMaster where OfficeTypeID=@type)
	--Print 'Scheduled VED and  Assessment not done difference 30 days'
	END
	END
	ELSE
	BEGIN
	set @point  = (SELECT NotDone from PointsForTimelyCompletionOFVEDMaster where OfficeTypeID=@type)
	--Print 'Scheduled VED but Assessment not done'
	END
	END
	ELSE
	BEGIN
	set @point = (SELECT NotScheduled from PointsForTimelyCompletionOFVEDMaster where OfficeTypeID=@type)
	--Print 'NOt Scheduled any VED'
	END
	--SELECT @point

	RETURN @point




	--------	DECLARE @point int
	--------Declare  @OfficeID varchar(100)
 --------   Declare  @ScheduleOn datetime
	--------Set @OfficeID = 34
 --------   Set @ScheduleOn ='2017-11-01 00:00:00.000'

	-----------Step Check whether Any Schedule have be created or not 

	--------IF (Select Count(*) from VEDSchedules
 --------   where  DATEPART(MM, ScheduledOn) = DATEPART(MM, DATEADD(MONTH, -1, @ScheduleOn))
 --------   AND  DATEPART(YYYY, ScheduledOn) = DATEPART(YYYY, DATEADD(MONTH, -1, @ScheduleOn))
 --------   and OfficeID = @OfficeID) > 0
	--------BEGIN
 --------   Declare  @MaxScheduleOn Datetime
 --------   Declare  @MaxActualAssessmentDate Datetime
	--------IF (Select Count(*) from VEDSchedules
 --------   where  DATEPART(MM, ScheduledOn) = DATEPART(MM, DATEADD(MONTH, -1, @ScheduleOn))
 --------   AND  DATEPART(YYYY, ScheduledOn) = DATEPART(YYYY, DATEADD(MONTH, -1, @ScheduleOn))
 --------   and OfficeID = @OfficeID and (ActualAssesstmentDate is not null or ActualAssesstmentDate <> ''))  > 0
	--------BEGIN

	--------set @MaxScheduleOn =  (SELECT TOP 1 ScheduledOn from VEDSchedules 
	-------- where  DATEPART(MM, ScheduledOn) = DATEPART(MM, DATEADD(MONTH, -1, @ScheduleOn))
 --------   AND  DATEPART(YYYY, ScheduledOn) = DATEPART(YYYY, DATEADD(MONTH, -1, @ScheduleOn))
 --------   and OfficeID = @OfficeID and (ActualAssesstmentDate is not null or ActualAssesstmentDate <> '')
	--------order by  ActualAssesstmentDate desc
	--------)

	--------set @MaxActualAssessmentDate =  (SELECT TOP 1 ActualAssesstmentDate from VEDSchedules 
	-------- where  DATEPART(MM, ScheduledOn) = DATEPART(MM, DATEADD(MONTH, -1, @ScheduleOn))
 --------   AND  DATEPART(YYYY, ScheduledOn) = DATEPART(YYYY, DATEADD(MONTH, -1, @ScheduleOn))
 --------   and OfficeID = @OfficeID and (ActualAssesstmentDate is not null or ActualAssesstmentDate <> '')
	--------order by  ActualAssesstmentDate desc)

	--------Print @MaxScheduleOn

	--------Print @MaxActualAssessmentDate

	--------IF DATEDIFF(DD,@MaxScheduleOn, @MaxActualAssessmentDate)  Between -3 and  3
	--------BEGIN
	--------set @point = 3
	--------Print 'Scheduled VED and  Assessment not done difference -3 and 3 days'
	--------END
	--------ELSE IF DATEDIFF(DD,@MaxScheduleOn, @MaxActualAssessmentDate)  Between 4 and  14
	--------BEGIN
	--------set @point = 1
	--------Print 'Scheduled VED and  Assessment not done difference 4 and 14 days'
	--------END
	--------ELSE IF DATEDIFF(DD,@MaxScheduleOn, @MaxActualAssessmentDate)  Between 15 and  30
	--------BEGIN
	--------set @point = -1
	--------Print 'Scheduled VED and  Assessment not done difference 15 and 30 days'
	--------END
	--------ELSE IF DATEDIFF(DD,@MaxScheduleOn, @MaxActualAssessmentDate)  > 30
	--------BEGIN
	--------set @point = -3
	--------Print 'Scheduled VED and  Assessment not done difference 30 days'
	--------END
	--------END
	--------ELSE
	--------BEGIN
	--------set @point  = -3
	--------Print 'Scheduled VED but Assessment not done'
	--------END
	--------END
	--------ELSE
	--------BEGIN
	--------set @point = -9
	--------Print 'NOt Scheduled any VED'
	--------END
	--------SELECT @point

END