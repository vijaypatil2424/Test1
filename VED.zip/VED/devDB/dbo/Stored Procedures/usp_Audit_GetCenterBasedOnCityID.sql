﻿-- =============================================

-- Author:		<Sachin7 Jain>

-- Create date: <05-10-2017>

-- Description:	<To get the City Based on the State ID>

-- =============================================

CREATE PROCEDURE [dbo].[usp_Audit_GetCenterBasedOnCityID] 

	@City varchar(100),
	@officeCategoryID int

AS

BEGIN

	SELECT 

		ID,

		Title

	FROM	

		OfficeMaster

	WHERE

		UPPER(City) = UPPER(@City)

	AND
			
		OfficeCategoryID = @officeCategoryID
	ORDER BY 
		Title asc

END