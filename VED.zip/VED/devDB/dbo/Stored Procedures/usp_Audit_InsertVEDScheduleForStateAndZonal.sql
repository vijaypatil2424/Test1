﻿	   CREATE PROCEDURE [dbo].[usp_Audit_InsertVEDScheduleForStateAndZonal] 		--  vedID :  officeID : 808 scheduledOn : 18-09-2017 comments :  loggedInUser : madhuri.kamble
      --[usp_InsertUpdateVEDSchedule]  '','madhuri.kamble',808,'2017-09-18',''
     @UserID VARCHAR(200), @OfficeID INT = NULL, @ScheduledOn DATETIME = NULL, @AssessmentType VARCHAR(2) AS 
      BEGIN
       

	   INSERT into
                        VEDSchedules(officeID, ScheduledOn, ScheduledBy, AssessmentType) 
                     values
                        (
                           @OfficeID,
                           @ScheduledOn,
                           @UserID,
                           @AssessmentType 
                        )

			SELECT 'ErrorCode' = 1, 'ErrorMessage' = 'Success'

			

			SELECT SCOPE_IDENTITY() as VEDID

            -- if 2 not allowed
      END