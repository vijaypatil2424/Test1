﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE usp_DynamicQuery
	@SQLQuery varchar(Max)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	

	EXECUTE(@SQLQuery)

END