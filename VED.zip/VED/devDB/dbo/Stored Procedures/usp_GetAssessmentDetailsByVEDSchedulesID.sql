﻿----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
CREATE PROCEDURE [dbo].[usp_GetAssessmentDetailsByVEDSchedulesID] @VEDScheduledID int AS --[dbo].[usp_GetAssessmentDetailsByVEDSchedulesID] 230
BEGIN
   SELECT
      fam.Title AS FacilityArea,
      fdm.Title as FaciltyDetails,
      cm.Title as Criticality,
      Condition,
      ad.Comments,
      'IsImageAvailable' = 
      (
         SELECT
            dbo.[ufnToConfirmImagebyFacilityID]( @VEDScheduledID, fdm.ID) 
      )
,
      fdm.ID as FacilityID,
      @VEDScheduledID as 'VEDScheduleID' 
   from
      AssessmentDetails ad 
      JOIN
         FacilityAreaMaster fam 
         on fam.ID = ad.FacilityAreaID 
      JOIN
         FacilityDetailsMaster fdm 
         on fdm.ID = ad.FacilityDetailsID 
      JOIN
         CriticalityMaster cm 
         on cm.ID = ad.CriticalityID 
   where
      VEDScheduleID = @VEDScheduledID 
   order by
      fdm.id asc 
      Declare @OfficeID int 
   Set
      @OfficeID = 
      (
         Select
            OfficeId 
         from
            VEDschedules 
         where
            ID = @VEDScheduledID 
      )
      SELECT
         REPLACE(CONVERT(NVARCHAR, ScheduledOn, 106), ' ', '-') as ScheduledOn,
         ScheduledBy,
         REPLACE(CONVERT(NVARCHAR, ActualAssesstmentDate, 106), ' ', '-') as ActualAssesstmentDate,
         OM.Title as Center,
         zm.Title as Zone,
         --OM.Address as Address,
         OM.City,
         --OCM.TItle AS OfficeCategory,
         OT.Title AS OfficeType,
         --OM.CarpetArea AS CarpetArea,
         ved.VitalCount,
         ved.EssentialCount,
         ved.DesirableCount,
         ved.VitalNotApplicable,
         ved.EssentialNotApplicable,
         ved.DesirableNotApplicable,
         ved.TotalVEDByType,
         ved.VEDScore,
         ved.MAXVEDScore,
         COnvert(DECIMAL(10, 2), 
         (
(ved.VEDScore / ved.MAXVEDScore) * 100
         )
) AS 'VED Percentage' 
      FROM
         vedschedules ved 
         INNER JOIN
            OFFICEMASTER om 
            ON ved.OfficeID = om.ID 
         Inner join
            ZoneMaster zm 
            ON ZM.ID = OM.ZoneID 
         INNER JOIN
            OFFICECategoryMASTER OCM 
            ON OCM.ID = OM.OFFICECATEGORYID 
         Inner JOIn
            OfficeTypeMaster OT 
            ON OT.ID = OM.OFFICETYPEID 
      WHERE
         Ved.ID = @VEDScheduledID 
         AND ActualAssesstmentDate is not null 			--ORDER by
         --   ActualAssesstmentDate DESC 
END