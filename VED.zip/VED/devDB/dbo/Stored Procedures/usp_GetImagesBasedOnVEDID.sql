﻿-- =============================================
-- Author:		<Sachin Jain>
-- Create date: <28-09-2017>
-- Description:	<To get the images based on the VEDID and FacilityDetails ID>
-- =============================================
CREATE PROCEDURE [dbo].[usp_GetImagesBasedOnVEDID] 
	@VEDID int
   ,@FaciltyDetailsID int
AS
BEGIN
	

	SELECT Image,ImageName FROM 
	AssessmentImages
	WHERE 
	VEDScheduleID = @VEDID
	AND FacilityDetailID = @FaciltyDetailsID
	



END