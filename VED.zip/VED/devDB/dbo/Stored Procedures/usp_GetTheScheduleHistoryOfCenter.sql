﻿-- =============================================



-- Author:		<Sachin Jain>



-- Create date: <15-09-2017>



-- Description:	<To get the history of Scheduled against the center>



-- =============================================



CREATE PROCEDURE [dbo].[usp_GetTheScheduleHistoryOfCenter]  --5,97



	@count int



   ,@centerID int



AS



BEGIN





		 SELECT 

		 TOP(@count)

		 REPLACE(CONVERT(NVARCHAR,ScheduledOn, 106), ' ', '-') as ScheduledOn,

         ScheduledBy,

         ActualAssesstmentDate,

         OM.Title as Center,

         zm.Title as Zone,

         OM.Address as Address,

         OM.City,

         OCM.TItle AS OfficeCategory,

         OT.Title AS OfficeType,

         OM.CarpetArea AS CarpetArea, 

		 ved.VitalCount,

		 ved.EssentialCount,

		 ved.DesirableCount,

		 ved.VitalNotApplicable,

		 ved.EssentialNotApplicable,

		 ved.DesirableNotApplicable,

		 ved.TotalVEDByType,

		 ved.VEDScore,

		 ved.MAXVEDScore,

		 VED.ID as VEDID

      FROM

         vedschedules ved 

         INNER JOIN

            OFFICEMASTER om 

            ON ved.OfficeID = om.ID 

         Inner join

            ZoneMaster zm 

            ON ZM.ID = OM.ZoneID 

         INNER JOIN

            OFFICECategoryMASTER OCM 

            ON OCM.ID = OM.OFFICECATEGORYID 

         Inner JOIn

            OfficeTypeMaster OT 

            ON OT.ID = OM.OFFICETYPEID  

        WHERE om.ID =@centerID

		AND

				ActualAssesstmentDate is not null

		AND
				VED.AssessmentType = 1

		ORDER by

		ActualAssesstmentDate DESC

END







--Select * from VEDSchedules