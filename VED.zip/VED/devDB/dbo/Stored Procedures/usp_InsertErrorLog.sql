﻿-- =============================================
-- Author:		<Sachin Jain>
-- Create date: <14-09-2017>
-- Description:	<To insert data in log table>
-- =============================================
CREATE PROCEDURE [dbo].[usp_InsertErrorLog]  
	 @Type int = NULL
	,@MethodName varchar(200) = NULL
	,@Request varchar(max) = NULL
	,@Response varchar(max) = NULL
	,@CreatedBy varchar(200) = NULL
	,@CreatedOn datetime = NULL
	,@ExecutionContext uniqueidentifier = NULL
	,@RequestType int = NULL
AS
BEGIN
	
	INSERT INTO 
				ErrorLog 
				(	
					 Type 
					,MethodName 
					,Request 
					,Response 
					,CreatedBy 
					,CreatedOn
					,ExecutionContext
					,RequestType

				)
	VALUES		(
					 @Type 
					,@MethodName 
					,@Request 
					,@Response 
					,@CreatedBy 
					,GetDAte()
					,@ExecutionContext
					,@RequestType
				)
END