﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_InsertUpdateAssessmentImages] 
	-- @VEDScheduleID int = NULL
	--,@FacilityDetailID int = NULL
	--,@Image image = NULL
	--,@ImageType nvarchar(100) = NULL
	--,@ImageSize bigint = NULL
	--,@ImageName varchar(500) = NULL
	--,@CreatedOn datetime  = NULL
	--,@CreatedBy varchar(200) = NULL
	--,@Type varchar(100) = NULL
	--@Data [AssessmentImagesType] ReadOnly 
	@Data [AssessmentImagesType] ReadOnly  

AS
BEGIN

				INSERT INTO	
				AssessmentImages
								(
								VEDScheduleID
								,FacilityDetailID
								,Image
								,CreatedOn
								,CreatedBy
								,ImageName
								)
				SELECT
								
								 VEDScheduleID
								,FacilityDetailID
								,Image
								,GETDATE()
								,CreatedBy
								,ImageName
								

				FROM
								@Data
	

END