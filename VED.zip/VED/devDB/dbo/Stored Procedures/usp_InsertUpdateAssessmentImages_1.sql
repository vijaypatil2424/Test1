﻿-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[usp_InsertUpdateAssessmentImages_1] 
	 @VEDScheduleID int = NULL
	,@FacilityDetailID int = NULL
	,@Image image = NULL
	,@ImageName varchar(500) = NULL
AS
BEGIN

				INSERT INTO	
				AssessmentImages
								(
								 VEDScheduleID
								,FacilityDetailID
								,Image
								,ImageName
								)
				VALUES
								(
								 @VEDScheduleID
								,@FacilityDetailID
								,@Image
								,@ImageName
								)
								
END