﻿-- =============================================
-- Author:		<Sachin Jain>
-- Create date: <12-09-2017>
-- Description:	<To Insert and Update the Facility Details>
-- =============================================
CREATE PROCEDURE [dbo].[usp_InsertUpdateFacilityDetails]
	 @ID int  = NULL
	,@FacilityAreaID int = NULL
	,@Title varchar(100) = NULL
	,@CriticalityID int = NULL
	,@OfficeTypeID int = NULL
	,@Comments nvarchar(max) = null
	,@CreatedBy varchar(200) = NULL
	,@ModifiedBy varchar(200) = NULL
AS
BEGIN
	
	IF EXISTS (SELECT
					ID
				FROM
					FacilityDetailsMaster
				WHERE
					ID=@ID)

	BEGIN
	UPDATE
		FacilityDetailsMaster
	SET
		 FacilityAreaID  =@FacilityAreaID
		,Title 			=@Title 			
		,CriticalityID 	=@CriticalityID 
		,OfficeTypeID	   =@OfficeTypeID		
		,ModifiedOn 		=GETDATE() 
		,Comments = @Comments		
		,ModifiedBy 		=@ModifiedBy 
	WHERE	
		ID=@ID	

			
	END
	ELSE
	BEGIN
	--INSERT
	INSERT INTO 
		FacilityDetailsMaster
							(
							 ID
							,FacilityAreaID 
							,Title 			
							,CriticalityID 	
							,OfficeTypeID	
							,Comments
							,CreatedBy 	
							,CreatedOn 	
							)
	VALUES
							(
							 @ID
							,@FacilityAreaID
							,@Title 		
							,@CriticalityID 
							,@OfficeTypeID
							,@Comments
							,@CreatedBy	 
							,GETDATE()
							)
	END
END