﻿-- =============================================
-- Author:		<Sachin Jain>
-- Create date: <12/09/2017>
-- Description:	<Updating the Master from the Event Listener>
-- =============================================
CREATE PROCEDURE [dbo].[usp_InsertUpdateMasterByType]
 @ID int 
,@Title varchar(255)
,@UserId varchar(100)
,@ZonalHeadID varchar(100) = null
,@type varchar(100)
,@Initials char = null
,@StateHeadID varchar(200) = null
AS
BEGIN
	
	IF UPPER(@type) = 'ZONE'
	BEGIN

	IF EXISTS (SELECT 
					ID
				FROM
					ZoneMaster
				WHERE 
					ID = @ID)

	BEGIN
	UPDATE
		ZoneMaster
	SET 
		Title = @Title, ZonalHeadID = @ZonalHeadID , ModifiedBy = @UserId, ModifiedOn = GETDATE()
	WHERE
		ID = @ID
	END
	ELSE	
	BEGIN
	INSERT INTO ZoneMaster(ID,Title,ZonalHeadID,CreatedBy,CreatedOn)
	VALUES(@ID,@Title,@ZonalHeadID,@UserId,GETDATE())
	END
	END
	IF UPPER(@type) = 'OFFICECATEGORY'
	BEGIN

	IF EXISTS (SELECT 
					ID
				FROM
					OfficeCategoryMaster
				WHERE 
					ID = @ID)

	BEGIN
	UPDATE
		OfficeCategoryMaster
	SET 
		Title = @Title, ModifiedBy = @UserId, ModifiedOn = GETDATE()
	WHERE
		ID = @ID
	END
	ELSE	
	BEGIN
	INSERT INTO OfficeCategoryMaster(ID,Title,CreatedBy,CreatedOn)
	VALUES(@ID,@Title,@UserId,GETDATE())
	END
	END
	IF UPPER(@type) = 'OFFICETYPE'
	BEGIN

	IF EXISTS (SELECT 
					ID
				FROM
					OfficeTypeMaster
				WHERE 
					ID = @ID)

	BEGIN
	UPDATE
		OfficeTypeMaster
	SET 
		Title = @Title, ModifiedBy = @UserId, ModifiedOn = GETDATE()
	WHERE
		ID = @ID
	END
	ELSE	
	BEGIN
	INSERT INTO OfficeTypeMaster(ID,Title,CreatedBy,CreatedOn)
	VALUES(@ID,@Title,@UserId,GETDATE())
	END
	END
	IF UPPER(@type) = 'STATE'
	BEGIN

	IF EXISTS (SELECT 
					ID
				FROM
					StateMaster
				WHERE 
					ID = @ID)

	BEGIN
	UPDATE
		StateMaster
	SET 
		Title = @Title, StateHeadID = @StateHeadID, ModifiedBy = @UserId, ModifiedOn = GETDATE()
	WHERE
		ID = @ID
	END
	ELSE	
	BEGIN
	INSERT INTO StateMaster(ID,Title,StateHeadID, CreatedBy,CreatedOn)
	VALUES(@ID,@Title,@StateHeadID, @UserId,GETDATE())
	END
	END
	IF UPPER(@type) = 'TYPE'
	BEGIN

	IF EXISTS (SELECT 
					ID
				FROM
					TypeMaster
				WHERE 
					ID = @ID)

	BEGIN
	UPDATE
		TypeMaster
	SET 
		Title = @Title, ModifiedBy = @UserId, ModifiedOn = GETDATE()
	WHERE
		ID = @ID
	END
	ELSE	
	BEGIN
	INSERT INTO TypeMaster(ID,Title,CreatedBy,CreatedOn)
	VALUES(@ID,@Title,@UserId,GETDATE())
	END
	END
	IF UPPER(@type) = 'CRITICALITY'
	BEGIN

	IF EXISTS (SELECT 
					ID
				FROM
					CriticalityMaster
				WHERE 
					ID = @ID)

	BEGIN
	UPDATE
		CriticalityMaster
	SET 
		Title = @Title, ModifiedBy = @UserId,Initials =@Initials, ModifiedOn = GETDATE()
	WHERE
		ID = @ID
	END
	ELSE	
	BEGIN
	INSERT INTO CriticalityMaster(ID,Title,Initials, CreatedBy,CreatedOn)
	VALUES(@ID,@Title,@Initials,@UserId,GETDATE())
	END
	END
	IF UPPER(@type) = 'FACILITYAREA'
	BEGIN

	IF EXISTS (SELECT 
					ID
				FROM
					FacilityAreaMaster
				WHERE 
					ID = @ID)

	BEGIN
	UPDATE
		FacilityAreaMaster
	SET 
		Title = @Title, ModifiedBy = @UserId, ModifiedOn = GETDATE()
	WHERE
		ID = @ID
	END
	ELSE	
	BEGIN
	INSERT INTO FacilityAreaMaster(ID,Title, CreatedBy,CreatedOn)
	VALUES(@ID,@Title,@UserId,GETDATE())
	END
	END
END