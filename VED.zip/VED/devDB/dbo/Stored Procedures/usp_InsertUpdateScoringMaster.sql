﻿CREATE PROCEDURE [dbo].[usp_InsertUpdateScoringMaster] 
	 @ID int  = NULL
	,@OfficeTypeID int = NULL
	,@CriticalityID int = NULL
	,@FacilityCheckPoints int = NULL
	,@Good int = NULL
	,@Poor int = NULL
	,@NotWorking int = NULL
	,@NotAvailable int = NULL
	,@ModifiedBy varchar(200) = NULL
AS
BEGIN
	
	IF NOT EXISTS (SELECT ID from AssessmentScoringMaster where ID= @ID)
	BEGIN
	INSERT INTO AssessmentScoringMaster(ID,FacilityCheckPoints,OfficeTypeID,CriticalityID,Good,Poor,NotWorking,NotAvailable,CreatedOn,CreatedBy)
	VALUES (@ID,@FacilityCheckPoints,@OfficeTypeID,@CriticalityID,@Good,@Poor,@NotWorking,@NotAvailable,GETDATE(),@ModifiedBy)
	END
	ELSE
	BEGIN


	UPDATE
		AssessmentScoringMaster
	SET
		 OfficeTypeID = @OfficeTypeID 
		,CriticalityID  =@CriticalityID  
		,FacilityCheckPoints= @FacilityCheckPoints  
		,Good  = @Good  
		,Poor  = @Poor  
		,NotWorking  = @NotWorking  
		,NotAvailable  = @NotAvailable 
		,ModifiedBy =@ModifiedBy
	WHERE
		ID=@ID
  END
END