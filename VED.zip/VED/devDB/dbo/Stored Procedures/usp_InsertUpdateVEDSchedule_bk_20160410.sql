﻿
	   CREATE PROCEDURE [dbo].[usp_InsertUpdateVEDSchedule_bk_20160410] 	
	   
	 --  vedID :  officeID : 808 scheduledOn : 18-09-2017 comments :  loggedInUser : madhuri.kamble
	   	--[usp_InsertUpdateVEDSchedule]  '','madhuri.kamble',808,'2017-09-18',''
      @ID INT = NULL, @UserID VARCHAR(200), @OfficeID INT = NULL, @ScheduledOn DATETIME = NULL, @Comments VARCHAR(max) = NULL , @AssessmentType VARCHAR(2)
	  AS 
      BEGIN
         --To get all the VED scheduled of current month and Year for the loggedinUser
         IF EXISTS 
         (
            SELECT
               ID 
            FROM
               VEDSchedules 
            WHERE
               ID = @ID 
         )
         BEGIN


		 IF EXISTS 
                                          (
                                             SELECT
                                                ID 
                                             from
                                                vedschedules 
                                             where
                                                OfficeID = @OfficeID 
                                                AND DATEPART(MM, ScheduledOn) = DATEPART(MM, @ScheduledOn) 
                                                and DATEPART(YYYY, ScheduledOn) = DATEPART(YYYY, @ScheduledOn) 
                                                and DATEPART(DD, ScheduledOn) = DATEPART(DD, @ScheduledOn) 
                                          )
                                          begin
                                             select
                                                'ErrorCode' = 0,
                                                'ErrorMessage' = 'Already an Assessments is scheduled for the selected center on the provided date' 
                                          end
                                          else
                                             begin
											   --Update
            DECLARE @PreviousDate DATETIME 
            SET
               @PreviousDate = 
               (
                  SELECT
                     ScheduledOn 
                  FROM
                     VEDSchedules 
                  WHERE
                     ID = @ID 
               )
               INSERT INTO
                  VEDScheduleAudit (VEDScheduleID, PreviousScheduleDate, NewScheduleDate, Comments, Scheduledby, ModifiedOn, ModifiedBy) 
               VALUES
                  (
                     @ID,
                     @PreviousDate,
                     @ScheduledOn,
                     @comments,
                     @UserID,
                     Getdate(),
                     @UserID 
                  )
                  UPDATE
                     VEDSchedules 
                  SET
                     ScheduledOn = @ScheduledOn,
                     ScheduledBy = @UserID,
                     ModifiedBy = @UserID,
                     ModifiedOn = GetDate() 
                  WHERE
                     ID = @ID 
                     SELECT
                        'ErrorCode' = 1,
                        'ErrorMessage' = 'Record Inserted/Updated successfully' 
											 END



          
         END
         ELSE
            BEGIN
               Declare @CenterCount INT 
                     SET
                        @CenterCount = 
                        (
                           Select
                              count(*) 
                           FROM
                              OfficeMaster 
                           WHERE
                              OfficeAdmins LIKE '%' + @UserID + '%'
                        )
                        IF @CenterCount > 7 
                        BEGIN
                           IF EXISTS 
                           (
                              SELECT
                                 ID 
                              from
                   vedschedules 
                              where
                                 OfficeID = @OfficeID 
                                 AND DATEPART(MM, ScheduledOn) = DATEPART(MM, @ScheduledOn) 
                                 and DATEPART(YYYY, ScheduledOn) = DATEPART(YYYY, @ScheduledOn) 
                           )
                           BEGIN
                              SELECT
                                 'ErrorCode' = 0,
                                 'ErrorMessage' = 'An Assessment is already scheduled for the selected center' 
                           END
                           ELSE
                              BEGIN
                                 INSERT INTO
                                    vedschedules (officeid, scheduledon, scheduledby,AssessmentType) 
                                 VALUES
                                    (
                                       @OfficeID,
                                       @ScheduledOn,
                                       @UserID ,
									   @AssessmentType
                                    )
                                    SELECT
                                       'ErrorCode' = 1,
                                       'ErrorMessage' = 'Record Inserted/Updated successfully' 
                              END
                        END
                        ELSE
                           BEGIN
                              -- check count of VED schuled for the current mintb 
                              declare @countofvedscheduled int 
                                    set
                                       @countofvedscheduled = 
                                       (
                                          SELECT
                                             count(*) 
                                          from
                                             vedschedules 
                                          where
                                             OfficeID = @OfficeID 
                                             AND DATEPART(MM, ScheduledOn) = DATEPART(MM, @ScheduledOn) 
                                             and DATEPART(YYYY, ScheduledOn) = DATEPART(YYYY, @ScheduledOn) 
                                       )
                                       if @countofvedscheduled < 2 
                                       BEGIN
                                          IF EXISTS 
                                          (
                                             SELECT
                                                ID 
                                             from
                                                vedschedules 
                                             where
                                                OfficeID = @OfficeID 
                                                AND DATEPART(MM, ScheduledOn) = DATEPART(MM, @ScheduledOn) 
                                                and DATEPART(YYYY, ScheduledOn) = DATEPART(YYYY, @ScheduledOn) 
                                                and DATEPART(DD, ScheduledOn) = DATEPART(DD, @ScheduledOn) 
                                          )
                                          begin
                                             select
                                                'ErrorCode' = 0,
                                                'ErrorMessage' = 'Already an Assessments is scheduled for the selected center on the provided date' 
                                          end
                                          else
                                             begin
                                                INSERT into
                                                   VEDSchedules(officeID, ScheduledOn, ScheduledBy,AssessmentType) 
                                                values
                                 (
                                                      @OfficeID,
                                                      @ScheduledOn,
                                                      @UserID,
													  @AssessmentType
                                                   )
                                                   select
                                                      'ErrorCode' = 1,
                                                      'ErrorMessage' = 'Record Inserted/Updated Successfully' 
                                             end
                                       END
                                       ELSE
                                          BEGIN
                                             SELECT
                                                'ErrorCode' = 0,
                                                'ErrorMessage' = 'Already Two Assessments are scheduled for the selected center' 
                                          END
                                          -- if 2 not allowed
                                          -- else then insert
                           END
            END
      END