﻿-- =============================================



CREATE PROCEDURE [dbo].[usp_Report_GetAssessmentDetailsByVEDSchedulesIDForPoor] --152



@VEDScheduledID int 



AS



BEGIN



	



		SELECT 

		ad.ID as ID,



		fam.Title AS FacilityArea ,



		fdm.Title as FacilityDetails,



		 cm.Title as Criticality,



		 Condition,



		 ad.Comments,



		 fdm.ID as FacilityID,



		 'IsImageAvailable' = (SELECT  dbo.[ufnToConfirmImagebyFacilityID]( @VEDScheduledID,fdm.ID)),



		 @VEDScheduledID as 'VEDScheduleID',



		  ISNUll(ad.IsMailSent,0) as IsMailSent,



		 ad.MailComments,



		 ad.MailSendDate,

		 Om.EFacilityHelpDeskEmail



		from AssessmentDetails ad



		JOIN FacilityAreaMaster fam



		on fam.ID = ad.FacilityAreaID



		JOIN FacilityDetailsMaster fdm on



		fdm.ID = ad.FacilityDetailsID



		JOIN CriticalityMaster cm



		on cm.ID = ad.CriticalityID

		JOIN VEDSchedules VED 
		on VED.ID = ad.VEDScheduleID

		JoIn

		OfficeMaster om on

		OM.ID = VED.OfficeID


		 

		where



		VEDScheduleID = @VEDScheduledID



		AND  UPPER(ad.Condition) = 'POOR'



		order by fdm.id asc







END





--Select * from 