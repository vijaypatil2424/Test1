﻿-- =============================================
-- Author:		<Sachin Jain>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE usp_Report_GetImages 

@ID int
--@FacilityDetailsID int

AS
BEGIN

	Select Image,imageName from AssessmentImages
	Where ID = @ID

END