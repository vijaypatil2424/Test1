﻿

CREATE PROCEDURE usp_Report_GetMailDetails 

	@VEDScheduleID varchar(50)

AS

BEGIN

	

SELECT ZM.Title as Zone,

SM.Title as State,

OM.city,

OM.Title as CEnter,

VED.ScheduledBy as 'Created By',

SM.StateHeadID 

   FROM

VEDSchedules VED join 

OfficeMaster OM on

OM.ID =  VED.OfficeID

JOIN  StateMaster SM

on

SM.ID = OM.StateID

JOIN ZoneMaster ZM

 ON ZM.ID = OM.ZoneID

 Where 

 VED.ID = @VEDScheduleID

END