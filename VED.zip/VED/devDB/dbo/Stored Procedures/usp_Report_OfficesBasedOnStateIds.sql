﻿Create PROCEDURE usp_Report_OfficesBasedOnStateIds 
--usp_Report_StatesBasedOnZoneIds 
	@StateIDs varchar(100)
AS
BEGIN
	Select Distinct OM.ID, OM.Title  from OfficeMaster OM Join StateMaster SM
	On om.StateID = sm.ID
	where OM.stateId  IN (
		    SELECT Value
		    FROM funcListToTableInt(@StateIDs,',')
                   )
END