﻿CREATE PROCEDURE usp_Report_StatesBasedOnZoneIds 
--usp_Report_StatesBasedOnZoneIds 
	@ZoneIDs varchar(100)
AS
BEGIN
	Select Distinct OM.StateID, SM.Title  from OfficeMaster OM Join StateMaster SM
	On om.StateID = sm.ID
	where OM.ZoneID  IN (
		    SELECT Value
		    FROM funcListToTableInt(@ZoneIDs,',')
                   )
END