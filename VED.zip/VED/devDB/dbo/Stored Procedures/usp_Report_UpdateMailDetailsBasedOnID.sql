﻿-- =============================================

-- Author:		<Author,,Name>

-- Create date: <Create Date,,>

-- Description:	<Description,,>

-- =============================================

CREATE PROCEDURE usp_Report_UpdateMailDetailsBasedOnID 

	 @MailComments varchar(max)

	,@MailSentToEmailID varchar(20)

	,@IsMailSent bit

	,@ID int

	,@UserID varchar(200)

AS

BEGIN

	

	Update AssessmentDetails

	set 

		IsMailSent = @IsMailSent,

		ModifiedBy = @UserID,

		ModifiedOn = GETDATE(),

		MailSendDate = GETDATE(),

		MailSentToEmailID = @MailSentToEmailID,

		MailComments = @MailComments



	Where ID = @ID



	Select '1' as ErrorCode , 'Success' as ErrorMessage





END