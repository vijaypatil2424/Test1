﻿CREATE PROCEDURE [dbo].[usp_Report_VEDDetailsBasedOnOfficeIds] 
--usp_Report_StatesBasedOnZoneIds 
	@OfficeIDs varchar(max),
	@fromDate varchar(100) = null,
	@toDate varchar(100) = null
AS
BEGIN


if @fromDate is Not Null and @toDate is not null
BEGIN
Select VED.ID as VEDID, OM.ID as CenterID, ZM.Title as Zone, SM.Title as State, City,OM.Title as Office, 

	'Good' = (Select count(*) from AssessmentDetails where VEDScheduleID = VED.ID and  Condition= 'Good'),
	'Poor' = (Select count(*) from AssessmentDetails where VEDScheduleID = VED.ID and  Condition= 'Poor'),
	'Not Working' = (Select count(*) from AssessmentDetails where VEDScheduleID = VED.ID and  Condition= 'Not Working'),
	'Not Applicable' = (Select count(*) from AssessmentDetails where VEDScheduleID = VED.ID and  Condition= 'Not Applicable'),
	'Not Available' = (Select count(*) from AssessmentDetails where VEDScheduleID = VED.ID and  Condition= 'Not Available'),
 --   CASE  When 'Good' = '0' Then  '-' else 'Good' END as  'GoodValue'
	  REPLACE(CONVERT(NVARCHAR,VED.ScheduledOn, 106), ' ', '-') as ScheduledOn, 	
	 ISNULL(REPLACE(CONVERT(NVARCHAR,VED.ActualAssesstmentDate, 106), ' ', '-'),'-') as ActualAssesstmentDate ,
	  VED.ScheduledBy,
	 ISNULL(CAST(vitalcount as Varchar(50)),'-') as vitalcount,
	 ISNULL(CAST(EssentialCount as Varchar(50)),'-') as EssentialCount,
	 ISNULL(CAST(DesirableCount as Varchar(50)),'-') as DesirableCount, 
	 ISNULL(CAST(VEDScore as Varchar(50)),'-') as VEDScore,
	 ISNULL(CAST(MAXVEDScore as Varchar(50)),'-') as MAXVEDScore,
	 ISNULL(CAST(((VEDScore/MAXVEDScore)*100) as Varchar(50)),'-') as VEDPER,
	 'AssessmentType' = (SELECT CASE When AssessmentType = 1 then 'Area'  WHEN AssessmentType = 2 then 'State'  Else 'Zone' END  )
	  from OfficeMaster OM
	JOIN STATEMASTER SM On SM.ID = OM.StateID
	JOIN ZoneMaster ZM ON ZM.ID = om.ZoneID
	JOIN VEDSchedules VED on VED.OfficeID  = OM.ID
	where om.ID  IN (
		    SELECT Value
		    FROM funcListToTableInt(@OfficeIDs,',')
                   )
AND
		(CAST(ScheduledOn AS DATE) >= CAST(@fromDate AS DATE) and  CAST(ScheduledOn AS DATE) <=  CAST(@toDate AS DATE))
	ORDER BY VED.ScheduledOn,OM.Title desc
END
ELSE
BEGIN

	Select VED.ID as VEDID, OM.ID as CenterID, ZM.Title as Zone, SM.Title as State, City,OM.Title as Office, 

	'Good' = (Select count(*) from AssessmentDetails where VEDScheduleID = VED.ID and  Condition= 'Good'),
	'Poor' = (Select count(*) from AssessmentDetails where VEDScheduleID = VED.ID and  Condition= 'Poor'),
	'Not Working' = (Select count(*) from AssessmentDetails where VEDScheduleID = VED.ID and  Condition= 'Not Working'),
	'Not Applicable' = (Select count(*) from AssessmentDetails where VEDScheduleID = VED.ID and  Condition= 'Not Applicable'),
	'Not Available' = (Select count(*) from AssessmentDetails where VEDScheduleID = VED.ID and  Condition= 'Not Available'),
 --   CASE  When 'Good' = '0' Then  '-' else 'Good' END as  'GoodValue'
	  REPLACE(CONVERT(NVARCHAR,VED.ScheduledOn, 106), ' ', '-') as ScheduledOn, 	
	 ISNULL(REPLACE(CONVERT(NVARCHAR,VED.ActualAssesstmentDate, 106), ' ', '-'),'-') as ActualAssesstmentDate ,
	  VED.ScheduledBy,
	 ISNULL(CAST(vitalcount as Varchar(50)),'-') as vitalcount,
	 ISNULL(CAST(EssentialCount as Varchar(50)),'-') as EssentialCount,
	 ISNULL(CAST(DesirableCount as Varchar(50)),'-') as DesirableCount, 
	 ISNULL(CAST(VEDScore as Varchar(50)),'-') as VEDScore,
	 ISNULL(CAST(MAXVEDScore as Varchar(50)),'-') as MAXVEDScore,
	 ISNULL(CAST(((VEDScore/MAXVEDScore)*100) as Varchar(50)),'-') as VEDPER,
	 'AssessmentType' = (SELECT CASE When AssessmentType = 1 then 'Area'  WHEN AssessmentType = 2 then 'State'  Else 'Zone' END  )
	  from OfficeMaster OM
	JOIN STATEMASTER SM On SM.ID = OM.StateID
	JOIN ZoneMaster ZM ON ZM.ID = om.ZoneID
	JOIN VEDSchedules VED on VED.OfficeID  = OM.ID
	where om.ID  IN (
		    SELECT Value
		    FROM funcListToTableInt(@OfficeIDs,',')
                   )
	ORDER BY VED.ScheduledOn,OM.Title desc
	END
END