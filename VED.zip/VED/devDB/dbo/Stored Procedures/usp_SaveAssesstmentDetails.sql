﻿-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-- =============================================
-- Author:		<Sachin Jain>
-- Create date: <15-09-2017>
-- Description:	<To store the assestment details>
-- =============================================
CREATE PROCEDURE [dbo].[usp_SaveAssesstmentDetails]
@Data [AssessmentDetailsType] ReadOnly   ,
@VEDScheduleID int
AS
BEGIN
--SELECT '1'

	INSERT 
	INTO	
		AssessmentDetails
						(
						 [VEDScheduleID]  
						,[FacilityAreaID]  
						,[FacilityDetailsID]  
						,[CriticalityID]  
						,[Condition]  
						,[AssessmentDoneBy]  
						,[AssessmentDate]  
						,[Comments] 
						,[AssessmentType]  
						)
	SELECT 
			             [VEDScheduleID]  
						,[FacilityAreaID]  
						,[FacilityDetailsID]  
						,[CriticalityID]  
						,[Condition]  
						,[AssessmentDoneBy]  
						,GETDATE() 
						,[Comments]
						,[AssessmentType] 

	FROM
		@Data
	UPDATE
		VEDSchedules
	SET
		ActualAssesstmentDate = GETDATE()
	WHERE 
		ID = @VEDScheduleID
END