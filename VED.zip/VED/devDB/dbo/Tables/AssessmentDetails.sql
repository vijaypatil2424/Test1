﻿CREATE TABLE [dbo].[AssessmentDetails] (
    [ID]                INT           IDENTITY (1, 1) NOT NULL,
    [VEDScheduleID]     INT           NOT NULL,
    [FacilityAreaID]    INT           NOT NULL,
    [FacilityDetailsID] INT           NOT NULL,
    [CriticalityID]     INT           NOT NULL,
    [Condition]         VARCHAR (20)  NOT NULL,
    [AssessmentDoneBy]  VARCHAR (200) NOT NULL,
    [AssessmentDate]    DATETIME      NOT NULL,
    [Comments]          VARCHAR (500) NOT NULL,
    [AssessmentType]    INT           NULL,
    [MailComments]      VARCHAR (MAX) NULL,
    [MailSendDate]      DATETIME      NULL,
    [MailSentToEmailID] VARCHAR (250) NULL,
    [IsMailSent]        BIT           NULL,
    [ModifiedBy]        VARCHAR (200) NULL,
    [ModifiedOn]        DATETIME      NULL,
    CONSTRAINT [PK_AssessmentDetails] PRIMARY KEY CLUSTERED ([ID] ASC)
);

