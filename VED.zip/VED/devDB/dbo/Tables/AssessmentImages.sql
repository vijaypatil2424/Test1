﻿CREATE TABLE [dbo].[AssessmentImages] (
    [ID]               INT           IDENTITY (1, 1) NOT NULL,
    [VEDScheduleID]    INT           NULL,
    [FacilityDetailID] INT           NULL,
    [Image]            IMAGE         NULL,
    [ImageName]        VARCHAR (500) NULL,
    [CreatedOn]        DATETIME      CONSTRAINT [DF_AssessmentImages_CreatedOn] DEFAULT (getdate()) NULL,
    [CreatedBy]        VARCHAR (200) NULL,
    CONSTRAINT [PK_AssessmentImages] PRIMARY KEY CLUSTERED ([ID] ASC)
);

