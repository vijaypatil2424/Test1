﻿CREATE TABLE [dbo].[AssessmentImages_1] (
    [ID]               INT             IDENTITY (1, 1) NOT NULL,
    [VEDScheduleID]    INT             NULL,
    [FacilityDetailID] INT             NULL,
    [Image]            VARBINARY (MAX) NULL,
    [ImageName]        VARCHAR (500)   NULL,
    [CreatedOn]        DATETIME        CONSTRAINT [DF_AssessmentImages_1_CreatedOn] DEFAULT (getdate()) NULL,
    [CreatedBy]        VARCHAR (200)   NULL,
    CONSTRAINT [PK_AssessmentImages_1] PRIMARY KEY CLUSTERED ([ID] ASC)
);

