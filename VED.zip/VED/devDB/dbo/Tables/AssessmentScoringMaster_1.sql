﻿CREATE TABLE [dbo].[AssessmentScoringMaster_1] (
    [ID]                  INT           IDENTITY (1, 1) NOT NULL,
    [OfficeTypeID]        INT           NOT NULL,
    [CriticalityID]       INT           NULL,
    [FacilityCheckPoints] INT           NULL,
    [Good]                INT           NULL,
    [Poor]                INT           NULL,
    [NotWorking]          INT           NULL,
    [NotAvailable]        INT           NULL,
    [CreatedOn]           DATETIME      NULL,
    [CreatedBy]           VARCHAR (200) NULL,
    [ModifiedOn]          DATETIME      NULL,
    [ModifiedBy]          VARCHAR (200) NULL
);

