﻿CREATE TABLE [dbo].[CriticalityMaster] (
    [ID]         INT           NOT NULL,
    [Title]      VARCHAR (20)  NULL,
    [Initials]   CHAR (1)      NULL,
    [CreatedOn]  DATETIME      CONSTRAINT [DF_CriticalityMaster_CreatedOn] DEFAULT (getdate()) NULL,
    [CreatedBy]  VARCHAR (200) NULL,
    [ModifiedOn] DATETIME      NULL,
    [ModifiedBy] VARCHAR (200) NULL
);

