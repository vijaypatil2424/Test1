﻿CREATE TABLE [dbo].[ErrorLog] (
    [ID]               INT              IDENTITY (1, 1) NOT NULL,
    [Type]             INT              NOT NULL,
    [MethodName]       VARCHAR (200)    NULL,
    [Request]          VARCHAR (MAX)    NULL,
    [Response]         VARCHAR (MAX)    NULL,
    [CreatedBy]        VARCHAR (200)    NULL,
    [CreatedOn]        DATETIME         CONSTRAINT [DF_ErrorLog_CreatedOn] DEFAULT (getdate()) NULL,
    [ExecutionContext] UNIQUEIDENTIFIER NULL,
    [RequestType]      INT              NULL,
    CONSTRAINT [PK_ErrorLog] PRIMARY KEY CLUSTERED ([ID] ASC)
);


GO
EXECUTE sp_addextendedproperty @name = N'MS_Description', @value = N'1 :  Information  0: Error', @level0type = N'SCHEMA', @level0name = N'dbo', @level1type = N'TABLE', @level1name = N'ErrorLog', @level2type = N'COLUMN', @level2name = N'Type';

