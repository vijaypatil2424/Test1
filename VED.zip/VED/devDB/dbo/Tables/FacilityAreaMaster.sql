﻿CREATE TABLE [dbo].[FacilityAreaMaster] (
    [ID]         INT           NOT NULL,
    [Title]      VARCHAR (100) NOT NULL,
    [CreatedOn]  DATETIME      CONSTRAINT [DF_FacilityAreaMaster_CreatedOn] DEFAULT (getdate()) NULL,
    [CreatedBy]  VARCHAR (200) NULL,
    [ModifiedOn] DATETIME      NULL,
    [ModifiedBy] VARCHAR (200) NULL,
    CONSTRAINT [PK_FacilityAreaMaster] PRIMARY KEY CLUSTERED ([ID] ASC)
);

