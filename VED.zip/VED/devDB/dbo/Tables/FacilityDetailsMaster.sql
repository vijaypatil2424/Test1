﻿CREATE TABLE [dbo].[FacilityDetailsMaster] (
    [ID]             INT           NOT NULL,
    [FacilityAreaID] INT           NOT NULL,
    [Title]          VARCHAR (100) NOT NULL,
    [CriticalityID]  INT           NOT NULL,
    [OfficeTypeID]   INT           NULL,
    [Comments]       VARCHAR (MAX) NULL,
    [CreatedOn]      DATETIME      CONSTRAINT [DF_FacilityDetailsMaster_CreatedOn] DEFAULT (getdate()) NULL,
    [CreatedBy]      VARCHAR (200) NULL,
    [ModifiedOn]     DATETIME      NULL,
    [ModifiedBy]     VARCHAR (200) NULL,
    CONSTRAINT [PK_FacilityDetailsMaster] PRIMARY KEY CLUSTERED ([ID] ASC)
);

