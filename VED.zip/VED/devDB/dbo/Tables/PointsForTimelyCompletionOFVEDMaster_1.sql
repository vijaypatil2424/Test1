﻿CREATE TABLE [dbo].[PointsForTimelyCompletionOFVEDMaster_1] (
    [ID]                     INT           IDENTITY (1, 1) NOT NULL,
    [OfficeTypeID]           INT           NULL,
    [OnTime]                 INT           NULL,
    [WithAcceptableDelay]    INT           NULL,
    [WithNotAcceptableDelay] INT           NULL,
    [NotDone]                INT           NULL,
    [NotScheduled]           INT           NULL,
    [CreatedOn]              DATETIME      NULL,
    [CreatedBy]              VARCHAR (200) NULL,
    [ModifiedOn]             DATETIME      NULL,
    [ModifiedBy]             VARCHAR (200) NULL
);

