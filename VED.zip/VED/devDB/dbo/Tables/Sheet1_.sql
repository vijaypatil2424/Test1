﻿CREATE TABLE [dbo].[Sheet1$] (
    [Location Id]            FLOAT (53)     NULL,
    [* Location Description] NVARCHAR (255) NULL,
    [Location Type]          NVARCHAR (255) NULL,
    [* Latitude]             FLOAT (53)     NULL,
    [* Longitude]            FLOAT (53)     NULL,
    [OfficeID]               NVARCHAR (255) NULL,
    [Geo Sams Code]          NVARCHAR (255) NULL,
    [LOC Occupied Code]      FLOAT (53)     NULL
);

