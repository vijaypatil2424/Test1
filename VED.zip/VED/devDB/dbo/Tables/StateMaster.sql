﻿CREATE TABLE [dbo].[StateMaster] (
    [ID]          INT           NOT NULL,
    [Title]       VARCHAR (100) NOT NULL,
    [StateHeadID] VARCHAR (200) NULL,
    [CreatedOn]   DATETIME      CONSTRAINT [DF_StateMaster_CreatedOn] DEFAULT (getdate()) NULL,
    [CreatedBy]   VARCHAR (200) NULL,
    [ModifiedOn]  DATETIME      NULL,
    [ModifiedBy]  VARCHAR (200) NULL
);

