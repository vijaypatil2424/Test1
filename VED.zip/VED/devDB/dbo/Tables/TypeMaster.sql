﻿CREATE TABLE [dbo].[TypeMaster] (
    [ID]         INT           NOT NULL,
    [Title]      VARCHAR (50)  NOT NULL,
    [CreatedOn]  DATETIME      CONSTRAINT [DF_TypeMaster_CreatedOn] DEFAULT (getdate()) NULL,
    [CreatedBy]  VARCHAR (200) NULL,
    [ModifiedOn] DATETIME      NULL,
    [ModifiedBy] VARCHAR (200) NULL
);

