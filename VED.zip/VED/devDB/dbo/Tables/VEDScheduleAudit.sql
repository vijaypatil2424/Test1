﻿CREATE TABLE [dbo].[VEDScheduleAudit] (
    [ID]                   INT           IDENTITY (1, 1) NOT NULL,
    [VEDScheduleID]        INT           NOT NULL,
    [PreviousScheduleDate] DATETIME      NULL,
    [NewScheduleDate]      DATETIME      NULL,
    [Comments]             VARCHAR (MAX) NULL,
    [Scheduledby]          VARCHAR (200) NULL,
    [ModifiedOn]           DATETIME      CONSTRAINT [DF_VEDScheduleAudit_ModifiedOn] DEFAULT (getdate()) NULL,
    [ModifiedBy]           VARCHAR (200) NULL,
    CONSTRAINT [PK_VEDScheduleAudit] PRIMARY KEY CLUSTERED ([ID] ASC)
);

