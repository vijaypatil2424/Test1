﻿CREATE TABLE [dbo].[VEDSchedules] (
    [ID]                     INT           IDENTITY (1, 1) NOT NULL,
    [OfficeID]               INT           NOT NULL,
    [ScheduledOn]            DATETIME      NULL,
    [ScheduledBy]            VARCHAR (200) NULL,
    [ActualAssesstmentDate]  DATETIME      NULL,
    [VitalCount]             DECIMAL (5)   NULL,
    [EssentialCount]         DECIMAL (5)   NULL,
    [DesirableCount]         DECIMAL (5)   NULL,
    [TotalVEDByType]         DECIMAL (5)   NULL,
    [VitalNotApplicable]     DECIMAL (5)   NULL,
    [EssentialNotApplicable] DECIMAL (5)   NULL,
    [DesirableNotApplicable] DECIMAL (5)   NULL,
    [VEDScore]               DECIMAL (5)   NULL,
    [MAXVEDScore]            DECIMAL (5)   NULL,
    [CreatedOn]              DATETIME      CONSTRAINT [DF_VEDSchedules_CreatedOn] DEFAULT (getdate()) NULL,
    [ModifiedOn]             DATETIME      NULL,
    [ModifiedBy]             VARCHAR (200) NULL,
    [AssessmentType]         INT           NULL,
    [DelegatedBy]            VARCHAR (200) NULL,
    CONSTRAINT [PK_VEDSchedules] PRIMARY KEY CLUSTERED ([ID] ASC)
);

