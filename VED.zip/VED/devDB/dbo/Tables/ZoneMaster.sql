﻿CREATE TABLE [dbo].[ZoneMaster] (
    [ID]          INT           NOT NULL,
    [Title]       VARCHAR (20)  NOT NULL,
    [ZonalHeadID] VARCHAR (200) NOT NULL,
    [CreatedOn]   DATETIME      CONSTRAINT [DF_ZoneMaster_CreatedOn] DEFAULT (getdate()) NULL,
    [CreatedBy]   VARCHAR (200) NULL,
    [ModifiedOn]  DATETIME      NULL,
    [ModifiedBy]  VARCHAR (200) NULL
);

