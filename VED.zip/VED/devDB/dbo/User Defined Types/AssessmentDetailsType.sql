﻿CREATE TYPE [dbo].[AssessmentDetailsType] AS TABLE (
    [VEDScheduleID]     INT           NOT NULL,
    [FacilityAreaID]    INT           NOT NULL,
    [FacilityDetailsID] INT           NOT NULL,
    [CriticalityID]     INT           NOT NULL,
    [Condition]         VARCHAR (20)  NOT NULL,
    [AssessmentDoneBy]  VARCHAR (200) NOT NULL,
    [AssessmentType]    INT           NOT NULL,
    [Comments]          VARCHAR (500) NOT NULL);

