﻿CREATE TYPE [dbo].[AssessmentImagesType] AS TABLE (
    [VEDScheduleID]    INT           NULL,
    [FacilityDetailID] INT           NULL,
    [Image]            IMAGE         NULL,
    [ImageName]        VARCHAR (500) NULL,
    [CreatedBy]        VARCHAR (200) NULL);

