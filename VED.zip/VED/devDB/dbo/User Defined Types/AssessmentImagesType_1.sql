﻿CREATE TYPE [dbo].[AssessmentImagesType_1] AS TABLE (
    [VEDScheduleID]    INT             NULL,
    [FacilityDetailID] INT             NULL,
    [Image]            VARBINARY (MAX) NULL,
    [ImageName]        VARCHAR (500)   NULL,
    [CreatedBy]        VARCHAR (200)   NULL);

