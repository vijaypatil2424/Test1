﻿
using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace vedListUpdateConsole
{
    public class Common
    {
        public static int getzoneid(string zonetext)
        {
            int lookupid = 0;
            string siteUrl = "http://qaspweb4.ril.com/sites/RCS/jcved/";

            ClientContext clientContext = new ClientContext(siteUrl);
            List oList = clientContext.Web.Lists.GetByTitle("JCZones");

            //CamlQuery camlQuery = new CamlQuery();


            CamlQuery camlQuery = new CamlQuery() { ViewXml = "<View><Query><Where><Eq><FieldRef Name='Title' /><Value Type='Text'>" + zonetext + "</Value></Eq></Where></Query></View>" };
            //camlQuery.ViewXml = "<View><Query<Where><Eq><FieldRef Name='Title' /><Value Type='Text'>"+zonetext+"</Value></Eq></Where></Query></View>";  


            ListItemCollection collListItem = oList.GetItems(camlQuery);

            clientContext.Load(collListItem);

            clientContext.ExecuteQuery();
            foreach (ListItem oListItem in collListItem)
            {
                lookupid = oListItem.Id;

            }




            return lookupid;
        }
        public static int getstateid(string statetext)
        {
            int lookupid = 0;
            string siteUrl = "http://qaspweb4.ril.com/sites/RCS/jcved/";

            ClientContext clientContext = new ClientContext(siteUrl);
            List oList = clientContext.Web.Lists.GetByTitle("JCStates");

            //CamlQuery camlQuery = new CamlQuery();


            CamlQuery camlQuery = new CamlQuery() { ViewXml = "<View><Query><Where><Eq><FieldRef Name='Title' /><Value Type='Text'>" + statetext + "</Value></Eq></Where></Query></View>" };
            //camlQuery.ViewXml = "<View><Query<Where><Eq><FieldRef Name='Title' /><Value Type='Text'>"+zonetext+"</Value></Eq></Where></Query></View>";  


            ListItemCollection collListItem = oList.GetItems(camlQuery);

            clientContext.Load(collListItem);

            clientContext.ExecuteQuery();
            foreach (ListItem oListItem in collListItem)
            {
                lookupid = oListItem.Id;

            }




            return lookupid;
        }
        public static int getjcofficetypeid(string jcofficetypetext)
        {
            if (jcofficetypetext == "DC")
            {
                jcofficetypetext = "Distribution Center";
            }
            else if (jcofficetypetext == "WHs")
            {
                jcofficetypetext = "Warehouse";
            }
            else if (jcofficetypetext == "Jio Office")
            {
                jcofficetypetext = "Jio Office";
            }

            int lookupid = 0;
            string siteUrl = "http://qaspweb4.ril.com/sites/RCS/jcved/";

            ClientContext clientContext = new ClientContext(siteUrl);
            List oList = clientContext.Web.Lists.GetByTitle("JCorOffice");

            //CamlQuery camlQuery = new CamlQuery();


            CamlQuery camlQuery = new CamlQuery() { ViewXml = "<View><Query><Where><Eq><FieldRef Name='Title' /><Value Type='Text'>" + jcofficetypetext + "</Value></Eq></Where></Query></View>" };
            //camlQuery.ViewXml = "<View><Query<Where><Eq><FieldRef Name='Title' /><Value Type='Text'>"+zonetext+"</Value></Eq></Where></Query></View>";  


            ListItemCollection collListItem = oList.GetItems(camlQuery);

            clientContext.Load(collListItem);

            clientContext.ExecuteQuery();
            foreach (ListItem oListItem in collListItem)
            {
                lookupid = oListItem.Id;

            }
            return lookupid;
        }
    }
}

