﻿using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace vedListUpdateConsole
{
    public class JioCenter
    {
        public void Start()
        {
            try
            {
                ClientContext ctx = new ClientContext("http://sp13devwfe01:19999/sites/RCS/JCVED/");
                List listOfficeMaster = ctx.Web.Lists.GetByTitle("JCOfficeMaster");
                ListItemCollection TempOfficeMaster = listOfficeMaster.GetItems(CamlQuery.CreateAllItemsQuery());
                ctx.Load(TempOfficeMaster); // loading all the fields JCStates
                ctx.ExecuteQuery();
                foreach (ListItem item in TempOfficeMaster)
                {
                    //ClientContext ctx1 = new ClientContext("http://sp13devwfe01:19999/sites/RCS/JCVED/");
                    //List listOfficeMaster1 = ctx1.Web.Lists.GetByTitle("WH");
                    //ListItem ite = listOfficeMaster1.GetItemById(item.Id);
                    //ctx1.Load(ite);
                    //ctx1.ExecuteQuery();
                    item["Area"] = Convert.ToString(item["Area"]);
                    item["PinCode"] = Convert.ToString(item["PinCode"]);
                    ////.item//.item.item["Site_x0020_Type_x0020__x000a__x0"] = "Warehouse";
                    item.Update();
                    ctx.ExecuteQuery();
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }
    }
}
