﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.SharePoint.Client;
using SP = Microsoft.SharePoint.Client;
using System.Data;
using System.Net;
using System.Security;


namespace vedListUpdateConsole
{
    class Program
    {
        //static void Main(string[] args)
        //{
        //    ClientContext ctx = new ClientContext("http://sp13devwfe01:19999/sites/RCS/JCVED/");
        //    List listOfficeMaster = ctx.Web.Lists.GetByTitle("Jio Office");
        //    ListItemCollection TempOfficeMaster = listOfficeMaster.GetItems(CamlQuery.CreateAllItemsQuery());
        //    ctx.Load(TempOfficeMaster); // loading all the fields JCStates
        //    ctx.ExecuteQuery();

        //    List JCOfficeMaster = ctx.Web.Lists.GetByTitle("JCOfficeMaster");
        //    try
        //    {
        //        int j = 0;
        //        foreach (var itemst in TempOfficeMaster)
        //        {
        //            ListItemCreationInformation itemCreateInfo = new ListItemCreationInformation();

        //            ListItem olist = JCOfficeMaster.AddItem(itemCreateInfo);
        //            string s=Convert.ToString(itemst["Title"]);
        //            olist["Title"] = itemst["Title"];
        //            if (s == "JWH_KLKT_01")	
        //            {
        //                string s1 =string.Empty;
        //            }
        //            string zone = Convert.ToString(itemst["Region"]);
        //            int zonelookupid = getzoneid(zone);
        //            olist["Zone"] = zonelookupid;

        //            string state = Convert.ToString(itemst["State"]);
        //            int stateid = getstateid(state);

        //            olist["JioState"] = stateid;
        //            olist["City"] = itemst["City"];
        //            olist["Address"] = itemst["Office_x0020_Address"];

        //            string jcofficetype = Convert.ToString(itemst["Site_x0020_Type_x0020__x000a__x0"]);
        //            int jcofficetypelookupid = getjcofficetypeid(jcofficetype);
        //            olist["JC_x002f_Office"] = jcofficetypelookupid;


        //            //olist["JC_x002f_Office"] = itemst["Site_x0020_Type_x0020__x000a__x0"];
        //            string activeornot = Convert.ToString(itemst["Status_x0020__x000a_of_x0020_Off"]);
        //            if (activeornot == "Live")
        //            {
        //                olist["Active"] = 1;// itemst["Status_x0020_of_x0020_DC"];
        //            }
        //            else
        //            {
        //                olist["Active"] = 0;
        //            }
        //            olist["CarpetArea"] = itemst["_x0020_Area_x0020__x000a_Sq_x002"];

        //            olist["Area"] = itemst["Area"];
        //            olist["PinCode"] = itemst["Pin_x0020_Code"];





        //            //value.Add(new SPFieldUserValue(web, user1.ID, user1.Name)));
        //            ////value.Add(new SPFieldUserValue(web, user2.ID, user2.Name)));

        //            //objItem["name"] = value;


        //            string areaHead = Convert.ToString(itemst["CS_x0020_State_x0020__x002f__x00"]);
        //            // olist["JCOfficeAdmins"] =areaHead;

        //            if (!string.IsNullOrEmpty(areaHead))
        //            {
        //                string[] areaHead1 = null;
        //                if (areaHead.Contains("/"))
        //                {
        //                    areaHead1 = areaHead.Split('/');
        //                    FieldUserValue[] userValueCollection = new FieldUserValue[areaHead1.Length];
        //                    try
        //                    {

        //                        int i = 0;
        //                        foreach (string item in areaHead1)
        //                        {
        //                            ClientContext ctx1 = new ClientContext("http://sp13devwfe01:19999/sites/RCS/JCVED/");
        //                            User userTest = ctx1.Web.EnsureUser(item.Trim());
        //                            ctx1.Load(userTest);
        //                            ctx1.ExecuteQuery();
        //                            FieldUserValue fieldUserVal = new FieldUserValue();
        //                            fieldUserVal.LookupId = userTest.Id;
        //                            userValueCollection.SetValue(fieldUserVal, i);
        //                            i++;
        //                        }
        //                        olist["JCOfficeAdmins"] = userValueCollection;
        //                    }
        //                    catch (Exception)
        //                    {

        //                        //throw;
        //                    }


        //                }
        //                else
        //                {
        //                    try
        //                    {
        //                        ClientContext ctx1 = new ClientContext("http://sp13devwfe01:19999/sites/RCS/JCVED/");
        //                        User userTest = ctx1.Web.EnsureUser(areaHead);
        //                        ctx1.Load(userTest);
        //                        ctx1.ExecuteQuery();
        //                        olist["JCOfficeAdmins"] = userTest.Id;
        //                    }
        //                    catch (Exception )
        //                    {
        //                        //Console.Write(ex.ToString());
        //                    }
        //                }


        //                //authorUser.Id;

        //            }
        //            olist.Update();
        //            ctx.ExecuteQuery();
        //            j++; 
        //        }
        //        Console.WriteLine(j);
        //    }
        //    catch (Exception ex)
        //    {
        //        Console.Write(ex.ToString());
        //    }


        //}

        static void Main(string[] args)
        {
            //WH whs = new WH();
            //whs.UpdateWHMaster();

            //DC whs = new DC();
            //whs.UpdateDCMaster();

            //JIOOffice jio = new JIOOffice();
            //jio.UpdateOfficeMaster();

            JioCenter jioCenter = new JioCenter();
            jioCenter.Start();

            //Question q = new Question();
            //q.Start();

        }

    }

}
