﻿using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace vedListUpdateConsole
{
    public class Question
    {
        public void Start()
        {
            ClientContext ctx = new ClientContext("http://qaspweb4.ril.com/sites/RCS/jcved");
            List listOfficeMaster = ctx.Web.Lists.GetByTitle("Facility Details Master");
            CamlQuery camlQuery = new CamlQuery();
            camlQuery.ViewXml =
                             @"<View>  
                                   <Query> 
                                      <Where><Or><Or><Eq><FieldRef Name='Office_x0020_Type' /><Value Type='Lookup'>Distribution Center</Value></Eq><Eq><FieldRef Name='Office_x0020_Type' /><Value Type='Lookup'>Jio Office</Value></Eq></Or><Eq><FieldRef Name='Office_x0020_Type' /><Value Type='Lookup'>Warehouse</Value></Eq></Or></Where> 
                                   </Query> 
                             </View>";
            ListItemCollection TempOfficeMaster = listOfficeMaster.GetItems(camlQuery);
            //ListItemCollection TempOfficeMaster = listOfficeMaster.GetItems(CamlQuery.CreateAllItemsQuery());
            ctx.Load(TempOfficeMaster); // loading all the fields JCStates
            ctx.ExecuteQuery();

            ClientContext ctx_2 = new ClientContext("http://sp13devwfe01:19999/sites/RCS/JCVED/");
            List JCOfficeMaster = ctx_2.Web.Lists.GetByTitle("Facility Details Master");
            foreach (ListItem item in TempOfficeMaster)
            {
                ListItemCreationInformation itemCreateInfo = new ListItemCreationInformation();
                ListItem olistItem = JCOfficeMaster.AddItem(itemCreateInfo);
                olistItem["Facility_x0020_Area"] = GetFacilityArea((item["Facility_x0020_Area"] as FieldLookupValue).LookupValue);
                olistItem["Criticality"] = GetCriticality((item["Criticality"] as FieldLookupValue).LookupValue);
                olistItem["Office_x0020_Type"] = getjcofficetypeid((item["Office_x0020_Type"] as FieldLookupValue).LookupValue);
                olistItem["Comments"] = item["Comments"];
                olistItem["Title"] = item["Title"];
                olistItem.Update();
                ctx_2.ExecuteQuery();
            }

        }
        public int GetFacilityArea(string txt1)
        {
            // int id = 0;
            int lookupid = 0;
            string siteUrl = "http://sp13devwfe01:19999/sites/RCS/JCVED/";

            ClientContext clientContext = new ClientContext(siteUrl);
            List oList = clientContext.Web.Lists.GetByTitle("Facility Area Master");

            //CamlQuery camlQuery = new CamlQuery();


            CamlQuery camlQuery = new CamlQuery() { ViewXml = "<View><Query><Where><Eq><FieldRef Name='Title' /><Value Type='Text'>" + txt1 + "</Value></Eq></Where></Query></View>" };
            //camlQuery.ViewXml = "<View><Query<Where><Eq><FieldRef Name='Title' /><Value Type='Text'>"+zonetext+"</Value></Eq></Where></Query></View>";  


            ListItemCollection collListItem = oList.GetItems(camlQuery);

            clientContext.Load(collListItem);

            clientContext.ExecuteQuery();
            foreach (ListItem oListItem in collListItem)
            {
                lookupid = oListItem.Id;

            }
            return lookupid;
        }
        public int GetCriticality(string txt1)
        {
            // int id = 0;
            int lookupid = 0;
            string siteUrl = "http://qaspweb4.ril.com/sites/RCS/jcved/";

            ClientContext clientContext = new ClientContext(siteUrl);
            List oList = clientContext.Web.Lists.GetByTitle("Criticality Master");

            //CamlQuery camlQuery = new CamlQuery();


            CamlQuery camlQuery = new CamlQuery() { ViewXml = "<View><Query><Where><Eq><FieldRef Name='Title' /><Value Type='Text'>" + txt1 + "</Value></Eq></Where></Query></View>" };
            //camlQuery.ViewXml = "<View><Query<Where><Eq><FieldRef Name='Title' /><Value Type='Text'>"+zonetext+"</Value></Eq></Where></Query></View>";  


            ListItemCollection collListItem = oList.GetItems(camlQuery);

            clientContext.Load(collListItem);

            clientContext.ExecuteQuery();
            foreach (ListItem oListItem in collListItem)
            {
                lookupid = oListItem.Id;

            }




            return lookupid;







        }
        public int getjcofficetypeid(string jcofficetypetext)
        {
            if (jcofficetypetext == "DC")
            {
                jcofficetypetext = "Distribution Center";
            }
            else if (jcofficetypetext == "WHs")
            {
                jcofficetypetext = "Warehouse";
            }
            else if (jcofficetypetext == "Jio Office")
            {
                jcofficetypetext = "Jio Office";
            }

            int lookupid = 0;
            string siteUrl = "http://qaspweb4.ril.com/sites/RCS/jcved/";

            ClientContext clientContext = new ClientContext(siteUrl);
            List oList = clientContext.Web.Lists.GetByTitle("JCorOffice");

            //CamlQuery camlQuery = new CamlQuery();


            CamlQuery camlQuery = new CamlQuery() { ViewXml = "<View><Query><Where><Eq><FieldRef Name='Title' /><Value Type='Text'>" + jcofficetypetext + "</Value></Eq></Where></Query></View>" };
            //camlQuery.ViewXml = "<View><Query<Where><Eq><FieldRef Name='Title' /><Value Type='Text'>"+zonetext+"</Value></Eq></Where></Query></View>";  


            ListItemCollection collListItem = oList.GetItems(camlQuery);

            clientContext.Load(collListItem);

            clientContext.ExecuteQuery();
            foreach (ListItem oListItem in collListItem)
            {
                lookupid = oListItem.Id;

            }
            return lookupid;
        }

    }
}
