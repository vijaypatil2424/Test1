﻿using Microsoft.SharePoint.Client;
using Microsoft.SharePoint.Client.UserProfiles;
using Microsoft.SharePoint.Client.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace vedListUpdateConsole
{
    public class WH
    {
        public void Start()
        {
            try
            {
                ClientContext ctx = new ClientContext("http://sp13devwfe01:19999/sites/RCS/JCVED/");
                List listOfficeMaster = ctx.Web.Lists.GetByTitle("WareHouseDump");
                ListItemCollection TempOfficeMaster = listOfficeMaster.GetItems(CamlQuery.CreateAllItemsQuery());
                ctx.Load(TempOfficeMaster); // loading all the fields JCStates
                ctx.ExecuteQuery();
                foreach (ListItem item in TempOfficeMaster)
                {
                    //ClientContext ctx1 = new ClientContext("http://sp13devwfe01:19999/sites/RCS/JCVED/");
                    //List listOfficeMaster1 = ctx1.Web.Lists.GetByTitle("WH");
                    //ListItem ite = listOfficeMaster1.GetItemById(item.Id);
                    //ctx1.Load(ite);
                    //ctx1.ExecuteQuery();
                    item["Email"] = item["Email_x002d_ID"].ToString() + ";";
                    ////.item//.item.item["Site_x0020_Type_x0020__x000a__x0"] = "Warehouse";
                    item.Update();
                    ctx.ExecuteQuery();
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }
        public void UpdateWHMaster()
        {
            ClientContext ctx = new ClientContext("http://sp13devwfe01:19999/sites/RCS/JCVED/");
            List listOfficeMaster = ctx.Web.Lists.GetByTitle("WareHouseDump");
            ListItemCollection TempOfficeMaster = listOfficeMaster.GetItems(CamlQuery.CreateAllItemsQuery());
            ctx.Load(TempOfficeMaster); // loading all the fields JCStates
            ctx.ExecuteQuery();
           /////////// //http://qaspweb4.ril.com/sites/RCS/jcved/


            ClientContext ctx_2 = new ClientContext("http://qaspweb4.ril.com/sites/RCS/jcved/");
            List JCOfficeMaster = ctx_2.Web.Lists.GetByTitle("JCOfficeMaster");
            try
            {
                int j = 0;
                foreach (var item in TempOfficeMaster)
                {
                    ListItemCreationInformation itemCreateInfo = new ListItemCreationInformation();

                    ListItem olistItem = JCOfficeMaster.AddItem(itemCreateInfo);
                    string s = Convert.ToString(item["Title"]);
                    olistItem["Title"] = item["Title"];
                    //if (s == "JWH_KLKT_01")
                    //{
                    //    string s1 = string.Empty;
                    //}
                    string zone = Convert.ToString(item["Region"]);
                    int zonelookupid = Common.getzoneid(zone);
                    olistItem["Zone"] = zonelookupid;

                    string state = Convert.ToString(item["State"]);
                    int stateid = Common.getstateid(state);

                    olistItem["JioState"] = stateid;
                    olistItem["City"] = item["City"];
                    olistItem["Address"] = item["Address"];

                    string jcofficetype = Convert.ToString(item["Site_x0020_Type_x0020__x000a__x0"]);
                    int jcofficetypelookupid = Common.getjcofficetypeid(jcofficetype);
                    olistItem["JC_x002f_Office"] = jcofficetypelookupid;


                    //olist["JC_x002f_Office"] = itemst["Site_x0020_Type_x0020__x000a__x0"]; //Status_x0020_of_x0020_WH
                    string activeornot = Convert.ToString(item["Status_x0020_of_x0020_WH"]);
                    if (activeornot == "Live")
                    {
                        olistItem["Active"] = 1;// itemst["Status_x0020_of_x0020_DC"];
                    }
                    else
                    {
                        olistItem["Active"] = 0;
                    }
                    olistItem["CarpetArea"] = item["Area_x000a_Sq_x002e__x0020_Ft_x0"];// //_x0020_Area_x0020__x000a_Sq_x002

                    olistItem["Area"] = item["Area"];
                    olistItem["PinCode"] = item["Pin_x0020_Code"];
                    olistItem["JCOfficeType"] = 1;
                    olistItem["CityType"] = 1;
                    olistItem["JCType"] = 1;
                    //value.Add(new SPFieldUserValue(web, user1.ID, user1.Name)));
                    ////value.Add(new SPFieldUserValue(web, user2.ID, user2.Name)));

                    //objItem["name"] = value;


                    string areaHead = Convert.ToString(item["CS_x0020_State_x0020__x002f__x00"]);
                    // olist["JCOfficeAdmins"] =areaHead;

                    if (!string.IsNullOrEmpty(areaHead))
                    {
                        string[] areaHead1 = null;
                        if (areaHead.Contains("/"))
                        {
                            areaHead1 = areaHead.Split('/');
                            FieldUserValue[] userValueCollection = new FieldUserValue[areaHead1.Length];
                            try
                            {

                                int i = 0;
                                foreach (string item1 in areaHead1)
                                {
                                    ClientContext ctx1 = new ClientContext("http://qaspweb4.ril.com/sites/RCS/jcved/");
                                    //User user1 = ctx1.Web.
                                    User userTest = ctx1.Web.EnsureUser(item1.Trim());
                                    ctx1.Load(userTest);
                                    ctx1.ExecuteQuery();
                                    FieldUserValue fieldUserVal = new FieldUserValue();
                                    fieldUserVal.LookupId = userTest.Id;
                                    userValueCollection.SetValue(fieldUserVal, i);
                                    i++;
                                }
                                olistItem["JCOfficeAdmins"] = userValueCollection;
                            }
                            catch (Exception)
                            {
                                ClientContext ctx2 = new ClientContext("http://qaspweb4.ril.com/sites/RCS/jcved/");
                                Web web = ctx2.Web;
                                string email = "emailaddress@yourdomain.com";
                                PeopleManager peopleManager = new PeopleManager(ctx2);
                                ClientResult<PrincipalInfo> principal = Utility.ResolvePrincipal(ctx2, web, email, PrincipalType.User, PrincipalSource.All, web.SiteUsers, true);
                                ctx2.ExecuteQuery();


                                if (principal.Value != null)
                                {
                                    System.Console.WriteLine("Found user. LoginName is: '" + principal.Value.LoginName + "'");
                                    PersonProperties personProperties = peopleManager.GetPropertiesFor(principal.Value.LoginName);
                                    ctx2.Load(personProperties, p => p.AccountName, p => p.UserProfileProperties);
                                    ctx2.ExecuteQuery();
                                }
                                else
                                {
                                    System.Console.WriteLine("User with email '" + email + "' not found.");
                                }



                            }


                        }
                        else
                        {
                            try
                            {
                                ClientContext ctx1 = new ClientContext("http://qaspweb4.ril.com/sites/RCS/jcved/");
                                User userTest = ctx1.Web.EnsureUser(areaHead);
                                ctx1.Load(userTest);
                                ctx1.ExecuteQuery();
                                olistItem["JCOfficeAdmins"] = userTest.Id;
                            }
                            catch (Exception)
                            {
                                try
                                {
                                    ClientContext ctx2 = new ClientContext("http://qaspweb4.ril.com/sites/RCS/jcved/");
                                    Web web = ctx2.Web;
                                    string email = item["Email_x002d_ID"].ToString(); //"rajkumar.dwivedi@ril.com";//
                                    PeopleManager peopleManager = new PeopleManager(ctx2);
                                    ClientResult<PrincipalInfo> principal = Utility.ResolvePrincipal(ctx2, web, email, PrincipalType.User, PrincipalSource.All, web.SiteUsers, true);
                                    ctx2.ExecuteQuery();
                                    User userTest = ctx2.Web.EnsureUser(principal.Value.LoginName.Split('\\')[1]);
                                    ctx2.Load(userTest);
                                    ctx2.ExecuteQuery();
                                    olistItem["JCOfficeAdmins"] = userTest.Id;
                                }
                                catch (Exception)
                                {

                                    ClientContext ctx1 = new ClientContext("http://qaspweb4.ril.com/sites/RCS/jcved/");
                                    User userTest = ctx1.Web.EnsureUser("sachin7.jain");
                                    ctx1.Load(userTest);
                                    ctx1.ExecuteQuery();
                                    olistItem["JCOfficeAdmins"] = userTest.Id;
                                }
                            }
                        }
                    }
                    olistItem.Update();
                    ctx_2.ExecuteQuery();
                    j++;
                }
                Console.WriteLine(j);
            }
            catch (Exception ex)
            {
                Console.Write(ex.ToString());
            }

        }
    }
}
